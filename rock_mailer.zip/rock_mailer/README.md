<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400" alt="Laravel Logo"></a></p>

<p align="center">
<a href="https://github.com/laravel/framework/actions"><img src="https://github.com/laravel/framework/workflows/tests/badge.svg" alt="Build Status"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/dt/laravel/framework" alt="Total Downloads"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/v/laravel/framework" alt="Latest Stable Version"></a>
<a href="https://packagist.org/packages/laravel/framework"><img src="https://img.shields.io/packagist/l/laravel/framework" alt="License"></a>
</p>

## About Laravel

Laravel is a web application framework with expressive, elegant syntax. We believe development must be an enjoyable and creative experience to be truly fulfilling. Laravel takes the pain out of development by easing common tasks used in many web projects, such as:

- [Simple, fast routing engine](https://laravel.com/docs/routing).
- [Powerful dependency injection container](https://laravel.com/docs/container).
- Multiple back-ends for [session](https://laravel.com/docs/session) and [cache](https://laravel.com/docs/cache) storage.
- Expressive, intuitive [database ORM](https://laravel.com/docs/eloquent).
- Database agnostic [schema migrations](https://laravel.com/docs/migrations).
- [Robust background job processing](https://laravel.com/docs/queues).
- [Real-time event broadcasting](https://laravel.com/docs/broadcasting).

Laravel is accessible, powerful, and provides tools required for large, robust applications.

## Learning Laravel

Laravel has the most extensive and thorough [documentation](https://laravel.com/docs) and video tutorial library of all modern web application frameworks, making it a breeze to get started with the framework.

You may also try the [Laravel Bootcamp](https://bootcamp.laravel.com), where you will be guided through building a modern Laravel application from scratch.

If you don't feel like reading, [Laracasts](https://laracasts.com) can help. Laracasts contains thousands of video tutorials on a range of topics including Laravel, modern PHP, unit testing, and JavaScript. Boost your skills by digging into our comprehensive video library.

## Laravel Sponsors

We would like to extend our thanks to the following sponsors for funding Laravel development. If you are interested in becoming a sponsor, please visit the [Laravel Partners program](https://partners.laravel.com).

### Premium Partners

- **[Vehikl](https://vehikl.com/)**
- **[Tighten Co.](https://tighten.co)**
- **[WebReinvent](https://webreinvent.com/)**
- **[Kirschbaum Development Group](https://kirschbaumdevelopment.com)**
- **[64 Robots](https://64robots.com)**
- **[Curotec](https://www.curotec.com/services/technologies/laravel/)**
- **[Cyber-Duck](https://cyber-duck.co.uk)**
- **[DevSquad](https://devsquad.com/hire-laravel-developers)**
- **[Jump24](https://jump24.co.uk)**
- **[Redberry](https://redberry.international/laravel/)**
- **[Active Logic](https://activelogic.com)**
- **[byte5](https://byte5.de)**
- **[OP.GG](https://op.gg)**

## Contributing

Thank you for considering contributing to the Laravel framework! The contribution guide can be found in the [Laravel documentation](https://laravel.com/docs/contributions).

## Code of Conduct

In order to ensure that the Laravel community is welcoming to all, please review and abide by the [Code of Conduct](https://laravel.com/docs/contributions#code-of-conduct).

## Security Vulnerabilities

If you discover a security vulnerability within Laravel, please send an e-mail to Taylor Otwell via [taylor@laravel.com](mailto:taylor@laravel.com). All security vulnerabilities will be promptly addressed.

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

# Rock Mailer

A powerful email sending application built with Laravel, designed for handling large volumes of emails with attachments.

## Features

- Batch email processing
- Progress tracking with real-time updates
- File attachment support with random filename generation
- Authentication system
- Mobile-responsive interface
- Progress animation for better UX

## Installation on CentOS

### Automatic Installation

1. Download the installer script:
```bash
wget https://raw.githubusercontent.com/yourusername/rock_mailer/main/install.sh
```

2. Make it executable:
```bash
chmod +x install.sh
```

3. Run the installer:
```bash
sudo ./install.sh
```

4. After installation, configure your `.env` file:
```bash
cd /var/www/rock_mailer
nano .env
```

Update these settings:
```env
APP_URL=http://your-domain-or-ip
MAIL_MAILER=smtp
MAIL_HOST=your-smtp-server
MAIL_PORT=587
MAIL_USERNAME=your-username
MAIL_PASSWORD=your-password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=your-email
MAIL_FROM_NAME="${APP_NAME}"
```

### Manual Installation

If you prefer to install manually, follow these steps:

1. Install required packages:
```bash
sudo yum -y update
sudo yum -y install epel-release
sudo yum -y install wget git unzip httpd php php-cli php-fpm php-json php-common php-mysql php-zip php-gd php-mbstring php-curl php-xml php-pear php-bcmath php-json
```

2. Install Composer and clone the repository:
```bash
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
git clone https://github.com/yourusername/rock_mailer.git
cd rock_mailer
composer install --no-dev
```

3. Configure Apache and PHP (see install.sh for detailed configuration)

4. Set proper permissions:
```bash
sudo chown -R apache:apache /var/www/rock_mailer
sudo chmod -R 755 /var/www/rock_mailer
sudo chmod -R 775 /var/www/rock_mailer/storage
sudo chmod -R 775 /var/www/rock_mailer/bootstrap/cache
```

## Post-Installation

1. Set up your authentication credentials in the `.env` file
2. Configure your mail server settings
3. Test the application by sending a test email

## Security Considerations

1. Always use HTTPS in production
2. Keep your authentication credentials secure
3. Regularly update dependencies
4. Monitor mail server logs for any issues

## Troubleshooting

Common issues and solutions:

1. **Emails not sending:**
   - Check mail server configuration
   - Verify PHP mail settings
   - Check file permissions

2. **Upload issues:**
   - Verify PHP upload limits in php.ini
   - Check directory permissions

3. **Progress not updating:**
   - Clear browser cache
   - Check file permissions on storage directory

## Support

For issues and feature requests, please create an issue in the GitHub repository.

## License

The Rock Mailer is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
