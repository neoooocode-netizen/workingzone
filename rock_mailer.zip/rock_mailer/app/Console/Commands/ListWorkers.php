<?php

namespace App\Console\Commands;

use App\Models\WorkerNode;
use Illuminate\Console\Command;

class ListWorkers extends Command
{
    protected $signature = 'worker:list';
    protected $description = 'List all worker nodes';

    public function handle()
    {
        $workers = WorkerNode::all();
        
        $this->table(
            ['ID', 'Hostname', 'Status', 'Created At'],
            $workers->map(function ($worker) {
                return [
                    $worker->id,
                    $worker->hostname,
                    $worker->status,
                    $worker->created_at
                ];
            })
        );
    }
}
