<?php

namespace App\Console\Commands;

use App\Models\WorkerNode;
use App\Services\WorkerAutoSetup;
use Illuminate\Console\Command;

class SetupWorkerNode extends Command
{
    protected $signature = 'worker:setup {worker_id}';
    protected $description = 'Set up a worker node';

    protected $workerSetup;

    public function __construct(WorkerAutoSetup $workerSetup)
    {
        parent::__construct();
        $this->workerSetup = $workerSetup;
    }

    public function handle()
    {
        $worker = WorkerNode::find($this->argument('worker_id'));
        
        if (!$worker) {
            $this->error('Worker node not found');
            return 1;
        }

        $this->info('Setting up worker node: ' . $worker->hostname);

        try {
            $result = $this->workerSetup->setupWorker([
                'hostname' => $worker->hostname,
                'ip_address' => $worker->ip_address,
                'ssh_key_path' => $worker->ssh_key_path,
                'capacity' => $worker->capacity,
                'ssh_port' => $worker->ssh_port,
                'ssh_user' => $worker->ssh_user,
                'auth_type' => $worker->ssh_key_path ? 'key' : 'password',
            ]);

            if (!$result['success']) {
                $this->error('Failed to set up worker: ' . $result['message']);
                return 1;
            }

            $this->info('Worker setup completed successfully');
            return 0;
        } catch (\Exception $e) {
            $this->error('Error setting up worker: ' . $e->getMessage());
            return 1;
        }
    }
}
