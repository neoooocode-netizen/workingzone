<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class LogStreamEvent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $logEntry;
    private $channels;

    /**
     * Create a new event instance.
     */
    public function __construct(array $logEntry, array $channels = [])
    {
        $this->logEntry = $logEntry;
        $this->channels = $channels;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return array<int, \Illuminate\Broadcasting\Channel>
     */
    public function broadcastOn(): array
    {
        $broadcastChannels = [];

        // Always broadcast to all logs channel
        $broadcastChannels[] = new PrivateChannel('logs.all');

        // Add specific channels based on the log entry
        foreach ($this->channels as $channel) {
            $broadcastChannels[] = new PrivateChannel($channel);
        }

        return $broadcastChannels;
    }

    /**
     * Get the data to broadcast.
     */
    public function broadcastWith(): array
    {
        return [
            'timestamp' => now()->toIso8601String(),
            'type' => $this->logEntry['type'] ?? 'system',
            'level' => $this->logEntry['level'] ?? 'info',
            'message' => $this->logEntry['message'] ?? '',
            'context' => $this->logEntry['context'] ?? [],
            'worker_id' => $this->logEntry['worker_id'] ?? null,
            'campaign_id' => $this->logEntry['campaign_id'] ?? null,
        ];
    }
}
