<?php

namespace App\Http\Controllers;

use App\Models\EmailBatch;
use App\Models\Campaign;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class BatchController extends Controller
{
    /**
     * Get next available batch for processing
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getNext(Request $request)
    {
        try {
            // Get worker from request header
            $workerId = $request->header('X-Worker-ID');
            if (!$workerId) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Worker ID not provided'
                ], 400);
            }

            // Get worker by node_id but use its id (primary key) for relationships
            $worker = DB::table('worker_nodes')
                ->where('node_id', $workerId)
                ->first();

            if (!$worker) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Worker not found'
                ], 404);
            }

            // Log::info('Worker requesting batch', [
            //     'worker_id' => $workerId,
            //     'current_load' => $worker->current_load,
            //     'capacity' => $worker->capacity
            // ]);

            // Check worker capacity
            if ($worker->current_load >= $worker->capacity) {
                Log::warning('Worker at maximum capacity', [
                    'worker_id' => $workerId,
                    'current_load' => $worker->current_load,
                    'capacity' => $worker->capacity
                ]);
                return response()->json([
                    'status' => 'error',
                    'message' => 'Worker at maximum capacity'
                ], 400);
            }

            // Get next available batch from active campaigns
            $query = EmailBatch::whereHas('campaign', function ($query) {
                $query->where('status', 'active');
            })
            ->where('status', 'pending')
            ->whereNull('worker_node_id')
            ->orderBy('created_at', 'asc');

            // Log::debug('Batch query', [
            //     'sql' => $query->toSql(),
            //     'bindings' => $query->getBindings()
            // ]);

            $batch = $query->first();

            if (!$batch) {
                // Log counts to help diagnose why no batch was found
                $pendingCount = EmailBatch::where('status', 'pending')->count();
                $activeCampaignCount = Campaign::where('status', 'active')->count();
                $unassignedCount = EmailBatch::whereNull('worker_node_id')->count();

                // Log::info('No batches available', [
                //     'pending_batches' => $pendingCount,
                //     'active_campaigns' => $activeCampaignCount,
                //     'unassigned_batches' => $unassignedCount
                // ]);

                return response()->json([
                    'status' => 'success',
                    'message' => 'No batches available',
                    'data' => null
                ]);
            }

            // Load the campaign with its data
            $campaign = $batch->campaign;

            // Assign batch to worker using worker's id (primary key)
            $batch->update([
                'worker_node_id' => $worker->id,
                'status' => 'processing',
                'started_at' => now()
            ]);

            // Update worker load
            DB::table('worker_nodes')
                ->where('node_id', $workerId)
                ->increment('current_load');

            // Log::info('Batch assigned to worker', [
            //     'batch_id' => $batch->id,
            //     'worker_id' => $workerId,
            //     'campaign_id' => $campaign->id
            // ]);

            // Prepare email data with all necessary campaign information
            $emailData = [
                'id' => $batch->id, // Add batch ID to response
                'campaign' => [
                    'id' => $campaign->id,
                    'subject' => $campaign->subject,
                    'from_email' => $campaign->from_email,
                    'from_name' => $campaign->from_name,
                    'reply_to' => $campaign->reply_to,
                    'body' => $campaign->body,
                    'attachments' => collect($campaign->attachments)->map(function($attachment) {
                        try {
                            $fullPath = Storage::path($attachment['path']);
                            if (!file_exists($fullPath)) {
                                Log::error('Attachment file not found', [
                                    'path' => $attachment['path'],
                                    'full_path' => $fullPath
                                ]);
                                return null;
                            }

                            $content = file_get_contents($fullPath);
                            if ($content === false) {
                                Log::error('Failed to read attachment file', [
                                    'path' => $attachment['path'],
                                    'full_path' => $fullPath
                                ]);
                                return null;
                            }

                            return [
                                'name' => $attachment['name'],
                                'mime_type' => $attachment['mime_type'],
                                'content' => base64_encode($content)
                            ];
                        } catch (\Exception $e) {
                            Log::error('Error processing attachment', [
                                'path' => $attachment['path'],
                                'error' => $e->getMessage()
                            ]);
                            return null;
                        }
                    })->filter()->values()->all()
                ],
                'recipients' => $batch->recipients
            ];

            return response()->json([
                'status' => 'success',
                'data' => $emailData
            ]);

        } catch (\Exception $e) {
            Log::error('Error getting next batch', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'worker_id' => $request->header('X-Worker-ID')
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Failed to get next batch: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update batch processing status
     *
     * @param Request $request
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function updateStatus(Request $request, string $id)
    {
        $request->validate([
            'status' => 'required|in:processing,completed,failed',
            'success_count' => 'required|integer',
            'failed_count' => 'required|integer',
            'error_logs' => 'array'
        ]);

        $batch = EmailBatch::findOrFail($id);
        $workerId = $request->header('X-Worker-ID');

        // Verify worker ownership
        if ($batch->worker_node_id !== $workerId) {
            return response()->json([
                'status' => 'error',
                'message' => 'Unauthorized to update this batch'
            ], 403);
        }

        // Update batch status
        $batch->update([
            'status' => $request->status,
            'success_count' => $request->success_count,
            'failed_count' => $request->failed_count,
            'error_logs' => $request->error_logs,
            'completed_at' => $request->status === 'completed' ? now() : null
        ]);

        // Update campaign stats
        $campaign = Campaign::find($batch->campaign_id);
        $campaign->increment('sent_count', $request->success_count);
        $campaign->increment('failed_count', $request->failed_count);

        // Check if campaign is completed
        $remainingBatches = EmailBatch::where('campaign_id', $campaign->id)
            ->whereNotIn('status', ['completed', 'failed'])
            ->count();

        if ($remainingBatches === 0) {
            $campaign->update([
                'status' => 'completed',
                'completed_at' => now()
            ]);
        }

        // Update worker load
        if (in_array($request->status, ['completed', 'failed'])) {
            DB::table('worker_nodes')
                ->where('node_id', $workerId)
                ->decrement('current_load');
        }

        Log::info('Batch status updated', [
            'batch_id' => $id,
            'status' => $request->status,
            'worker_id' => $workerId
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Batch status updated successfully'
        ]);
    }

    /**
     * Mark batch as complete
     *
     * @param Request $request
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function complete(Request $request, string $id)
    {
        $batch = EmailBatch::findOrFail($id);
        $workerId = $request->header('X-Worker-ID');

        // Verify worker ownership
        if ($batch->worker_node_id !== $workerId) {
            return response()->json([
                'status' => 'error',
                'message' => 'Unauthorized to complete this batch'
            ], 403);
        }

        // Mark batch as completed
        $batch->update([
            'status' => 'completed',
            'completed_at' => now()
        ]);

        // Update worker load
        DB::table('worker_nodes')
            ->where('node_id', $workerId)
            ->decrement('current_load');

        // Check if campaign is completed
        $campaign = Campaign::find($batch->campaign_id);
        $remainingBatches = EmailBatch::where('campaign_id', $campaign->id)
            ->whereNotIn('status', ['completed', 'failed'])
            ->count();

        if ($remainingBatches === 0) {
            $campaign->update(['status' => 'completed']);
        }

        Log::info('Batch completed', [
            'batch_id' => $id,
            'worker_id' => $workerId
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Batch marked as complete'
        ]);
    }
}
