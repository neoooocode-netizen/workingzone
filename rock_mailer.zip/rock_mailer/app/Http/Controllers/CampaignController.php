<?php

namespace App\Http\Controllers;

use App\Models\Campaign;
use App\Models\EmailBatch;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class CampaignController extends Controller
{
    /**
     * Display a listing of campaigns
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $activeCampaigns = Campaign::with(['batches', 'activeWorkers'])
            ->orderBy('created_at', 'desc')
            ->get();

        $completedCampaigns = Campaign::where('status', 'completed')
            ->orderBy('completed_at', 'desc')
            ->paginate(10);

        // Calculate additional stats for active campaigns
        $activeCampaigns->each(function ($campaign) {
            // Calculate success rate
            $campaign->success_rate = $campaign->total_recipients > 0
                ? round(($campaign->sent_count / $campaign->total_recipients) * 100, 1)
                : 0;

            // Calculate emails per minute
            $startTime = $campaign->started_at ?? $campaign->created_at;
            $duration = now()->diffInMinutes($startTime) ?: 1;
            $campaign->emails_per_minute = round($campaign->sent_count / $duration);

            // Get batch statistics
            $campaign->batchStats = $campaign->batches->groupBy('status')
                ->map(fn($group) => $group->count());
        });

        return view('campaigns.index', compact('activeCampaigns', 'completedCampaigns'));
    }

    /**
     * Show the form for creating a new campaign.
     */
    public function create()
    {
        return view('campaigns.create');
    }

    /**
     * Store a newly created campaign.
     */
    public function store(Request $request)
    {
        try {
            // Basic validation for common fields
            $validatedData = $request->validate([
                'name' => 'required|string|max:255',
                'subject' => 'required|string|max:255',
                'from_email' => 'required|email|max:255',
                'from_name' => 'required|string|max:255',
                'reply_to' => 'nullable|email|max:255',
                'body' => 'required|string',
                'batch_size' => 'nullable|integer|min:1|max:2000',
                'priority' => 'nullable|integer|min:1|max:9',
                'recipients_type' => 'required|in:direct,file',
                'attachments' => 'nullable|array|max:10',
                'attachments.*' => [
                    'nullable',
                    'file',
                    function ($attribute, $value, $fail) {
                        if (!$value || !$value->isValid()) {
                            $fail('The file upload was not successful.');
                            return;
                        }

                        $extension = strtolower($value->getClientOriginalExtension());
                        $mimeType = $value->getMimeType();
                        $allowedExtensions = ['pdf', 'html', 'htm', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'gif'];
                        $allowedMimeTypes = [
                            'application/pdf',
                            'text/html',
                            'text/plain',
                            'application/msword',
                            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                            'application/vnd.ms-excel',
                            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                            'image/jpeg',
                            'image/png',
                            'image/gif'
                        ];
                        
                        if (!in_array($extension, $allowedExtensions) && !in_array($mimeType, $allowedMimeTypes)) {
                            $fail("The file must be a HTML, PDF, Word, Excel, or image file.");
                        }
                        
                        if ($value->getSize() > 10240 * 1024) {
                            $fail("The file size must not exceed 10MB.");
                        }
                    }
                ]
            ]);

            // Validate recipients based on input type
            if ($request->recipients_type === 'direct') {
                $request->validate([
                    'recipients' => 'required|string'
                ]);
                $recipientLines = preg_split("/\r\n|\n|\r/", $request->recipients);
            } else {
                $request->validate([
                    'recipients_file' => 'required|file|mimes:txt,csv|max:51200'
                ]);
                
                if (!$request->hasFile('recipients_file') || !$request->file('recipients_file')->isValid()) {
                    throw new \Exception('The recipients file upload was not successful.');
                }

                $file = $request->file('recipients_file');
                $recipientLines = collect(file($file->path()))
                    ->filter(function($line) {
                        return !empty(trim($line));
                    })
                    ->map(function($line) {
                        return trim($line);
                    })
                    ->toArray();
            }

            // Process recipients in chunks to avoid memory issues
            $validRecipients = [];
            $chunkSize = 2000; // Updated to match new batch size limit
            $chunks = array_chunk($recipientLines, $chunkSize);
            
            foreach ($chunks as $chunk) {
                $validChunk = array_filter($chunk, function($email) {
                    $email = trim($email);
                    return filter_var($email, FILTER_VALIDATE_EMAIL);
                });
                
                if (!empty($validChunk)) {
                    $validRecipients = array_merge($validRecipients, $validChunk);
                }
                
                // Free up memory
                unset($chunk);
                unset($validChunk);
            }

            if (empty($validRecipients)) {
                throw new \Exception('No valid email addresses found in the input.');
            }

            // Handle attachments
            $attachments = [];
            if ($request->hasFile('attachments')) {
                $storageDir = 'campaign-attachments';
                Storage::makeDirectory($storageDir);
                
                foreach ($request->file('attachments') as $file) {
                    if (!$file->isValid()) {
                        throw new \Exception("Invalid attachment file: " . $file->getClientOriginalName());
                    }

                    $uuid = Str::uuid();
                    $path = $file->storeAs(
                        "{$storageDir}/{$uuid}",
                        $file->getClientOriginalName(),
                        'local'
                    );
                    
                    if (!$path) {
                        throw new \Exception("Failed to store attachment: " . $file->getClientOriginalName());
                    }

                    $fullPath = Storage::path($path);
                    if (!file_exists($fullPath)) {
                        throw new \Exception("Stored file not found: " . $path);
                    }

                    $attachments[] = [
                        'path' => $path,
                        'name' => $file->getClientOriginalName(),
                        'mime_type' => $file->getMimeType(),
                        'size' => $file->getSize()
                    ];

                    Log::info('Attachment stored', [
                        'name' => $file->getClientOriginalName(),
                        'path' => $path,
                        'full_path' => $fullPath,
                        'exists' => file_exists($fullPath)
                    ]);
                }
            }

            $campaign = DB::transaction(function () use ($request, $validRecipients, $attachments) {
                // Create campaign
                $campaign = Campaign::create([
                    'id' => Str::uuid(),
                    'name' => $request->name,
                    'subject' => $request->subject,
                    'from_email' => $request->from_email,
                    'from_name' => $request->from_name,
                    'reply_to' => $request->reply_to,
                    'body' => $request->body,
                    'status' => 'active',
                    'total_recipients' => count($validRecipients),
                    'sent_count' => 0,
                    'failed_count' => 0,
                    'batch_size' => $request->batch_size ?? 100,
                    'priority' => $request->priority ?? 5,
                    'attachments' => $attachments
                ]);

                // Create email batches in chunks to avoid memory issues
                $batchNumber = 1;
                $recipientChunks = array_chunk($validRecipients, $campaign->batch_size);
                
                foreach ($recipientChunks as $chunk) {
                    EmailBatch::create([
                        'id' => Str::uuid(),
                        'campaign_id' => $campaign->id,
                        'recipients' => $chunk,
                        'status' => 'pending',
                        'total_count' => count($chunk),
                        'success_count' => 0,
                        'failed_count' => 0,
                        'error_log' => [],
                        'batch_number' => $batchNumber++
                    ]);
                    
                    // Free up memory
                    unset($chunk);
                }

                Log::info('Campaign created with batches', [
                    'campaign_id' => $campaign->id,
                    'total_recipients' => count($validRecipients),
                    'batch_count' => count($recipientChunks),
                    'priority' => $campaign->priority
                ]);

                return $campaign;
            });

            return redirect()->route('campaigns.show', $campaign)
                ->with('success', 'Campaign created successfully. Processing ' . number_format($campaign->total_recipients) . ' recipients.');

        } catch (\Exception $e) {
            Log::error('Campaign creation failed', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            $errorMessage = $e->getMessage();
            if (str_contains($errorMessage, 'validation')) {
                $errorMessage = 'Please check your input and try again.';
            }

            return back()->withErrors(['error' => $errorMessage])->withInput();
        }
    }

    /**
     * Display the specified campaign.
     */
    public function show(Campaign $campaign)
    {
        return view('campaigns.show', compact('campaign'));
    }

    /**
     * Get campaign status
     *
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function status($id)
    {
        $campaign = Campaign::with(['batches' => function ($query) {
            $query->select('id', 'campaign_id', 'status', 'worker_node_id');
        }])->findOrFail($id);

        $batchStats = $campaign->batches->groupBy('status')
            ->map(fn($group) => $group->count());

        return response()->json([
            'status' => 'success',
            'data' => [
                'campaign_id' => $campaign->id,
                'name' => $campaign->name,
                'status' => $campaign->status,
                'progress' => [
                    'total_recipients' => $campaign->total_recipients,
                    'sent_count' => $campaign->sent_count,
                    'failed_count' => $campaign->failed_count,
                    'batch_stats' => $batchStats,
                ],
                'created_at' => $campaign->created_at,
                'updated_at' => $campaign->updated_at,
            ]
        ]);
    }

    /**
     * Pause the specified campaign.
     */
    public function pause(Campaign $campaign)
    {
        if ($campaign->status === 'completed') {
            return back()->with('error', 'Cannot pause completed campaign');
        }

        $campaign->update(['status' => 'paused']);

        // Pause all pending batches
        EmailBatch::where('campaign_id', $campaign->id)
            ->where('status', 'pending')
            ->update(['status' => 'paused']);

        Log::info('Campaign paused', ['campaign_id' => $campaign->id]);

        return back()->with('success', 'Campaign paused successfully.');
    }

    /**
     * Resume the specified campaign.
     */
    public function resume(Campaign $campaign)
    {
        if ($campaign->status === 'completed') {
            return back()->with('error', 'Cannot resume completed campaign');
        }

        $campaign->update(['status' => 'active']);

        // Resume paused batches
        EmailBatch::where('campaign_id', $campaign->id)
            ->where('status', 'paused')
            ->update(['status' => 'pending']);

        Log::info('Campaign resumed', ['campaign_id' => $campaign->id]);

        return back()->with('success', 'Campaign resumed successfully.');
    }

    /**
     * Start the specified campaign.
     *
     * @param Campaign $campaign
     * @return \Illuminate\Http\RedirectResponse
     */
    public function start(Campaign $campaign)
    {
        try {
            DB::transaction(function () use ($campaign) {
                // Update campaign status
                $campaign->status = 'active';
                $campaign->started_at = now();
                $campaign->save();

                Log::info("Campaign started", [
                    'campaign_id' => $campaign->id,
                    'total_recipients' => $campaign->total_recipients,
                    'batch_count' => $campaign->batches()->count()
                ]);
            });

            return redirect()->route('campaigns.index')
                ->with('success', 'Campaign started successfully.');
        } catch (\Exception $e) {
            Log::error("Failed to start campaign", [
                'campaign_id' => $campaign->id,
                'error' => $e->getMessage()
            ]);

            return redirect()->route('campaigns.index')
                ->with('error', 'Failed to start campaign. Please try again.');
        }
    }

    /**
     * Download campaign attachment
     */
    public function downloadAttachment(Campaign $campaign, $path)
    {
        try {
            // Verify the attachment belongs to this campaign
            $attachment = collect($campaign->attachments)->first(function($att) use ($path) {
                return $att['path'] === $path;
            });

            if (!$attachment) {
                return response()->json(['error' => 'Attachment not found'], 404);
            }

            $fullPath = Storage::path($path);
            
            if (!file_exists($fullPath)) {
                return response()->json(['error' => 'File not found'], 404);
            }

            return response()->file($fullPath, [
                'Content-Type' => $attachment['mime_type'],
                'Content-Disposition' => 'attachment; filename="' . $attachment['name'] . '"'
            ]);

        } catch (\Exception $e) {
            Log::error('Failed to download attachment', [
                'campaign_id' => $campaign->id,
                'path' => $path,
                'error' => $e->getMessage()
            ]);
            return response()->json(['error' => 'Failed to download attachment'], 500);
        }
    }

    /**
     * Remove the specified campaign.
     */
    public function destroy(Campaign $campaign)
    {
        $campaign->delete();
        
        Log::info('Campaign deleted', ['campaign_id' => $campaign->id]);
        
        return redirect()->route('campaigns.index')
            ->with('success', 'Campaign deleted successfully.');
    }
}
