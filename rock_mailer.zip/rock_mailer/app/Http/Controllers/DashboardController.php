<?php

namespace App\Http\Controllers;

use App\Models\Campaign;
use App\Models\WorkerNode;
use App\Models\EmailBatch;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;

class DashboardController extends Controller
{
    /**
     * Show the dashboard
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Get system stats
        $stats = [
            'campaigns' => [
                'total' => Campaign::count(),
                'active' => Campaign::where('status', 'active')->count(),
                'completed' => Campaign::where('status', 'completed')->count(),
                'failed' => Campaign::where('status', 'failed')->count()
            ],
            'workers' => [
                'total' => WorkerNode::count(),
                'active' => WorkerNode::where('status', 'active')->count(),
                'offline' => WorkerNode::where('status', 'offline')->count()
            ],
            'emails' => [
                'sent' => Campaign::sum('sent_count'),
                'failed' => Campaign::sum('failed_count'),
                'pending' => EmailBatch::where('status', 'pending')->count()
            ]
        ];

        // Get recent campaigns
        $recentCampaigns = Campaign::orderBy('created_at', 'desc')
            ->take(5)
            ->get();

        // Get active workers with their current load
        $workers = WorkerNode::where('status', 'active')
            ->orderBy('current_load', 'desc')
            ->get();

        return view('dashboard.index', compact('stats', 'recentCampaigns', 'workers'));
    }

    /**
     * Show system status
     *
     * @return \Illuminate\View\View
     */
    public function systemStatus()
    {
        // Get Redis status
        $redisStatus = $this->checkRedisStatus();

        // Get worker health status
        $workerStatus = WorkerNode::select('node_id', 'hostname', 'status', 'last_heartbeat', 'current_load')
            ->where('status', 'active')
            ->get()
            ->map(function ($worker) {
                $worker->healthy = $worker->last_heartbeat > now()->subMinutes(5);
                return $worker;
            });

        // Get queue metrics
        $queueMetrics = [
            'pending_campaigns' => Redis::zcard('campaigns:queue'),
            'pending_batches' => EmailBatch::where('status', 'pending')->count(),
            'processing_batches' => EmailBatch::where('status', 'processing')->count()
        ];

        return view('dashboard.system-status', compact('redisStatus', 'workerStatus', 'queueMetrics'));
    }

    /**
     * Check Redis connection status
     *
     * @return array
     */
    protected function checkRedisStatus(): array
    {
        try {
            $ping = Redis::ping();
            $info = Redis::info();
            
            return [
                'status' => 'connected',
                'version' => $info['redis_version'],
                'memory_used' => $info['used_memory_human'],
                'connected_clients' => $info['connected_clients'],
                'uptime' => $info['uptime_in_seconds']
            ];
        } catch (\Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Show campaign monitoring view
     *
     * @return \Illuminate\View\View
     */
    public function campaignMonitoring()
    {
        $campaigns = Campaign::with(['batches' => function ($query) {
                $query->select('id', 'campaign_id', 'status', 'success_count', 'failed_count');
            }])
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('dashboard.campaign-monitoring', compact('campaigns'));
    }

    /**
     * Show worker monitoring view
     *
     * @return \Illuminate\View\View
     */
    public function workerMonitoring()
    {
        $workers = WorkerNode::withCount(['activeBatches', 'completedBatches'])
            ->orderBy('status')
            ->orderBy('current_load', 'desc')
            ->paginate(10);

        return view('dashboard.worker-monitoring', compact('workers'));
    }
}
