<?php

namespace App\Http\Controllers;

use App\Models\Campaign;
use App\Models\SystemEvent;
use App\Models\Worker;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Redis;

class MonitoringController extends Controller
{
    public function systemOverview()
    {
        // Get basic metrics
        $totalWorkers = Worker::count();
        $activeCampaigns = Campaign::where('status', 'active')->count();
        
        // Calculate trends (percentage change in the last hour)
        $workerTrend = $this->calculateTrend('workers_trend', $totalWorkers);
        $campaignTrend = $this->calculateTrend('campaigns_trend', $activeCampaigns);
        $queueLoad = $this->getQueueLoad();
        $queueTrend = $this->calculateTrend('queue_trend', $queueLoad);
        $systemHealth = $this->calculateSystemHealth();
        $healthTrend = $this->calculateTrend('health_trend', $systemHealth);

        // Get queue statistics
        $queues = $this->getQueueStatistics();

        // Get chart data
        $campaignsChartData = $this->getCampaignsPerWorkerData();
        $resourceChartData = $this->getResourceUsageData();

        // Get recent system events
        $systemEvents = SystemEvent::latest()->take(10)->get();

        return view('monitoring.system-overview', compact(
            'totalWorkers',
            'activeCampaigns',
            'workerTrend',
            'campaignTrend',
            'queueLoad',
            'queueTrend',
            'systemHealth',
            'healthTrend',
            'queues',
            'campaignsChartData',
            'resourceChartData',
            'systemEvents'
        ));
    }

    private function calculateTrend($key, $currentValue)
    {
        $previousValue = Cache::get($key, $currentValue);
        $trend = $previousValue != 0 ? (($currentValue - $previousValue) / $previousValue) * 100 : 0;
        Cache::put($key, $currentValue, now()->addHour());
        return round($trend, 1);
    }

    private function getQueueLoad()
    {
        $totalCapacity = Worker::sum('capacity');
        if ($totalCapacity === 0) return 0;

        $currentLoad = Queue::size('emails') + Queue::size('campaign-processing');
        return min(100, round(($currentLoad / $totalCapacity) * 100, 1));
    }

    private function calculateSystemHealth()
    {
        $metrics = [
            'worker_health' => $this->getWorkerHealth(),
            'queue_health' => $this->getQueueHealth(),
            'memory_usage' => $this->getMemoryHealth(),
            'error_rate' => $this->getErrorRateHealth()
        ];

        return round(array_sum($metrics) / count($metrics), 1);
    }

    private function getWorkerHealth()
    {
        $totalWorkers = Worker::count();
        if ($totalWorkers === 0) return 100;

        $activeWorkers = Worker::where('status', 'active')->count();
        return ($activeWorkers / $totalWorkers) * 100;
    }

    private function getQueueHealth()
    {
        $failedJobs = Queue::failed()->count();
        $totalJobs = Queue::size('emails') + Queue::size('campaign-processing') + $failedJobs;
        
        if ($totalJobs === 0) return 100;
        return (($totalJobs - $failedJobs) / $totalJobs) * 100;
    }

    private function getMemoryHealth()
    {
        $memoryLimit = config('queue.memory_limit', 1024); // MB
        $currentUsage = memory_get_usage(true) / 1024 / 1024;
        
        return max(0, min(100, (($memoryLimit - $currentUsage) / $memoryLimit) * 100));
    }

    private function getErrorRateHealth()
    {
        $totalEmails = Cache::get('total_emails_sent', 0);
        $failedEmails = Cache::get('total_emails_failed', 0);
        
        if ($totalEmails === 0) return 100;
        return (($totalEmails - $failedEmails) / $totalEmails) * 100;
    }

    private function getQueueStatistics()
    {
        $queues = ['emails', 'campaign-processing'];
        $stats = [];

        foreach ($queues as $queue) {
            $processed = Cache::get("queue_{$queue}_processed", 0);
            $failed = Cache::get("queue_{$queue}_failed", 0);
            $rate = Cache::get("queue_{$queue}_rate", 0);

            $stats[] = [
                'name' => $queue,
                'jobs' => Queue::size($queue),
                'processed' => $processed,
                'failed' => $failed,
                'processing_rate' => $rate
            ];
        }

        return $stats;
    }

    private function getCampaignsPerWorkerData()
    {
        $workers = Worker::with('campaigns')->get();
        
        return [
            'labels' => $workers->pluck('node_id')->toArray(),
            'datasets' => [
                [
                    'label' => 'Active Campaigns',
                    'data' => $workers->map(function ($worker) {
                        return $worker->campaigns()->where('status', 'active')->count();
                    })->toArray(),
                    'backgroundColor' => '#60A5FA'
                ]
            ]
        ];
    }

    private function getResourceUsageData()
    {
        $timestamps = collect(range(0, 11))->map(function ($hour) {
            return now()->subHours(11 - $hour)->format('H:i');
        });

        return [
            'labels' => $timestamps->toArray(),
            'datasets' => [
                [
                    'label' => 'CPU Usage (%)',
                    'data' => collect(range(0, 11))->map(function ($hour) {
                        return Cache::get("cpu_usage_{$hour}", rand(20, 80));
                    })->toArray(),
                    'borderColor' => '#60A5FA',
                    'fill' => false
                ],
                [
                    'label' => 'Memory Usage (%)',
                    'data' => collect(range(0, 11))->map(function ($hour) {
                        return Cache::get("memory_usage_{$hour}", rand(30, 90));
                    })->toArray(),
                    'borderColor' => '#34D399',
                    'fill' => false
                ]
            ]
        ];
    }

    public function debugLogs()
    {
        return view('monitoring.debug-logs');
    }
}
