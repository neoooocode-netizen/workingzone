<?php

namespace App\Http\Controllers;

use App\Models\WorkerNode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use App\Services\WorkerAutoSetup;
use Illuminate\Support\Facades\File;

class WorkerController extends Controller
{
    protected $workerSetup;

    public function __construct(WorkerAutoSetup $workerSetup)
    {
        $this->workerSetup = $workerSetup;
    }

    /**
     * Display a listing of workers
     */
    public function index()
    {
        $workers = WorkerNode::orderBy('created_at', 'desc')->get();
        return view('workers.index', compact('workers'));
    }

    /**
     * Store a new worker node (admin UI)
     */
    public function store(Request $request)
    {
        try {
            // Determine if this is a single worker or batch upload
            $addType = $request->input('add_type', 'single');
            
            if ($addType === 'single') {
                return $this->storeSingleWorker($request);
            } else {
                return $this->storeBatchWorkers($request);
            }
            
        } catch (\Exception $e) {
            Log::error('Failed to create worker node', [
                'error' => $e->getMessage(),
                'add_type' => $request->input('add_type')
            ]);

            return redirect()->back()
                ->withInput()
                ->withErrors(['error' => $e->getMessage()]);
        }
    }
    
    /**
     * Store a single worker node
     */
    protected function storeSingleWorker(Request $request)
    {
        // Validate the request
        $config = $request->validate([
            'hostname' => 'required|string',
            'ssh_key_path' => 'required_if:auth_type,key|string|nullable',
            'capacity' => 'required|integer',
            'ssh_port' => 'required|integer',
            'ssh_user' => 'required|string',
            'auth_type' => 'required|in:password,key',
            'ssh_password' => 'required_if:auth_type,password|string|nullable',
            'ssh_key' => 'required_if:auth_type,key|string|nullable',
        ]);

        // Start worker setup process
        $setupResult = $this->workerSetup->setupWorker($config);
        if (!$setupResult['success']) {
            throw new \Exception($setupResult['error'] ?? 'Failed to setup worker');
        }

        return redirect()->route('workers.show', $setupResult['worker'])
            ->with('success', 'Worker node created successfully');
    }
    
    /**
     * Store multiple worker nodes from a batch file
     */
    protected function storeBatchWorkers(Request $request)
    {
        // Validate the request
        $request->validate([
            'workers_file' => 'required|file|mimes:txt',
            'batch_ssh_port' => 'required|integer',
            'capacity' => 'required|integer',
        ]);
        
        if (!$request->hasFile('workers_file')) {
            throw new \Exception('Workers file is required');
        }
        
        // Read the file contents
        $file = $request->file('workers_file');
        $content = File::get($file->getPathname());
        $lines = explode("\n", $content);
        
        // Filter empty lines
        $lines = array_filter($lines, fn($line) => !empty(trim($line)));
        
        if (empty($lines)) {
            throw new \Exception('Workers file is empty');
        }
        
        $successCount = 0;
        $errorCount = 0;
        $errors = [];
        
        // Process each line in the format: ip_address:username:password
        foreach ($lines as $line) {
            $parts = explode(':', trim($line));
            
            // Verify format
            if (count($parts) !== 3) {
                $errors[] = "Invalid format for line: {$line}. Expected format: ip_address:username:password";
                $errorCount++;
                continue;
            }
            
            // Create config for worker setup
            $config = [
                'hostname' => $parts[0],
                'ssh_user' => $parts[1],
                'ssh_password' => $parts[2],
                'auth_type' => 'password',
                'ssh_port' => $request->input('batch_ssh_port'),
                'capacity' => $request->input('capacity'),
                'ssh_key' => null,
                'ssh_key_path' => null,
            ];
            
            try {
                // Start worker setup process
                $setupResult = $this->workerSetup->setupWorker($config);
                if (!$setupResult['success']) {
                    $errors[] = "Failed to setup worker {$parts[0]}: " . ($setupResult['error'] ?? 'Unknown error');
                    $errorCount++;
                } else {
                    $successCount++;
                }
            } catch (\Exception $e) {
                Log::error('Failed to create worker node in batch', [
                    'error' => $e->getMessage(),
                    'hostname' => $parts[0]
                ]);
                $errors[] = "Exception setting up worker {$parts[0]}: {$e->getMessage()}";
                $errorCount++;
            }
        }
        
        // Prepare response message
        $message = "Batch processing complete. Successfully set up {$successCount} workers.";
        if ($errorCount > 0) {
            $message .= " Failed to set up {$errorCount} workers.";
            return redirect()->route('workers.index')
                ->with('warning', $message)
                ->with('batch_errors', $errors);
        }
        
        return redirect()->route('workers.index')
            ->with('success', $message);
    }

    /**
     * Display worker details
     */
    public function show(WorkerNode $worker)
    {
        try {
            $workerStatus = $this->workerSetup->getWorkerStatus($worker);
            
            // Get system metrics
            $metrics = [
                'memory' => $this->formatBytes($worker->memory_usage),
                'network' => 'N/A', // We can add network metrics later if needed
                'cpu' => $worker->cpu_usage . '%'
            ];
            
            $status = [
                'status' => $workerStatus['status'] === 'running' ? 'active' : 'inactive',
                'container_status' => $workerStatus['status'],
                'service_logs' => $workerStatus['logs'],
                'process_info' => $workerStatus['process_info'],
                'last_heartbeat' => $worker->last_heartbeat_at ? $worker->last_heartbeat_at->diffForHumans() : 'Never',
                'current_load' => $worker->current_load,
                'memory_usage' => $worker->memory_usage,
                'success_rate' => $worker->success_rate,
                'metrics' => $metrics,
                'last_error' => $worker->last_error,
                'error' => isset($workerStatus['error']) ? $workerStatus['error'] : null
            ];
            
            return view('workers.show', [
                'worker' => $worker,
                'status' => $status
            ]);
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    /**
     * Format bytes to human readable format
     */
    private function formatBytes($bytes, $precision = 2): string 
    {
        if ($bytes === 0 || $bytes === null) return "0 B";

        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);

        return round($bytes / (1024 ** $pow), $precision) . ' ' . $units[$pow];
    }

    /**
     * Update worker configuration
     */
    public function update(Request $request, WorkerNode $worker)
    {
        $request->validate([
            'capacity' => 'required|integer|min:1',
        ]);

        try {
            $worker->update([
                'capacity' => $request->capacity,
            ]);

            // Restart the worker service to apply changes
            $this->workerSetup->executeCommand($worker, 'systemctl restart rock-mailer-worker');

            return redirect()->route('workers.index')
                ->with('success', 'Worker updated successfully');
                
        } catch (\Exception $e) {
            Log::error('Failed to update worker', [
                'error' => $e->getMessage(),
                'worker' => $worker->id
            ]);
            
            return redirect()->back()
                ->withErrors(['error' => 'Failed to update worker: ' . $e->getMessage()]);
        }
    }

    /**
     * Remove worker node
     */
    public function destroy(WorkerNode $worker)
    {
        try {
            // Stop and disable the systemd service
            $this->workerSetup->executeCommand($worker, 'systemctl stop rock-mailer-worker');
            $this->workerSetup->executeCommand($worker, 'systemctl disable rock-mailer-worker');
            
            // Remove service files and application
            $this->workerSetup->executeCommand($worker, 'rm -f /etc/systemd/system/rock-mailer-worker.service');
            $this->workerSetup->executeCommand($worker, 'rm -rf /opt/rock_mailer');
            $this->workerSetup->executeCommand($worker, 'systemctl daemon-reload');
            
            // Delete the worker record
            $worker->delete();

            return redirect()->route('workers.index')
                ->with('success', 'Worker removed successfully');
                
        } catch (\Exception $e) {
            Log::error('Failed to remove worker node', [
                'error' => $e->getMessage(),
                'worker' => $worker
            ]);

            return redirect()->back()
                ->withErrors(['remove_error' => 'Failed to remove worker: ' . $e->getMessage()]);
        }
    }

    /**
     * Handle worker self-registration (API)
     */
    public function register(Request $request)
    {
        $request->validate([
            'hostname' => 'required|string',
            'system_info' => 'required|array',
            'capabilities' => 'required|array',
        ]);

        try {
            // Check if worker exists
            $worker = WorkerNode::where('hostname', $request->hostname)->first();

            if (!$worker) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Worker not found. Please add worker through admin interface first.'
                ], 404);
            }

            // Update worker info
            $worker->update([
                'system_info' => $request->system_info,
                'capabilities' => $request->capabilities,
                'status' => 'ready',
                'last_seen_at' => now(),
            ]);

            return response()->json([
                'status' => 'success',
                'worker_id' => $worker->id,
                'auth_token' => $worker->auth_token,
            ]);

        } catch (\Exception $e) {
            Log::error('Worker registration failed', [
                'error' => $e->getMessage(),
                'hostname' => $request->hostname
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Registration failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * API: Update worker heartbeat and metrics
     */
    public function heartbeat(Request $request)
    {
        try {
            // Log::info("Heartbeat request data:", [
            //     'all' => $request->all(),
            //     'json' => $request->json()->all(),
            //     'content' => $request->getContent(),
            //     'worker_id' => $request->header('X-Worker-ID')
            // ]);
            
            $data = $request->json()->all();
            
            $request->validate([
                'status' => 'required|string',
                'load' => 'required|integer|min:0',
                'memory_usage' => 'required|integer|min:0',
                'peak_memory' => 'required|integer|min:0',
                'cpu_usage' => 'required|numeric|min:0',
                'total_emails_sent' => 'required|integer|min:0',
                'success_rate' => 'required|numeric|min:0|max:100'
            ]);

            $worker = WorkerNode::where('id', $request->header('X-Worker-ID'))->first();

            if (!$worker) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Worker not found'
                ], 404);
            }

            $worker->update([
                'last_heartbeat_at' => now(),
                'current_load' => $data['load'],
                'memory_usage' => $data['memory_usage'],
                'cpu_usage' => $data['cpu_usage'],
                'total_emails_sent' => $data['total_emails_sent'],
                'success_rate' => $data['success_rate'],
                'status' => $data['status']
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Heartbeat updated successfully'
            ]);

        } catch (\Exception $e) {
            Log::error('Worker heartbeat failed', [
                'error' => $e->getMessage(),
                'worker_id' => $request->header('X-Worker-ID'),
                'request' => $request->all()
            ]);

            return response()->json([
                'status' => 'error',
                'message' => 'Heartbeat update failed: ' . $e->getMessage()
            ], 500);
        }
    }
}
