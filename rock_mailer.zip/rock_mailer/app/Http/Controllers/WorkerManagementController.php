<?php

namespace App\Http\Controllers;

use App\Models\WorkerNode;
use App\Services\WorkerAutoSetup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class WorkerManagementController extends Controller
{
    protected $workerSetup;

    public function __construct(WorkerAutoSetup $workerSetup)
    {
        $this->workerSetup = $workerSetup;
    }

    /**
     * Display a listing of workers
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $workers = WorkerNode::withCount(['activeBatches', 'completedBatches'])
            ->orderBy('status')
            ->orderBy('current_load', 'desc')
            ->get();

        return view('workers.index', compact('workers'));
    }

    /**
     * Store a newly created worker
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'hostname' => 'required|string',
            'ssh_port' => 'required|integer|min:1|max:65535',
            'ssh_user' => 'required|string',
            'auth_type' => 'required|in:password,key',
            'ssh_password' => 'required_if:auth_type,password',
            'ssh_key' => 'required_if:auth_type,key',
            'capacity' => 'required|integer|min:1'
        ]);

        try {
            // Generate unique node ID
            $nodeId = 'worker-' . Str::random(8);

            // Create worker record
            $worker = WorkerNode::create([
                'node_id' => $nodeId,
                'hostname' => $validated['hostname'],
                'status' => 'initializing',
                'capacity' => $validated['capacity'],
                'current_load' => 0,
                'auth_token' => Str::random(32)
            ]);

            // Prepare SSH credentials
            $sshCredentials = [
                'ssh_port' => $validated['ssh_port'],
                'ssh_user' => $validated['ssh_user'],
                'auth_type' => $validated['auth_type']
            ];

            // Add either password or key based on auth_type
            if ($validated['auth_type'] === 'password') {
                $sshCredentials['ssh_password'] = $validated['ssh_password'];
            } else {
                $sshCredentials['ssh_key'] = $validated['ssh_key'];
            }

            // Start worker deployment
            $this->workerSetup->deployWorker($worker, $sshCredentials);

            return redirect()->route('workers.index')
                ->with('success', 'Worker deployment initiated. This may take a few minutes.');
        } catch (\Exception $e) {
            Log::error('Worker deployment failed', [
                'error' => $e->getMessage(),
                'hostname' => $validated['hostname']
            ]);

            return redirect()->route('workers.index')
                ->with('error', 'Failed to deploy worker: ' . $e->getMessage());
        }
    }

    /**
     * Update worker settings
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\WorkerNode  $worker
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, WorkerNode $worker)
    {
        $validated = $request->validate([
            'capacity' => 'required|integer|min:1'
        ]);

        try {
            $worker->update($validated);

            return redirect()->route('workers.index')
                ->with('success', 'Worker settings updated successfully.');
        } catch (\Exception $e) {
            Log::error('Worker update failed', [
                'error' => $e->getMessage(),
                'worker_id' => $worker->id
            ]);

            return redirect()->route('workers.index')
                ->with('error', 'Failed to update worker: ' . $e->getMessage());
        }
    }

    /**
     * Remove a worker
     *
     * @param  \App\Models\WorkerNode  $worker
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(WorkerNode $worker)
    {
        try {
            // Stop any active batches
            $worker->activeBatches()->update(['status' => 'pending']);

            // Remove the worker
            $worker->delete();

            return redirect()->route('workers.index')
                ->with('success', 'Worker removed successfully.');
        } catch (\Exception $e) {
            Log::error('Worker removal failed', [
                'error' => $e->getMessage(),
                'worker_id' => $worker->id
            ]);

            return redirect()->route('workers.index')
                ->with('error', 'Failed to remove worker: ' . $e->getMessage());
        }
    }

    /**
     * Show worker details
     *
     * @param  \App\Models\WorkerNode  $worker
     * @return \Illuminate\View\View
     */
    public function show(WorkerNode $worker)
    {
        $worker->load(['activeBatches.campaign', 'completedBatches' => function ($query) {
            $query->latest()->take(10);
        }]);

        return view('workers.show', compact('worker'));
    }
}
