<?php

namespace App\Http\Middleware;

use App\Models\WorkerNode;
use Closure;
use Illuminate\Http\Request;

class WorkerAuthentication
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $workerId = $request->header('X-Worker-ID');
        $authToken = $request->header('X-Auth-Token');

        if (!$workerId || !$authToken) {
            return response()->json([
                'status' => 'error',
                'message' => 'Worker ID and Auth Token are required'
            ], 401);
        }

        $worker = WorkerNode::where('node_id', $workerId)
            ->where('auth_token', $authToken)
            ->first();

        if (!$worker) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid Worker credentials'
            ], 401);
        }

        // Add worker to request for later use
        $request->worker = $worker;

        return $next($request);
    }
}
