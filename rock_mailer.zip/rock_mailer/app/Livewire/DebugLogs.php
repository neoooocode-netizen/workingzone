<?php

namespace App\Livewire;

use App\Models\SystemLog;
use App\Models\Worker;
use App\Models\Campaign;
use Livewire\Component;
use Livewire\WithPagination;
use Illuminate\Support\Facades\Response;

class DebugLogs extends Component
{
    use WithPagination;

    public $filters = [
        'type' => '',
        'level' => '',
        'worker_id' => '',
        'campaign_id' => '',
        'date_from' => '',
        'date_to' => ''
    ];

    public $selectedLog = null;

    protected $queryString = [
        'filters' => ['except' => [
            'type' => '',
            'level' => '',
            'worker_id' => '',
            'campaign_id' => '',
            'date_from' => '',
            'date_to' => ''
        ]]
    ];

    public function mount()
    {
        // Set default date range to last 24 hours if not specified
        if (empty($this->filters['date_from'])) {
            $this->filters['date_from'] = now()->subDay()->format('Y-m-d\TH:i');
        }
        if (empty($this->filters['date_to'])) {
            $this->filters['date_to'] = now()->format('Y-m-d\TH:i');
        }
    }

    public function updatedFilters()
    {
        $this->resetPage();
    }

    public function getLogsQuery()
    {
        $query = SystemLog::query()
            ->when($this->filters['type'], fn($q, $type) => $q->where('type', $type))
            ->when($this->filters['level'], fn($q, $level) => $q->where('level', $level))
            ->when($this->filters['worker_id'], fn($q, $workerId) => $q->where('worker_id', $workerId))
            ->when($this->filters['campaign_id'], fn($q, $campaignId) => $q->where('campaign_id', $campaignId))
            ->when($this->filters['date_from'], fn($q, $date) => $q->where('created_at', '>=', $date))
            ->when($this->filters['date_to'], fn($q, $date) => $q->where('created_at', '<=', $date))
            ->latest();

        return $query;
    }

    public function showDetails($logId)
    {
        $this->selectedLog = SystemLog::findOrFail($logId);
        $this->dispatch('open-modal', 'log-details');
    }

    public function exportLogs()
    {
        $logs = $this->getLogsQuery()->get();
        
        $csvData = [];
        $csvData[] = [
            'Timestamp',
            'Type',
            'Level',
            'Message',
            'Worker',
            'Campaign',
            'Context',
            'Metadata'
        ];

        foreach ($logs as $log) {
            $csvData[] = [
                $log->created_at->format('Y-m-d H:i:s'),
                $log->type,
                $log->level,
                $log->message,
                $log->worker_id ? "Worker #{$log->worker_id}" : '',
                $log->campaign ? $log->campaign->name : '',
                json_encode($log->context),
                json_encode($log->metadata)
            ];
        }

        $filename = 'debug_logs_' . now()->format('Y-m-d_His') . '.csv';
        
        return Response::streamDownload(function () use ($csvData) {
            $file = fopen('php://output', 'w');
            foreach ($csvData as $row) {
                fputcsv($file, $row);
            }
            fclose($file);
        }, $filename, [
            'Content-Type' => 'text/csv',
        ]);
    }

    public function render()
    {
        return view('monitoring.debug-logs', [
            'logs' => $this->getLogsQuery()->paginate(25),
            'workers' => Worker::all(),
            'campaigns' => Campaign::all(),
        ]);
    }
}
