<?php

namespace App\Livewire;

use App\Models\SystemLog;
use App\Models\EmailDeliveryLog;
use App\Services\WorkerLoggingService;
use App\Services\DebugCommandService;
use Livewire\Component;
use Livewire\Attributes\On;

class ErrorDetailsModal extends Component
{
    public $showModal = false;
    public $errorLog = null;
    public $debugMode = false;
    public $verboseLogging = false;
    public $showRawData = false;
    public $showPerformanceMetrics = false;
    public $systemStatus = null;
    public $performanceMetrics = null;

    #[On('show-error-details')]
    public function showError($errorId, $type = 'system')
    {
        $this->errorLog = $type === 'system' 
            ? SystemLog::find($errorId) 
            : EmailDeliveryLog::find($errorId);

        if ($this->errorLog) {
            $this->loadSystemStatus();
            $this->showModal = true;
        }
    }

    public function loadSystemStatus()
    {
        if (!$this->errorLog) return;

        // Get worker status if available
        if ($this->errorLog->worker_id) {
            $debugService = new DebugCommandService();
            $this->systemStatus = $debugService->testWorkerConnectivity($this->errorLog->worker);

            if ($this->debugMode && $this->showPerformanceMetrics) {
                $loggingService = new WorkerLoggingService();
                $this->performanceMetrics = $loggingService->getSystemMetrics();
            }
        }
    }

    public function toggleDebugMode()
    {
        $this->debugMode = !$this->debugMode;
        if ($this->debugMode) {
            $this->loadSystemStatus();
        }
    }

    public function toggleVerboseLogging()
    {
        $this->verboseLogging = !$this->verboseLogging;
    }

    public function toggleRawData()
    {
        $this->showRawData = !$this->showRawData;
    }

    public function togglePerformanceMetrics()
    {
        $this->showPerformanceMetrics = !$this->showPerformanceMetrics;
        if ($this->showPerformanceMetrics) {
            $this->loadSystemStatus();
        }
    }

    public function retryEmail()
    {
        if ($this->errorLog instanceof EmailDeliveryLog) {
            // Dispatch job to retry email
            dispatch(new \App\Jobs\SendEmail(
                $this->errorLog->campaign,
                $this->errorLog->email,
                $this->errorLog->metadata['template'] ?? null
            ));

            $this->dispatch('success', 'Email queued for retry');
        }
    }

    public function refreshWorkerStatus()
    {
        if ($this->errorLog && $this->errorLog->worker_id) {
            $debugService = new DebugCommandService();
            $result = $debugService->forceWorkerStatusRefresh($this->errorLog->worker);
            
            if ($result['success']) {
                $this->dispatch('success', 'Worker status refreshed');
                $this->loadSystemStatus();
            } else {
                $this->dispatch('error', 'Failed to refresh worker status');
            }
        }
    }

    public function checkPostfix()
    {
        if ($this->errorLog && $this->errorLog->worker_id) {
            $debugService = new DebugCommandService();
            $result = $debugService->checkPostfixStatus($this->errorLog->worker);
            
            if ($result['success']) {
                $this->systemStatus['postfix'] = $result['data'];
                $this->dispatch('success', 'Postfix status checked');
            } else {
                $this->dispatch('error', 'Failed to check Postfix status');
            }
        }
    }

    public function clearErrorLog()
    {
        if ($this->errorLog) {
            $this->errorLog->delete();
            $this->dispatch('success', 'Error log cleared');
            $this->showModal = false;
        }
    }

    public function render()
    {
        return view('components.error-details-modal');
    }
}
