<?php

namespace App\Livewire;

use App\Models\Worker;
use App\Services\ErrorAggregationService;
use Carbon\Carbon;
use Livewire\Component;
use Livewire\Attributes\On;

class ErrorStatistics extends Component
{
    public $timeRange = '24h';
    public $workerId = null;
    public $selectedCategory = null;

    protected $queryString = [
        'timeRange' => ['except' => '24h'],
        'workerId' => ['except' => ''],
        'selectedCategory' => ['except' => '']
    ];

    public function mount()
    {
        $this->loadErrorStats();
    }

    public function getTimeRangeValues(): array
    {
        return [
            '1h' => ['name' => 'Last Hour', 'value' => now()->subHour()],
            '24h' => ['name' => 'Last 24 Hours', 'value' => now()->subDay()],
            '7d' => ['name' => 'Last 7 Days', 'value' => now()->subDays(7)],
            '30d' => ['name' => 'Last 30 Days', 'value' => now()->subDays(30)]
        ];
    }

    public function updatedTimeRange()
    {
        $this->loadErrorStats();
    }

    public function updatedWorkerId()
    {
        $this->loadErrorStats();
    }

    public function selectCategory($category)
    {
        $this->selectedCategory = $this->selectedCategory === $category ? null : $category;
        $this->loadErrorStats();
    }

    protected function getStartDate(): Carbon
    {
        return $this->getTimeRangeValues()[$this->timeRange]['value'];
    }

    #[On('refresh-error-stats')]
    public function loadErrorStats()
    {
        $service = new ErrorAggregationService();
        $startDate = $this->getStartDate();
        
        $this->errorStats = $service->getErrorStats(
            $startDate,
            now(),
            $this->workerId ? (int)$this->workerId : null
        );
    }

    public function getCategoryBadgeClass($category)
    {
        return ErrorAggregationService::getCategoryBadgeClass($category);
    }

    public function exportErrorStats()
    {
        $service = new ErrorAggregationService();
        $startDate = $this->getStartDate();
        
        $stats = $service->getErrorStats(
            $startDate,
            now(),
            $this->workerId ? (int)$this->workerId : null
        );

        $csvData = [];
        
        // Add categories summary
        $csvData[] = ['Error Categories'];
        $csvData[] = ['Category', 'Count', 'Description'];
        foreach ($stats['categories'] as $category => $count) {
            $csvData[] = [
                $category,
                $count,
                ErrorAggregationService::getCategoryDescription($category)
            ];
        }
        
        // Add worker error rates
        $csvData[] = [];
        $csvData[] = ['Worker Error Rates'];
        $csvData[] = ['Worker ID', 'Total Emails', 'Total Errors', 'Error Rate (%)'];
        foreach ($stats['rates'] as $rate) {
            $csvData[] = [
                $rate->id,
                $rate->total_emails,
                $rate->total_errors,
                $rate->error_rate
            ];
        }
        
        // Add error patterns
        $csvData[] = [];
        $csvData[] = ['Common Error Patterns'];
        $csvData[] = ['Error Type', 'Error Message', 'Occurrences'];
        foreach ($stats['patterns'] as $pattern) {
            $csvData[] = [
                $pattern->error_type,
                $pattern->error_message,
                $pattern->occurrence_count
            ];
        }
        
        // Add error trends
        $csvData[] = [];
        $csvData[] = ['Error Trends'];
        $csvData[] = ['Hour', 'Error Type', 'Error Count'];
        foreach ($stats['trends'] as $trend) {
            $csvData[] = [
                $trend->hour,
                $trend->error_type,
                $trend->error_count
            ];
        }

        $filename = 'error_statistics_' . now()->format('Y-m-d_His') . '.csv';
        
        return response()->streamDownload(function () use ($csvData) {
            $file = fopen('php://output', 'w');
            foreach ($csvData as $row) {
                fputcsv($file, $row);
            }
            fclose($file);
        }, $filename, [
            'Content-Type' => 'text/csv',
        ]);
    }

    public function render()
    {
        return view('monitoring.error-statistics', [
            'workers' => Worker::all(),
            'timeRanges' => $this->getTimeRangeValues(),
            'errorStats' => $this->errorStats ?? null,
        ]);
    }
}
