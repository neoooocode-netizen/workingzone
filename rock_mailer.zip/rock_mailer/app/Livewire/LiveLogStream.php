<?php

namespace App\Livewire;

use App\Models\Worker;
use App\Models\Campaign;
use App\Models\SystemLog;
use Livewire\Component;
use Livewire\Attributes\On;

class LiveLogStream extends Component
{
    public $filters = [
        'worker_id' => null,
        'campaign_id' => null,
        'error_only' => false,
        'type' => 'all'
    ];

    public $logs = [];
    public $maxLogs = 100;

    protected $queryString = [
        'filters' => ['except' => [
            'worker_id' => null,
            'campaign_id' => null,
            'error_only' => false,
            'type' => 'all'
        ]]
    ];

    public function mount()
    {
        $this->loadInitialLogs();
    }

    public function loadInitialLogs()
    {
        $query = SystemLog::query()
            ->when($this->filters['worker_id'], fn($q, $id) => $q->where('worker_id', $id))
            ->when($this->filters['campaign_id'], fn($q, $id) => $q->where('campaign_id', $id))
            ->when($this->filters['error_only'], fn($q) => $q->where('level', 'error'))
            ->when($this->filters['type'] !== 'all', fn($q) => $q->where('type', $this->filters['type']))
            ->latest()
            ->limit($this->maxLogs);

        $this->logs = $query->get()->toArray();
    }

    #[On('echo-private:logs.all,LogStreamEvent')]
    public function handleNewLog($payload)
    {
        // Check if the log matches our filters
        if (!$this->logMatchesFilters($payload)) {
            return;
        }

        // Add the new log to the beginning of the array
        array_unshift($this->logs, $payload);

        // Keep only the last $maxLogs entries
        $this->logs = array_slice($this->logs, 0, $this->maxLogs);
    }

    protected function logMatchesFilters($log): bool
    {
        if ($this->filters['worker_id'] && $log['worker_id'] != $this->filters['worker_id']) {
            return false;
        }

        if ($this->filters['campaign_id'] && $log['campaign_id'] != $this->filters['campaign_id']) {
            return false;
        }

        if ($this->filters['error_only'] && $log['level'] !== 'error') {
            return false;
        }

        if ($this->filters['type'] !== 'all' && $log['type'] !== $this->filters['type']) {
            return false;
        }

        return true;
    }

    public function clearLogs()
    {
        $this->logs = [];
    }

    public function toggleErrorOnly()
    {
        $this->filters['error_only'] = !$this->filters['error_only'];
        $this->loadInitialLogs();
    }

    public function updatedFilters()
    {
        $this->loadInitialLogs();
    }

    public function getLogBadgeClass($level)
    {
        return match($level) {
            'error' => 'bg-red-100 text-red-800',
            'warning' => 'bg-yellow-100 text-yellow-800',
            'info' => 'bg-blue-100 text-blue-800',
            'debug' => 'bg-gray-100 text-gray-800',
            default => 'bg-gray-100 text-gray-800'
        };
    }

    public function render()
    {
        return view('monitoring.live-log-stream', [
            'workers' => Worker::all(),
            'campaigns' => Campaign::all(),
        ]);
    }
}
