<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Campaign extends Model
{
    use HasFactory, HasUuids;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<string, mixed>
     */
    protected $fillable = [
        'id',
        'name',
        'subject',
        'from_email',
        'from_name',
        'reply_to',
        'body',
        'status',
        'total_recipients',
        'sent_count',
        'failed_count',
        'batch_size',
        'priority',
        'attachments'
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
        'total_recipients' => 'integer',
        'sent_count' => 'integer',
        'failed_count' => 'integer',
        'batch_size' => 'integer',
        'priority' => 'integer',
        'attachments' => 'array',
    ];

    /**
     * Get the batches for the campaign.
     */
    public function batches()
    {
        return $this->hasMany(EmailBatch::class);
    }

    /**
     * Get the active workers for the campaign.
     */
    public function activeWorkers()
    {
        return $this->belongsToMany(WorkerNode::class, 'campaign_worker')
            ->withPivot(['emails_sent', 'emails_failed'])
            ->wherePivot('active', true);
    }

    /**
     * Get all workers that have ever processed this campaign.
     */
    public function workers()
    {
        return $this->belongsToMany(WorkerNode::class, 'campaign_worker')
            ->withPivot(['emails_sent', 'emails_failed', 'active']);
    }
}
