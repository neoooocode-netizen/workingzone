<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class EmailBatch extends Model
{
    use HasFactory, HasUuids;

    protected $fillable = [
        'id',
        'campaign_id',
        'worker_node_id',
        'batch_number',
        'recipients',
        'total_count',
        'status',
        'success_count',
        'failed_count',
        'error_log',
        'started_at',
        'completed_at'
    ];

    protected $casts = [
        'recipients' => 'array',
        'error_log' => 'array',
        'success_count' => 'integer',
        'failed_count' => 'integer',
        'total_count' => 'integer',
        'batch_number' => 'integer',
        'started_at' => 'datetime',
        'completed_at' => 'datetime'
    ];

    /**
     * Get the campaign that owns this batch
     */
    public function campaign()
    {
        return $this->belongsTo(Campaign::class);
    }

    /**
     * Get the worker processing this batch
     */
    public function worker()
    {
        return $this->belongsTo(WorkerNode::class, 'worker_node_id');
    }

    /**
     * Calculate the progress percentage of this batch
     */
    public function getProgressPercentage()
    {
        $total = count($this->recipients);
        if ($total === 0) {
            return 0;
        }
        
        return round(($this->sent_count / $total) * 100, 2);
    }

    /**
     * Check if the batch is completed
     */
    public function isCompleted()
    {
        return $this->status === 'completed' || 
               ($this->sent_count + $this->failed_count) >= count($this->recipients);
    }
}
