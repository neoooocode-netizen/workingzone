<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EmailDeliveryLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'worker_id',
        'campaign_id',
        'email',
        'status',
        'message_id',
        'error_type',
        'error_message',
        'smtp_response',
        'delivery_time',
        'attempts',
        'metadata'
    ];

    protected $casts = [
        'metadata' => 'array',
        'delivery_time' => 'float',
        'created_at' => 'datetime',
        'updated_at' => 'datetime'
    ];

    // Status constants
    public const STATUS_SENT = 'sent';
    public const STATUS_FAILED = 'failed';
    public const STATUS_BOUNCED = 'bounced';
    public const STATUS_REJECTED = 'rejected';
    public const STATUS_RATE_LIMITED = 'rate_limited';

    // Error type constants
    public const ERROR_SMTP = 'smtp';
    public const ERROR_DNS = 'dns';
    public const ERROR_CONNECTION = 'connection';
    public const ERROR_AUTHENTICATION = 'authentication';
    public const ERROR_RATE_LIMIT = 'rate_limit';
    public const ERROR_VALIDATION = 'validation';

    /**
     * Get the worker that processed this email.
     */
    public function worker()
    {
        return $this->belongsTo(Worker::class);
    }

    /**
     * Get the campaign this email belongs to.
     */
    public function campaign()
    {
        return $this->belongsTo(Campaign::class);
    }

    /**
     * Scope a query to only include successful sends.
     */
    public function scopeSuccessful($query)
    {
        return $query->where('status', self::STATUS_SENT);
    }

    /**
     * Scope a query to only include failed sends.
     */
    public function scopeFailed($query)
    {
        return $query->whereIn('status', [
            self::STATUS_FAILED,
            self::STATUS_BOUNCED,
            self::STATUS_REJECTED
        ]);
    }

    /**
     * Scope a query to only include rate-limited sends.
     */
    public function scopeRateLimited($query)
    {
        return $query->where('status', self::STATUS_RATE_LIMITED);
    }

    /**
     * Get the delivery status badge class.
     */
    public function getStatusBadgeClass()
    {
        return match($this->status) {
            self::STATUS_SENT => 'bg-green-100 text-green-800',
            self::STATUS_FAILED => 'bg-red-100 text-red-800',
            self::STATUS_BOUNCED => 'bg-yellow-100 text-yellow-800',
            self::STATUS_REJECTED => 'bg-orange-100 text-orange-800',
            self::STATUS_RATE_LIMITED => 'bg-purple-100 text-purple-800',
            default => 'bg-gray-100 text-gray-800'
        };
    }
}
