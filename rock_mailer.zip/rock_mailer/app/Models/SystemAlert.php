<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SystemAlert extends Model
{
    protected $fillable = [
        'type',
        'severity',
        'message',
        'context',
        'status',
        'resolved_at'
    ];

    protected $casts = [
        'context' => 'array',
        'resolved_at' => 'datetime'
    ];

    public function scopeUnresolved($query)
    {
        return $query->whereNull('resolved_at');
    }

    public function resolve()
    {
        $this->update([
            'status' => 'resolved',
            'resolved_at' => now()
        ]);
    }
}
