<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Support\Str;

class WorkerNode extends Model
{
    use HasFactory, HasUuids;

    // Worker status constants
    public const STATUS_INITIALIZING = 'initializing';
    public const STATUS_READY = 'ready';
    public const STATUS_ACTIVE = 'active';
    public const STATUS_ERROR = 'error';
    public const STATUS_OFFLINE = 'offline';

    protected $primaryKey = 'id';

    protected $keyType = 'string';

    public $incrementing = false;

    /**
     * Boot the model.
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->node_id = $model->id ?? (string) Str::uuid();
        });
    }

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'node_id',
        'hostname',
        'ip_address',
        'ssh_key_path',
        'ssh_password',
        'auth_type',
        'auth_token',
        'capacity',
        'status',
        'ssh_port',
        'ssh_user',
        'max_concurrent_jobs',
        'capabilities',
        'current_load',
        'last_heartbeat_at',
        'last_health_check',
        'last_error',
        'memory_usage',
        'total_emails_sent',
        'cpu_usage',
        'success_rate',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'auth_token',
        'ssh_key_path',
        'ssh_password',
    ];

    protected $casts = [
        'last_heartbeat_at' => 'datetime',
        'last_health_check' => 'datetime',
        'capabilities' => 'array',
        'current_load' => 'integer',
        'capacity' => 'integer',
        'ssh_port' => 'integer',
        'max_concurrent_jobs' => 'integer',
    ];

    /**
     * Get all performance logs for this worker
     */
    public function performanceLogs()
    {
        return $this->hasMany(WorkerPerformanceLog::class);
    }

    /**
     * Get all email batches currently assigned to this worker
     */
    public function emailBatches()
    {
        return $this->hasMany(EmailBatch::class);
    }

    /**
     * Check if the worker is healthy based on its status and last health check
     *
     * @return bool
     */
    public function isHealthy(): bool
    {
        return $this->status === 'ready' && 
               $this->last_health_check && 
               now()->subMinutes(5)->lte($this->last_health_check) &&
               $this->current_load < $this->capacity;
    }

    /**
     * Check if the worker is currently active
     */
    public function isActive()
    {
        return $this->status === 'active' && 
               $this->last_heartbeat_at && 
               $this->last_heartbeat_at->diffInMinutes(now()) < 5;
    }

    /**
     * Check if the worker has available capacity
     */
    public function hasAvailableCapacity()
    {
        return $this->current_load < $this->max_concurrent_jobs;
    }

    /**
     * Get the worker's current availability percentage
     */
    public function getAvailabilityPercentage()
    {
        if ($this->max_concurrent_jobs === 0) {
            return 0;
        }
        
        return (($this->max_concurrent_jobs - $this->current_load) / $this->max_concurrent_jobs) * 100;
    }

    /**
     * Update worker status
     *
     * @param string $status
     * @return bool
     */
    public function updateStatus(string $status): bool
    {
        $validStatuses = [
            self::STATUS_INITIALIZING,
            self::STATUS_READY,
            self::STATUS_ACTIVE,
            self::STATUS_ERROR,
            self::STATUS_OFFLINE
        ];
        
        if (!in_array($status, $validStatuses)) {
            throw new \InvalidArgumentException("Invalid status: {$status}");
        }

        $this->status = $status;
        $this->save();

        return true;
    }

    /**
     * Record health check
     *
     * @return void
     */
    public function recordHealthCheck(): void
    {
        $this->last_health_check = now();
        $this->save();
    }

    /**
     * Record heartbeat
     *
     * @return void
     */
    public function recordHeartbeat(): void
    {
        $this->last_heartbeat_at = now();
        $this->save();
    }

    /**
     * Check if the worker node is healthy based on status and last heartbeat
     *
     * @return bool
     */
    public function isHealthyNode()
    {
        if (!$this->last_heartbeat_at) {
            return false;
        }

        // Consider node unhealthy if no heartbeat in last 2 minutes
        $heartbeatThreshold = now()->subMinutes(2);
        return $this->last_heartbeat_at->gt($heartbeatThreshold);
    }
}
