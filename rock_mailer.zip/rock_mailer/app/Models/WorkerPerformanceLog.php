<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WorkerPerformanceLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'worker_id',
        'memory_usage',
        'memory_peak',
        'cpu_usage',
        'load_average',
        'queue_size',
        'processed_count',
        'processing_speed',
        'postfix_queue_size',
        'active_campaigns',
        'metadata'
    ];

    protected $casts = [
        'memory_usage' => 'float',
        'memory_peak' => 'float',
        'cpu_usage' => 'float',
        'load_average' => 'array',
        'queue_size' => 'integer',
        'processed_count' => 'integer',
        'processing_speed' => 'float',
        'postfix_queue_size' => 'integer',
        'active_campaigns' => 'integer',
        'metadata' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime'
    ];

    /**
     * Get the worker that this performance log belongs to.
     */
    public function worker()
    {
        return $this->belongsTo(WorkerNode::class, 'worker_id');
    }

    /**
     * Get memory usage in formatted string.
     */
    public function getFormattedMemoryUsage()
    {
        return $this->formatBytes($this->memory_usage);
    }

    /**
     * Get peak memory usage in formatted string.
     */
    public function getFormattedMemoryPeak()
    {
        return $this->formatBytes($this->memory_peak);
    }

    /**
     * Get processing speed in formatted string (emails per minute).
     */
    public function getFormattedProcessingSpeed()
    {
        return number_format($this->processing_speed, 1) . ' emails/min';
    }

    /**
     * Format bytes to human readable string.
     */
    protected function formatBytes($bytes)
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= pow(1024, $pow);

        return round($bytes, 2) . ' ' . $units[$pow];
    }

    /**
     * Scope a query to only include recent logs.
     */
    public function scopeRecent($query, $minutes = 60)
    {
        return $query->where('created_at', '>=', now()->subMinutes($minutes));
    }

    /**
     * Scope a query to get hourly averages.
     */
    public function scopeHourlyAverages($query)
    {
        return $query->selectRaw('
            DATE_FORMAT(created_at, "%Y-%m-%d %H:00:00") as hour,
            AVG(memory_usage) as avg_memory_usage,
            AVG(cpu_usage) as avg_cpu_usage,
            AVG(queue_size) as avg_queue_size,
            AVG(processing_speed) as avg_processing_speed
        ')
        ->groupBy('hour')
        ->orderBy('hour');
    }
}
