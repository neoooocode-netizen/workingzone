<?php

namespace App\Services;

use App\Models\SystemAlert;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Notification;
use App\Events\SystemMetricsUpdated;

class AlertService
{
    protected $thresholds = [
        'worker_health' => 80,
        'queue_size' => 1000,
        'error_rate' => 5,
        'memory_usage' => 90
    ];

    public function checkWorkerHealth($worker)
    {
        if ($worker->health < $this->thresholds['worker_health']) {
            $this->createAlert('worker', 'warning', "Worker {$worker->node_id} health below threshold", [
                'worker_id' => $worker->node_id,
                'health' => $worker->health,
                'threshold' => $this->thresholds['worker_health']
            ]);
        }
    }

    public function checkQueueHealth($queueSize, $queueName)
    {
        if ($queueSize > $this->thresholds['queue_size']) {
            $this->createAlert('queue', 'warning', "Queue {$queueName} size exceeds threshold", [
                'queue' => $queueName,
                'size' => $queueSize,
                'threshold' => $this->thresholds['queue_size']
            ]);
        }
    }

    public function checkCampaignHealth($campaign)
    {
        $errorRate = $campaign->error_count / max(1, $campaign->total_processed) * 100;
        
        if ($errorRate > $this->thresholds['error_rate']) {
            $this->createAlert('campaign', 'error', "Campaign {$campaign->id} error rate exceeds threshold", [
                'campaign_id' => $campaign->id,
                'error_rate' => $errorRate,
                'threshold' => $this->thresholds['error_rate']
            ]);
        }
    }

    public function checkSystemResources()
    {
        $memoryUsage = memory_get_usage(true) / 1024 / 1024;
        $memoryLimit = ini_get('memory_limit');
        
        if ($memoryUsage > $this->thresholds['memory_usage']) {
            $this->createAlert('system', 'critical', 'System memory usage exceeds threshold', [
                'usage' => $memoryUsage,
                'limit' => $memoryLimit,
                'threshold' => $this->thresholds['memory_usage']
            ]);
        }
    }

    protected function createAlert($type, $severity, $message, array $context)
    {
        // Check if similar alert exists
        $existingAlert = SystemAlert::unresolved()
            ->where('type', $type)
            ->where('message', $message)
            ->first();

        if (!$existingAlert) {
            $alert = SystemAlert::create([
                'type' => $type,
                'severity' => $severity,
                'message' => $message,
                'context' => $context,
                'status' => 'active'
            ]);

            // Log the alert
            Log::channel('alerts')->{$severity}($message, $context);

            // Broadcast metrics update
            event(new SystemMetricsUpdated([
                'alerts' => SystemAlert::unresolved()->count(),
                'latest_alert' => [
                    'type' => $type,
                    'message' => $message,
                    'severity' => $severity
                ]
            ]));

            return $alert;
        }

        return $existingAlert;
    }

    public function setThresholds(array $thresholds)
    {
        $this->thresholds = array_merge($this->thresholds, $thresholds);
    }
}
