<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Exception;

class BatchProcessor
{
    protected $apiUrl;
    protected $authToken;
    protected $mailer;
    protected $currentBatch;

    /**
     * Initialize batch processor
     *
     * @param string $apiUrl
     * @param string $authToken
     * @param WorkerMailer $mailer
     */
    public function __construct(string $apiUrl, string $authToken, WorkerMailer $mailer)
    {
        $this->apiUrl = rtrim($apiUrl, '/');
        $this->authToken = $authToken;
        $this->mailer = $mailer;
    }

    /**
     * Start processing batches
     *
     * @return void
     */
    public function start(): void
    {
        while (true) {
            try {
                // Get next batch
                $batch = $this->getNextBatch();
                
                if (!$batch) {
                    // No batch available, wait before retrying
                    Log::info('No batch available, waiting...');
                    sleep(10);
                    continue;
                }

                $this->currentBatch = $batch;
                Log::info('Processing batch', ['batch_id' => $batch['batch_id']]);

                // Process the batch
                $result = $this->mailer->processBatch(
                    $batch['recipients'],
                    $batch['email_data']
                );

                // Update batch status
                $this->updateBatchStatus($batch['batch_id'], array_merge(
                    ['status' => 'completed'],
                    $result
                ));

                Log::info('Batch completed', [
                    'batch_id' => $batch['batch_id'],
                    'stats' => $result
                ]);

            } catch (Exception $e) {
                Log::error('Batch processing error', [
                    'error' => $e->getMessage(),
                    'batch_id' => $this->currentBatch['batch_id'] ?? null
                ]);

                if (isset($this->currentBatch)) {
                    // Mark batch as failed
                    $this->updateBatchStatus($this->currentBatch['batch_id'], [
                        'status' => 'failed',
                        'error_logs' => [[
                            'error' => $e->getMessage(),
                            'timestamp' => now()
                        ]]
                    ]);
                }

                // Wait before retrying
                sleep(5);
            }
        }
    }

    /**
     * Get next available batch
     *
     * @return array|null
     */
    protected function getNextBatch(): ?array
    {
        try {
            $response = Http::withToken($this->authToken)
                ->get("{$this->apiUrl}/api/batches/next");

            if ($response->successful()) {
                $data = $response->json();
                return $data['data'] ?? null;
            }

            Log::warning('Failed to get next batch', [
                'status' => $response->status(),
                'response' => $response->json()
            ]);

            return null;

        } catch (Exception $e) {
            Log::error('Error getting next batch', [
                'error' => $e->getMessage()
            ]);
            return null;
        }
    }

    /**
     * Update batch processing status
     *
     * @param string $batchId
     * @param array $data
     * @return bool
     */
    protected function updateBatchStatus(string $batchId, array $data): bool
    {
        try {
            $response = Http::withToken($this->authToken)
                ->post("{$this->apiUrl}/api/batches/{$batchId}/update", $data);

            if ($response->successful()) {
                return true;
            }

            Log::warning('Failed to update batch status', [
                'batch_id' => $batchId,
                'status' => $response->status(),
                'response' => $response->json()
            ]);

            return false;

        } catch (Exception $e) {
            Log::error('Error updating batch status', [
                'batch_id' => $batchId,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * Stop batch processing
     *
     * @return void
     */
    public function stop(): void
    {
        // If there's a batch in progress, mark it as failed
        if (isset($this->currentBatch)) {
            $this->updateBatchStatus($this->currentBatch['batch_id'], [
                'status' => 'failed',
                'error_logs' => [[
                    'error' => 'Batch processing stopped',
                    'timestamp' => now()
                ]]
            ]);
        }

        exit(0);
    }
}
