<?php

namespace App\Services;

use App\Models\Worker;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class DebugCommandService
{
    /**
     * Force a worker to refresh its status.
     */
    public function forceWorkerStatusRefresh(Worker $worker): array
    {
        try {
            $response = Http::timeout(5)->post($worker->api_url . '/debug/refresh-status');
            
            if ($response->successful()) {
                Cache::tags(['worker', 'status'])->forget("worker:{$worker->id}:status");
                return [
                    'success' => true,
                    'message' => 'Worker status refreshed successfully',
                    'data' => $response->json()
                ];
            }

            return [
                'success' => false,
                'message' => 'Failed to refresh worker status',
                'error' => $response->body()
            ];
        } catch (\Exception $e) {
            Log::error('Worker status refresh failed', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => 'Worker status refresh failed',
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * View the current queue of a worker.
     */
    public function viewWorkerQueue(Worker $worker): array
    {
        try {
            $response = Http::timeout(5)->get($worker->api_url . '/debug/queue');
            
            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'Worker queue retrieved successfully',
                    'data' => $response->json()
                ];
            }

            return [
                'success' => false,
                'message' => 'Failed to retrieve worker queue',
                'error' => $response->body()
            ];
        } catch (\Exception $e) {
            Log::error('Worker queue retrieval failed', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => 'Worker queue retrieval failed',
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Test connectivity to a worker.
     */
    public function testWorkerConnectivity(Worker $worker): array
    {
        try {
            $startTime = microtime(true);
            $response = Http::timeout(5)->get($worker->api_url . '/debug/ping');
            $latency = round((microtime(true) - $startTime) * 1000, 2);
            
            if ($response->successful()) {
                return [
                    'success' => true,
                    'message' => 'Worker connectivity test successful',
                    'data' => [
                        'latency' => $latency,
                        'status' => $response->json()
                    ]
                ];
            }

            return [
                'success' => false,
                'message' => 'Worker connectivity test failed',
                'error' => $response->body()
            ];
        } catch (\Exception $e) {
            Log::error('Worker connectivity test failed', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => 'Worker connectivity test failed',
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Check Postfix status on a worker.
     */
    public function checkPostfixStatus(Worker $worker): array
    {
        try {
            $response = Http::timeout(5)->get($worker->api_url . '/debug/postfix-status');
            
            if ($response->successful()) {
                $status = $response->json();
                return [
                    'success' => true,
                    'message' => 'Postfix status retrieved successfully',
                    'data' => [
                        'active' => $status['active'] ?? false,
                        'queue_size' => $status['queue_size'] ?? 0,
                        'processes' => $status['processes'] ?? [],
                        'last_error' => $status['last_error'] ?? null,
                        'metrics' => $status['metrics'] ?? []
                    ]
                ];
            }

            return [
                'success' => false,
                'message' => 'Failed to retrieve Postfix status',
                'error' => $response->body()
            ];
        } catch (\Exception $e) {
            Log::error('Postfix status check failed', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);

            return [
                'success' => false,
                'message' => 'Postfix status check failed',
                'error' => $e->getMessage()
            ];
        }
    }
}
