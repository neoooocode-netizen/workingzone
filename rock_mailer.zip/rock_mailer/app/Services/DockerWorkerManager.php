<?php

namespace App\Services;

use App\Models\WorkerNode;
use Illuminate\Support\Facades\Log;
use phpseclib3\Net\SSH2;
use phpseclib3\Crypt\PublicKeyLoader;
use App\Services\WorkerFileManager;

class DockerWorkerManager
{
    protected $fileManager;

    public function __construct(WorkerFileManager $fileManager)
    {
        $this->fileManager = $fileManager;
    }

    /**
     * Execute a command on a worker node via SSH
     *
     * @param WorkerNode $worker
     * @param string $command
     * @param bool $forceSuccess
     */
    public function executeCommand(WorkerNode $worker, string $command, bool $forceSuccess = false): array
    {
        try {
            Log::debug('Executing command on worker', [
                'worker_id' => $worker->id,
                'command' => $command
            ]);

            $ssh = $this->getSSHConnection($worker);
            if (!$ssh) {
                return [
                    'success' => false,
                    'output' => '',
                    'error' => 'Failed to establish SSH connection'
                ];
            }

            Log::info('Executing SSH command', [
                'worker_id' => $worker->id,
                'command' => $command
            ]);

            // Execute command and capture both stdout and stderr
            $ssh->enableQuietMode();
            $output = '';
            $error = '';

            // Execute command and capture output
            $success = $ssh->exec($command, function($str) use (&$output) {
                $output .= $str;
            });
            
            // Get any error output
            $error = $ssh->getStdError();

            // Convert boolean success to proper exit code
            $exitCode = $success ? 0 : 1;

            Log::debug('Command execution completed', [
                'worker_id' => $worker->id,
                'command' => $command,
                'exit_code' => $exitCode,
                'output' => $output,
                'error' => $error
            ]);

            if ($exitCode !== 0) {
                Log::warning('Command completed with non-zero exit code', [
                    'worker_id' => $worker->id,
                    'command' => $command,
                    'exit_code' => $exitCode,
                    'output' => $output,
                    'error' => $error
                ]);
            }

            return [
                'success' => $forceSuccess ? true : ($exitCode === 0),
                'output' => $output,
                'error' => $error,
                'exit_code' => $exitCode
            ];

        } catch (\Exception $e) {
            Log::error('SSH command execution failed', [
                'command' => $command,
                'error' => $e->getMessage(),
                'worker_id' => $worker->id
            ]);

            return [
                'success' => false,
                'output' => '',
                'error' => $e->getMessage(),
                'exit_code' => -1
            ];
        }
    }

    /**
     * Store SSH key file
     *
     * @param string $path
     * @param string $content
     * @return bool
     */
    public function storeKeyFile(string $path, string $content): bool
    {
        try {
            file_put_contents($path, $content);
            chmod($path, 0600);
            return true;
        } catch (\Exception $e) {
            Log::error('Failed to store SSH key file', [
                'path' => $path,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * Monitor worker health
     *
     * @param WorkerNode $worker
     * @return bool
     */
    public function checkHealth(WorkerNode $worker): bool
    {
        try {
            $result = $this->executeCommand($worker, 'docker ps');
            return $result['success'];
        } catch (\Exception $e) {
            Log::error('Health check failed', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * Check if Docker is installed
     *
     * @param WorkerNode $worker
     * @return bool
     */
    public function checkDockerInstallation(WorkerNode $worker): bool
    {
        try {
            Log::info('Checking Docker installation', [
                'worker_id' => $worker->id
            ]);

            // Check if Docker is running
            $result = $this->executeCommand($worker, 'systemctl status docker');
            if (!$result['success'] && strpos($result['output'], 'Active: active') === false) {
                Log::info('Docker service not running, starting it', [
                    'worker_id' => $worker->id
                ]);
                
                // Try to start Docker service
                $this->executeCommand($worker, 'sudo systemctl start docker');
                
                // Check again
                $result = $this->executeCommand($worker, 'systemctl status docker');
                if (!$result['success'] && strpos($result['output'], 'Active: active') === false) {
                    Log::error('Failed to start Docker service', [
                        'worker_id' => $worker->id,
                        'error' => $result['error']
                    ]);
                    return false;
                }
            }

            // Verify Docker is working
            $result = $this->executeCommand($worker, 'docker info');
            if (!$result['success']) {
                Log::error('Docker is not functioning properly', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            // Check Docker Compose
            $composeResult = $this->executeCommand($worker, 'docker compose version');
            if (!$composeResult['success']) {
                Log::info('Installing Docker Compose V2 plugin', [
                    'worker_id' => $worker->id
                ]);

                // Install Docker Compose plugin through package manager
                $result = $this->executeCommand($worker, 'yum install -y docker-compose-plugin');
                if (!$result['success']) {
                    Log::warning('Failed to install Docker Compose via package manager, trying manual installation', [
                        'worker_id' => $worker->id,
                        'error' => $result['error']
                    ]);

                    // Manual installation as fallback
                    $result = $this->executeCommand($worker, 'mkdir -p /usr/local/lib/docker/cli-plugins');
                    if (!$result['success']) {
                        throw new \Exception('Failed to create Docker plugin directory: ' . ($result['error'] ?? 'Unknown error'));
                    }

                    // Download Docker Compose plugin
                    $result = $this->executeCommand($worker, 'curl -SL "https://github.com/docker/compose/releases/download/v2.20.3/docker-compose-linux-x86_64" -o /usr/local/lib/docker/cli-plugins/docker-compose');
                    if (!$result['success']) {
                        throw new \Exception('Failed to download Docker Compose plugin: ' . ($result['error'] ?? 'Unknown error'));
                    }

                    // Make it executable
                    $result = $this->executeCommand($worker, 'chmod +x /usr/local/lib/docker/cli-plugins/docker-compose');
                    if (!$result['success']) {
                        throw new \Exception('Failed to make Docker Compose plugin executable: ' . ($result['error'] ?? 'Unknown error'));
                    }
                }

                // Verify Docker Compose installation
                $verifyResult = $this->executeCommand($worker, 'docker compose version');
                if (!$verifyResult['success']) {
                    throw new \Exception('Docker Compose V2 installation verification failed: ' . ($verifyResult['error'] ?? 'Unknown error'));
                }

                Log::info('Docker Compose V2 installation completed', [
                    'worker_id' => $worker->id
                ]);
            }

            return true;
        } catch (\Exception $e) {
            Log::error('Docker installation check failed', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * Install Docker on a worker node
     *
     * @param WorkerNode $worker
     * @return bool
     */
    public function installDocker(WorkerNode $worker): bool
{
    try {
        Log::info('Starting Docker installation process', [
            'worker_id' => $worker->id,
            'hostname' => $worker->hostname
        ]);

        // Check if Docker is already installed
        $result = $this->executeCommand($worker, 'docker --version');
        if ($result['success'] && !empty($result['output'])) {
            Log::info('Docker is already installed', [
                'worker_id' => $worker->id,
                'version' => trim($result['output'])
            ]);
            return true;
        }

        Log::info('Docker not found, proceeding with installation', [
            'worker_id' => $worker->id
        ]);

         // Execute Docker installation commands in sequence
        $commands = [
            'yum update -y',
            'yum install -y yum-utils device-mapper-persistent-data lvm2', 
            'curl -fsSL https://download.docker.com/linux/centos/gpg | sudo tee /etc/pki/rpm-gpg/docker-gpg', 
            'yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo', 
            'yum install -y docker-ce docker-ce-cli containerd.io', 
            'curl -L "https://github.com/docker/compose/releases/download/v2.20.3/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose', 
            'chmod +x /usr/local/bin/docker-compose', 
            'docker --version', 
            'docker compose version'
        ];

        foreach ($commands as $command) {
            Log::debug('Executing command', [
                'worker_id' => $worker->id,
                'command' => $command
            ]);

            $result = $this->executeCommand($worker, $command);
            sleep(5);
            if (!$result['success']) {
                // Special handling for systemctl status, as it might return non-zero even when Docker is running
                // if ($command === 'sudo systemctl status docker' && str_contains($result['output'], 'active (running)')) {
                //     continue;
                // }

                Log::error('Command failed', [
                    'worker_id' => $worker->id,
                    'command' => $command,
                    'error' => $result['error']
                ]);
                throw new \Exception("Failed to execute command '$command': " . ($result['error'] ?? 'Unknown error'));
            }

            //For systemctl status, verify Docker is actually running
            // if ($command === 'sudo systemctl status docker' && !str_contains($result['output'], 'active (running)')) {
            //     throw new \Exception('Docker service is not running after installation');
            // }
        }

        // Verify Docker installation
        $result = $this->executeCommand($worker, 'docker --version');
        if (!$result['success'] || empty($result['output'])) {
            throw new \Exception('Docker installation verification failed');
        }

        // Verify Docker Compose installation
        $result = $this->executeCommand($worker, 'docker compose version');
        if (!$result['success'] || empty($result['output'])) {
            throw new \Exception('Docker Compose installation verification failed');
        }

        Log::info('Docker installation completed successfully', [
            'worker_id' => $worker->id
        ]);
        return true;

    } catch (\Exception $e) {
        Log::error('Docker installation failed', [
            'error' => $e->getMessage(),
            'worker_id' => $worker->id,
            'trace' => $e->getTraceAsString()
        ]);
        return false;
    }
}

    /**
     * Install PHP 8.2 on the worker node
     *
     * @param WorkerNode $worker
     * @return bool
     */
    public function installPhp(WorkerNode $worker): bool
    {
        try {
            Log::info('Starting PHP installation', [
                'worker_id' => $worker->id,
                'hostname' => $worker->hostname
            ]);

            // Install EPEL and Remi repository for CentOS 7
            $this->executeCommand($worker, 'yum install -y epel-release');
            $this->executeCommand($worker, 'yum install -y http://rpms.remirepo.net/enterprise/remi-release-7.rpm');
            
            // Enable Remi PHP 8.2 repository
            $this->executeCommand($worker, 'yum-config-manager --enable remi-php82');

            // Install PHP 8.2 and required extensions
            $result = $this->executeCommand($worker, 'yum install -y php82 php82-php-fpm php82-php-cli php82-php-common php82-php-json php82-php-mysqlnd php82-php-zip php82-php-gd php82-php-mbstring php82-php-curl php82-php-xml php82-php-bcmath php82-php-intl');
            
            if (!$result['success']) {
                Log::error('Failed to install PHP packages', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            // Create symbolic links for PHP 8.2
            $this->executeCommand($worker, 'ln -sf /usr/bin/php82 /usr/bin/php');
            
            // Install Composer
            $composerInstall = $this->executeCommand($worker, 'curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer');
            if (!$composerInstall['success']) {
                Log::error('Failed to install Composer', [
                    'worker_id' => $worker->id,
                    'error' => $composerInstall['error']
                ]);
                return false;
            }

            // Verify PHP installation
            $phpVersion = $this->executeCommand($worker, 'php -v');
            $composerVersion = $this->executeCommand($worker, 'composer --version');

            Log::info('PHP installation completed', [
                'worker_id' => $worker->id,
                'php_version' => $phpVersion['output'] ?? 'Unknown',
                'composer_version' => $composerVersion['output'] ?? 'Unknown'
            ]);

            return true;

        } catch (\Exception $e) {
            Log::error('PHP installation failed', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return false;
        }
    }

    /**
     * Pull required Docker images
     *
     * @param WorkerNode $worker
     * @return bool
     */
    public function pullImages(WorkerNode $worker): bool
    {
        try {
            // First verify Docker is running
            $result = $this->executeCommand($worker, 'systemctl status docker');
            if (!$result['success'] || strpos($result['output'], 'Active: active') === false) {
                Log::info('Docker not running, attempting to start...', ['worker_id' => $worker->id]);
                $result = $this->executeCommand($worker, 'sudo systemctl restart docker');
                if (!$result['success']) {
                    Log::error('Failed to restart Docker service', [
                        'worker_id' => $worker->id,
                        'error' => $result['error']
                    ]);
                    return false;
                }
                sleep(10);
            }

            // Configure Docker daemon with appropriate settings
            $dockerConfig = [
                'log-driver' => 'json-file',
                'log-opts' => [
                    'max-size' => '100m',
                    'max-file' => '3'
                ],
                'storage-driver' => 'overlay2',
                'iptables' => true,
                'selinux-enabled' => true,
                'registry-mirrors' => [
                    'https://registry-1.docker.io',
                    'https://mirror.gcr.io'
                ]
            ];

            $configJson = json_encode($dockerConfig, JSON_PRETTY_PRINT);
            $this->executeCommand($worker, "mkdir -p /etc/docker");
            $this->executeCommand($worker, "echo '$configJson' | sudo tee /etc/docker/daemon.json");
            $this->executeCommand($worker, "sudo systemctl restart docker");
            sleep(10); // Give more time for Docker to restart

            // Ensure Docker is properly running after config change
            $result = $this->executeCommand($worker, 'docker info');
            if (!$result['success']) {
                Log::error('Docker not responding after configuration change', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            // Pull required images with proper error handling
            $images = [
                'php:8.2-cli',
                'redis:latest',
                'mysql:8.0'
            ];

            foreach ($images as $image) {
                Log::info("Starting to pull Docker image: $image", ['worker_id' => $worker->id]);
                
                // Simple pull with retry logic
                $maxRetries = 3;
                $retryCount = 0;
                $pullSuccess = false;

                while (!$pullSuccess && $retryCount < $maxRetries) {
                    $result = $this->executeCommand($worker, "docker pull $image");
                    
                    if ($result['success']) {
                        Log::info("Successfully pulled image: $image", [
                            'worker_id' => $worker->id,
                            'attempt' => $retryCount + 1
                        ]);
                        $pullSuccess = true;
                        break;
                    }
                    
                    $retryCount++;
                    if ($retryCount < $maxRetries) {
                        Log::warning("Retry $retryCount for image: $image", [
                            'worker_id' => $worker->id,
                            'error' => $result['error'] ?? 'Unknown error'
                        ]);
                        sleep(5); // Simple delay between retries
                    }
                }

                if (!$pullSuccess) {
                    Log::error("Failed to pull Docker image after $maxRetries attempts: $image", [
                        'worker_id' => $worker->id,
                        'last_error' => $result['error'] ?? 'Unknown error'
                    ]);
                    return false;
                }
            }

            return true;
        } catch (\Exception $e) {
            Log::error('Failed to pull Docker images', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return false;
        }
    }

    /**
     * Restart worker containers
     *
     * @param WorkerNode $worker
     * @return bool
     */
    public function restartContainers(WorkerNode $worker): bool
    {
        try {
            // Verify Docker Compose is installed
            $result = $this->executeCommand($worker, 'which docker');
            if (!$result['success']) {
                Log::error('Docker Compose not found', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            // Verify docker-compose.yml exists
            $result = $this->executeCommand($worker, 'test -f /root/app/docker-compose.yml && echo "exists"');
            if (!$result['success'] || trim($result['output']) !== 'exists') {
                Log::error('docker-compose.yml not found', [
                    'worker_id' => $worker->id
                ]);
                return false;
            }

            Log::info('Starting container management', [
                'worker_id' => $worker->id,
                'action' => 'restart'
            ]);

            // First stop any existing containers
            $result = $this->executeCommand($worker, 'cd /root/app && docker compose down --remove-orphans');
            if (!$result['success']) {
                Log::error('Failed to stop existing containers', [
                    'worker_id' => $worker->id,
                    'error' => $result['error'],
                    'output' => $result['output']
                ]);
                throw new \Exception('Failed to stop existing containers: ' . ($result['error'] ?? 'Unknown error'));
            }

            // Start containers
            $result = $this->executeCommand($worker, 'cd /root/app && docker compose up -d --build --force-recreate');
            if (!$result['success']) {
                Log::error('Failed to start containers', [
                    'worker_id' => $worker->id,
                    'error' => $result['error'],
                    'output' => $result['output']
                ]);
                throw new \Exception('Failed to start containers: ' . ($result['error'] ?? 'Unknown error'));
            }

            // Verify container is running
            sleep(5); // Give container a moment to start
            $result = $this->executeCommand($worker, "cd /root/app && docker compose ps");
            if (!$result['success']) {
                Log::error('Failed to check container status', [
                    'worker_id' => $worker->id,
                    'error' => $result['error'],
                    'output' => $result['output']
                ]);
                throw new \Exception('Failed to check container status: ' . ($result['error'] ?? 'Unknown error'));
            }

            if (!str_contains($result['output'], 'worker')) {
                Log::error('Worker container not found in running containers', [
                    'worker_id' => $worker->id,
                    'ps_output' => $result['output']
                ]);
                throw new \RuntimeException('Worker container failed to start. Logs: ' . 
                    $this->executeCommand($worker, "cd /root/app && docker compose logs")['output']);
            }

            // Check container logs for any startup errors
            $result = $this->executeCommand($worker, "cd /root/app && docker compose logs --tail=50");
            Log::info('Container startup logs', [
                'worker_id' => $worker->id,
                'logs' => $result['output']
            ]);

            if (strpos($result['output'], 'Error') !== false || strpos($result['output'], 'error') !== false) {
                Log::error('Container logs show errors', [
                    'worker_id' => $worker->id,
                    'logs' => $result['output']
                ]);
                return false;
            }

            Log::info('Containers started successfully', [
                'worker_id' => $worker->id
            ]);

            return true;
        } catch (\Exception $e) {
            Log::error('Failed to restart containers', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return false;
        }
    }

    /**
     * Deploy Docker configuration to worker node
     */
    public function deployDockerConfig(WorkerNode $worker): array
    {
        try {
            Log::info('Starting Docker configuration deployment', [
                'worker_id' => $worker->id
            ]);

            // Stop and remove any existing containers
            $this->executeCommand($worker, 'cd /root/app && docker compose down --volumes --remove-orphans 2>/dev/null || true');
            
            // Remove all existing Docker images to ensure clean state
            $this->executeCommand($worker, 'docker system prune -af --volumes 2>/dev/null || true');
            
            // Ensure clean app directory
            $this->executeCommand($worker, 'rm -rf /root/app/* 2>/dev/null || true');
            $this->executeCommand($worker, 'mkdir -p /root/app');

            // Write Dockerfile
            $dockerfileContent = $this->fileManager->generateDockerfile();
            $this->executeCommand($worker, "echo " . escapeshellarg($dockerfileContent) . " > /root/app/Dockerfile");

            // Write docker-compose.yml
            $dockerComposeContent = $this->fileManager->generateDockerCompose($worker, config('app.url'));
            $this->executeCommand($worker, "echo " . escapeshellarg($dockerComposeContent) . " > /root/app/docker-compose.yml");

            // Set proper permissions
            $this->executeCommand($worker, 'chmod -R 755 /root/app');

            // Build and start containers
            $result = $this->executeCommand($worker, "cd /root/app && docker compose up -d --build --force-recreate --remove-orphans");
            if (!$result['success']) {
                throw new \Exception('Failed to start containers: ' . ($result['error'] ?? 'Unknown error'));
            }

            // Check container status
            sleep(5); // Give container time to start
            $status = $this->executeCommand($worker, "cd /root/app && docker compose ps");
            if (!str_contains($status['output'], 'worker')) {
                throw new \Exception('Worker container failed to start. Logs: ' . 
                    $this->executeCommand($worker, "cd /root/app && docker compose logs")['output']);
            }

            Log::info('Docker configuration deployment completed', [
                'worker_id' => $worker->id
            ]);

            return $result;
        } catch (\Exception $e) {
            Log::error('Failed to deploy Docker configuration', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    /**
     * Remove Docker containers
     */
    public function removeDockerContainers(WorkerNode $worker): array
    {
        return $this->executeCommand($worker, "cd /root/app && docker compose down -v");
    }

    /**
     * Get worker status including Docker container status and metrics
     *
     * @param WorkerNode $worker
     * @return array
     */
    public function getWorkerStatus(WorkerNode $worker): array
    {
        try {
            $result = $this->executeCommand($worker, 'cd /root/app && docker compose ps -a --format "{{.Name}},{{.State}}"');
            
            if (!$result['success']) {
                Log::error('Failed to get worker status', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return [
                    'status' => 'error',
                    'container_status' => 'unknown',
                    'error' => $result['error']
                ];
            }

            // Get container metrics
            $metricsCmd = 'cd /root/app && docker stats --no-stream --format "{{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.NetIO}}"';
            $metrics = $this->executeCommand($worker, $metricsCmd);

            return [
                'status' => 'active',
                'container_status' => $this->parseDockerStatus($result['output']),
                'metrics' => $this->parseDockerMetrics($metrics['output'] ?? ''),
                'last_error' => $worker->last_error,
                'last_heartbeat' => $worker->last_heartbeat_at?->diffForHumans()
            ];
        } catch (\Exception $e) {
            Log::error('Error getting worker status', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);
            
            return [
                'status' => 'error',
                'container_status' => 'error',
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Parse Docker PS output
     */
    protected function parseDockerStatus(string $output): string
    {
        if (empty($output)) {
            return 'unknown';
        }

        try {
            $lines = explode("\n", trim($output));
            foreach ($lines as $line) {
                $parts = explode(",", $line);
                if (count($parts) === 2 && str_contains($parts[0], 'worker')) {
                    return strtolower(trim($parts[1]));
                }
            }

            return 'stopped';
        } catch (\Exception $e) {
            Log::error('Error parsing docker status', ['error' => $e->getMessage()]);
            return 'unknown';
        }
    }

    /**
     * Parse Docker stats output
     */
    protected function parseDockerMetrics(string $output): array
    {
        if (empty($output)) {
            return [
                'cpu' => '0%',
                'memory' => '0 MB / 0 MB',
                'network' => '0 B / 0 B'
            ];
        }

        try {
            $lines = explode("\n", trim($output));
            if (empty($lines)) {
                return [
                    'cpu' => '0%',
                    'memory' => '0 MB / 0 MB',
                    'network' => '0 B / 0 B'
                ];
            }

            $parts = explode("\t", $lines[0]);
            return [
                'cpu' => $parts[1] ?? '0%',
                'memory' => $parts[2] ?? '0 MB / 0 MB',
                'network' => $parts[3] ?? '0 B / 0 B'
            ];
        } catch (\Exception $e) {
            Log::error('Error parsing docker metrics', ['error' => $e->getMessage()]);
            return [
                'cpu' => '0%',
                'memory' => '0 MB / 0 MB',
                'network' => '0 B / 0 B'
            ];
        }
    }

    protected function getSSHConnection(WorkerNode $worker)
    {
        try {
            Log::debug('Attempting SSH connection', [
                'worker_id' => $worker->id,
                'hostname' => $worker->hostname,
                'port' => $worker->ssh_port,
                'user' => $worker->ssh_user,
                'auth_type' => $worker->auth_type
            ]);

            $ssh = new SSH2($worker->hostname, $worker->ssh_port);
            
            // Set timeout to 10 seconds
            $ssh->setTimeout(10);

            // Handle authentication based on auth_type
            if ($worker->auth_type === 'password') {
                if (empty($worker->ssh_password)) {
                    throw new \Exception('SSH password is required for password authentication');
                }

                Log::debug('Attempting password authentication', [
                    'worker_id' => $worker->id,
                    'user' => $worker->ssh_user
                ]);

                if (!$ssh->login($worker->ssh_user, $worker->ssh_password)) {
                    $error = $ssh->getStdError();
                    Log::error('Password authentication failed', [
                        'worker_id' => $worker->id,
                        'error' => $error
                    ]);
                    throw new \Exception('Password authentication failed: ' . ($error ?: 'Unknown error'));
                }

                Log::debug('Password authentication successful', [
                    'worker_id' => $worker->id
                ]);

            } else if ($worker->auth_type === 'key' && $worker->ssh_key_path) {
                if (!file_exists($worker->ssh_key_path)) {
                    throw new \Exception('SSH key file not found: ' . $worker->ssh_key_path);
                }

                Log::debug('Attempting key authentication', [
                    'worker_id' => $worker->id,
                    'key_path' => $worker->ssh_key_path
                ]);

                $key = PublicKeyLoader::load(file_get_contents($worker->ssh_key_path));
                if (!$ssh->login($worker->ssh_user, $key)) {
                    $error = $ssh->getStdError();
                    Log::error('Key authentication failed', [
                        'worker_id' => $worker->id,
                        'error' => $error
                    ]);
                    throw new \Exception('Key authentication failed: ' . ($error ?: 'Unknown error'));
                }

                Log::debug('Key authentication successful', [
                    'worker_id' => $worker->id
                ]);

            } else {
                throw new \Exception('No valid authentication method provided');
            }

            return $ssh;
        } catch (\Exception $e) {
            Log::error('Failed to establish SSH connection', [
                'worker_id' => $worker->id,
                'hostname' => $worker->hostname,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return null;
        }
    }
}
