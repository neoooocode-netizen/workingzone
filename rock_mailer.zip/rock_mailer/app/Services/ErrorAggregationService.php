<?php

namespace App\Services;

use App\Models\SystemLog;
use App\Models\EmailDeliveryLog;
use App\Models\Worker;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Collection;

class ErrorAggregationService
{
    // Error categories
    public const CATEGORY_CONNECTION = 'connection';
    public const CATEGORY_AUTHENTICATION = 'authentication';
    public const CATEGORY_DELIVERY = 'delivery';
    public const CATEGORY_RESOURCE = 'resource';

    /**
     * Get error statistics for a specific time period.
     */
    public function getErrorStats(
        ?Carbon $startDate = null,
        ?Carbon $endDate = null,
        ?int $workerId = null
    ): array {
        $startDate = $startDate ?? now()->subDay();
        $endDate = $endDate ?? now();

        return [
            'categories' => $this->getErrorsByCategory($startDate, $endDate, $workerId),
            'rates' => $this->getErrorRatesByWorker($startDate, $endDate, $workerId),
            'patterns' => $this->getCommonErrorPatterns($startDate, $endDate, $workerId),
            'trends' => $this->getErrorTrends($startDate, $endDate, $workerId),
        ];
    }

    /**
     * Get errors grouped by category.
     */
    public function getErrorsByCategory(Carbon $startDate, Carbon $endDate, ?int $workerId = null): array
    {
        $query = EmailDeliveryLog::where('status', '!=', EmailDeliveryLog::STATUS_SENT)
            ->whereBetween('created_at', [$startDate, $endDate]);

        if ($workerId) {
            $query->where('worker_id', $workerId);
        }

        $errors = $query->get();

        return [
            self::CATEGORY_CONNECTION => $errors->filter(function ($log) {
                return in_array($log->error_type, [
                    EmailDeliveryLog::ERROR_CONNECTION,
                    EmailDeliveryLog::ERROR_DNS
                ]);
            })->count(),
            
            self::CATEGORY_AUTHENTICATION => $errors->filter(function ($log) {
                return $log->error_type === EmailDeliveryLog::ERROR_AUTHENTICATION;
            })->count(),
            
            self::CATEGORY_DELIVERY => $errors->filter(function ($log) {
                return in_array($log->error_type, [
                    EmailDeliveryLog::ERROR_SMTP,
                    EmailDeliveryLog::ERROR_VALIDATION
                ]);
            })->count(),
            
            self::CATEGORY_RESOURCE => $errors->filter(function ($log) {
                return $log->error_type === EmailDeliveryLog::ERROR_RATE_LIMIT;
            })->count(),
        ];
    }

    /**
     * Get error rates per worker.
     */
    public function getErrorRatesByWorker(Carbon $startDate, Carbon $endDate, ?int $workerId = null): Collection
    {
        $query = Worker::query()
            ->select('workers.id', 'workers.name')
            ->selectRaw('COUNT(DISTINCT email_delivery_logs.id) as total_emails')
            ->selectRaw('COUNT(DISTINCT CASE WHEN email_delivery_logs.status != ? THEN email_delivery_logs.id END) as total_errors', [EmailDeliveryLog::STATUS_SENT])
            ->selectRaw('ROUND(COUNT(DISTINCT CASE WHEN email_delivery_logs.status != ? THEN email_delivery_logs.id END) * 100.0 / COUNT(DISTINCT email_delivery_logs.id), 2) as error_rate', [EmailDeliveryLog::STATUS_SENT])
            ->leftJoin('email_delivery_logs', 'workers.id', '=', 'email_delivery_logs.worker_id')
            ->whereBetween('email_delivery_logs.created_at', [$startDate, $endDate])
            ->groupBy('workers.id', 'workers.name');

        if ($workerId) {
            $query->where('workers.id', $workerId);
        }

        return $query->get();
    }

    /**
     * Get common error patterns.
     */
    public function getCommonErrorPatterns(Carbon $startDate, Carbon $endDate, ?int $workerId = null): Collection
    {
        $query = EmailDeliveryLog::select(
                'error_type',
                'error_message',
                DB::raw('COUNT(*) as occurrence_count')
            )
            ->where('status', '!=', EmailDeliveryLog::STATUS_SENT)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->groupBy('error_type', 'error_message')
            ->having('occurrence_count', '>', 1)
            ->orderByDesc('occurrence_count');

        if ($workerId) {
            $query->where('worker_id', $workerId);
        }

        return $query->get();
    }

    /**
     * Get error trends over time.
     */
    public function getErrorTrends(Carbon $startDate, Carbon $endDate, ?int $workerId = null): Collection
    {
        $query = EmailDeliveryLog::select(
                DB::raw('DATE_FORMAT(created_at, "%Y-%m-%d %H:00:00") as hour'),
                'error_type',
                DB::raw('COUNT(*) as error_count')
            )
            ->where('status', '!=', EmailDeliveryLog::STATUS_SENT)
            ->whereBetween('created_at', [$startDate, $endDate])
            ->groupBy('hour', 'error_type')
            ->orderBy('hour');

        if ($workerId) {
            $query->where('worker_id', $workerId);
        }

        return $query->get();
    }

    /**
     * Categorize an error based on its type and message.
     */
    public static function categorizeError(string $errorType, string $errorMessage): string
    {
        return match($errorType) {
            EmailDeliveryLog::ERROR_CONNECTION,
            EmailDeliveryLog::ERROR_DNS => self::CATEGORY_CONNECTION,
            
            EmailDeliveryLog::ERROR_AUTHENTICATION => self::CATEGORY_AUTHENTICATION,
            
            EmailDeliveryLog::ERROR_SMTP,
            EmailDeliveryLog::ERROR_VALIDATION => self::CATEGORY_DELIVERY,
            
            EmailDeliveryLog::ERROR_RATE_LIMIT => self::CATEGORY_RESOURCE,
            
            default => 'other'
        };
    }

    /**
     * Get error category description.
     */
    public static function getCategoryDescription(string $category): string
    {
        return match($category) {
            self::CATEGORY_CONNECTION => 'Network and DNS related errors',
            self::CATEGORY_AUTHENTICATION => 'SMTP authentication failures',
            self::CATEGORY_DELIVERY => 'Email delivery and validation errors',
            self::CATEGORY_RESOURCE => 'System resource and rate limit errors',
            default => 'Other errors'
        };
    }

    /**
     * Get error category badge class.
     */
    public static function getCategoryBadgeClass(string $category): string
    {
        return match($category) {
            self::CATEGORY_CONNECTION => 'bg-blue-100 text-blue-800',
            self::CATEGORY_AUTHENTICATION => 'bg-red-100 text-red-800',
            self::CATEGORY_DELIVERY => 'bg-yellow-100 text-yellow-800',
            self::CATEGORY_RESOURCE => 'bg-purple-100 text-purple-800',
            default => 'bg-gray-100 text-gray-800'
        };
    }
}
