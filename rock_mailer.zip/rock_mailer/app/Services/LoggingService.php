<?php

namespace App\Services;

use App\Models\SystemLog;
use Illuminate\Database\Eloquent\Model;

class LoggingService
{
    /**
     * Log a campaign-related event.
     */
    public function logCampaign(string $message, Model $campaign, string $level = SystemLog::LEVEL_INFO, array $context = [], ?Model $worker = null)
    {
        return $this->createLog(
            type: SystemLog::TYPE_CAMPAIGN,
            message: $message,
            level: $level,
            context: $context,
            loggable: $campaign,
            worker: $worker,
            campaign: $campaign
        );
    }

    /**
     * Log a worker-related event.
     */
    public function logWorker(string $message, Model $worker, string $level = SystemLog::LEVEL_INFO, array $context = [], ?Model $campaign = null)
    {
        return $this->createLog(
            type: SystemLog::TYPE_WORKER,
            message: $message,
            level: $level,
            context: $context,
            loggable: $worker,
            worker: $worker,
            campaign: $campaign
        );
    }

    /**
     * Log a queue-related event.
     */
    public function logQueue(string $message, string $level = SystemLog::LEVEL_INFO, array $context = [], ?Model $worker = null, ?Model $campaign = null)
    {
        return $this->createLog(
            type: SystemLog::TYPE_QUEUE,
            message: $message,
            level: $level,
            context: $context,
            worker: $worker,
            campaign: $campaign
        );
    }

    /**
     * Log a system-related event.
     */
    public function logSystem(string $message, string $level = SystemLog::LEVEL_INFO, array $context = [], ?Model $worker = null, ?Model $campaign = null)
    {
        return $this->createLog(
            type: SystemLog::TYPE_SYSTEM,
            message: $message,
            level: $level,
            context: $context,
            worker: $worker,
            campaign: $campaign
        );
    }

    /**
     * Create a new log entry.
     */
    private function createLog(
        string $type,
        string $message,
        string $level = SystemLog::LEVEL_INFO,
        array $context = [],
        ?Model $loggable = null,
        ?Model $worker = null,
        ?Model $campaign = null,
        array $metadata = []
    ): SystemLog {
        $metadata = array_merge($metadata, [
            'ip' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'request_id' => request()->id(),
            'session_id' => session()->getId(),
        ]);

        return SystemLog::create([
            'type' => $type,
            'level' => $level,
            'message' => $message,
            'context' => $context,
            'loggable_type' => $loggable ? get_class($loggable) : null,
            'loggable_id' => $loggable ? $loggable->id : null,
            'worker_id' => $worker?->id,
            'campaign_id' => $campaign?->id,
            'metadata' => $metadata,
        ]);
    }
}
