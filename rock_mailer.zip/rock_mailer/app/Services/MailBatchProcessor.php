<?php

namespace App\Services;

class MailBatchProcessor
{
    private $batchSize = 200;
    private $tempDir;
    private $logFile;
    private $progressFile;
    private $trackingId;

    public function __construct()
    {
        $this->tempDir = storage_path('temp');
        if (!file_exists($this->tempDir)) {
            mkdir($this->tempDir, 0777, true);
        }
        $this->trackingId = uniqid();
        $this->logFile = $this->tempDir . '/mail_log_' . $this->trackingId . '.txt';
        $this->progressFile = $this->tempDir . '/progress_' . $this->trackingId . '.json';
    }

    public function getTrackingId()
    {
        return $this->trackingId;
    }

    public function process($recipients, $emailData)
    {
        // Ensure no time limit for large batches
        set_time_limit(0);
        ini_set('max_execution_time', 0);
        
        $totalRecipients = count($recipients);
        $batches = array_chunk($recipients, $this->batchSize);
        
        // Start at 0%
        $this->updateProgress(0, $totalRecipients, 'processing', 0);
        
        $processedCount = 0;
        foreach ($batches as $batch) {
            $this->sendBatch($batch, $emailData);
            $processedCount += count($batch);
            
            // Free up memory after each batch
            gc_collect_cycles();
            
            // Give other processes a chance to run
            if ($processedCount % 1000 === 0) {
                usleep(100000); // 0.1s pause every 1000 emails
            }
        }
        
        // Complete - update to 100%
        $this->updateProgress($totalRecipients, $totalRecipients, 'completed', 100);
        return $this->trackingId;
    }

    private function sendBatch($recipients, $emailData)
    {
        foreach ($recipients as $recipient) {
            try {
                $headers = $emailData['headers'];
                $subject = $emailData['subject'];
                $message = $emailData['message'];
                $attachment = $emailData['attachment'] ?? null;

                $success = mail(
                    $recipient,
                    $subject,
                    $message,
                    implode("\r\n", $headers),
                    $attachment ? "-f " . $emailData['from'] : null
                );

                $status = $success ? "SUCCESS" : "FAILED";
                $this->log("[$status] Sent to: $recipient");
            } catch (\Exception $e) {
                $this->log("[ERROR] Failed to send to $recipient: " . $e->getMessage());
            }
        }
    }

    private function log($message)
    {
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($this->logFile, "[$timestamp] $message\n", FILE_APPEND);
    }

    private function updateProgress($processed, $total, $status, $percentage)
    {
        $progress = [
            'id' => $this->trackingId,
            'processed' => $processed,
            'total' => $total,
            'percentage' => $percentage,
            'status' => $status,
            'timestamp' => time()
        ];

        file_put_contents($this->progressFile, json_encode($progress));
    }

    public function getProgress()
    {
        return json_decode(file_get_contents($this->progressFile), true);
    }

    public function cleanup()
    {
        // Clean up files after 24 hours
        $files = glob($this->tempDir . '/*');
        foreach ($files as $file) {
            if (time() - filemtime($file) > 86400) {
                unlink($file);
            }
        }
    }
}
