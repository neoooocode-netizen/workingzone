<?php

namespace App\Services;

use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Log;
use Exception;

class QueueManager
{
    const HIGH_PRIORITY = 'high';
    const NORMAL_PRIORITY = 'normal';
    const LOW_PRIORITY = 'low';
    const DEAD_LETTER = 'dead';

    protected $prefix;
    protected $metrics;

    public function __construct()
    {
        $this->prefix = config('redis.options.prefix', 'rock_mailer_');
        $this->metrics = Redis::connection('queue');
    }

    /**
     * Push a job to queue with priority
     */
    public function push(string $queue, array $data, string $priority = self::NORMAL_PRIORITY): bool
    {
        try {
            $queueKey = $this->getQueueKey($queue, $priority);
            $this->metrics->rpush($queueKey, json_encode($data));
            $this->incrementMetric("queued:{$queue}:{$priority}");
            return true;
        } catch (Exception $e) {
            Log::error('Failed to push to queue', [
                'queue' => $queue,
                'priority' => $priority,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    /**
     * Pop a job from queue based on priority
     */
    public function pop(string $queue): ?array
    {
        foreach ([self::HIGH_PRIORITY, self::NORMAL_PRIORITY, self::LOW_PRIORITY] as $priority) {
            $queueKey = $this->getQueueKey($queue, $priority);
            $data = $this->metrics->lpop($queueKey);
            
            if ($data) {
                $this->incrementMetric("processed:{$queue}:{$priority}");
                return json_decode($data, true);
            }
        }
        
        return null;
    }

    /**
     * Move failed job to dead letter queue
     */
    public function moveToDeadLetter(string $queue, array $data, string $reason): void
    {
        $deadLetterData = array_merge($data, [
            'failed_at' => now(),
            'reason' => $reason
        ]);

        $deadLetterKey = $this->getQueueKey($queue, self::DEAD_LETTER);
        $this->metrics->rpush($deadLetterKey, json_encode($deadLetterData));
        $this->incrementMetric("dead_letter:{$queue}");
    }

    /**
     * Retry job from dead letter queue
     */
    public function retryDeadLetter(string $queue): bool
    {
        $deadLetterKey = $this->getQueueKey($queue, self::DEAD_LETTER);
        $data = $this->metrics->lpop($deadLetterKey);

        if (!$data) {
            return false;
        }

        $jobData = json_decode($data, true);
        unset($jobData['failed_at'], $jobData['reason']);
        
        return $this->push($queue, $jobData, self::NORMAL_PRIORITY);
    }

    /**
     * Get queue metrics
     */
    public function getMetrics(string $queue): array
    {
        $metrics = [];
        
        foreach ([self::HIGH_PRIORITY, self::NORMAL_PRIORITY, self::LOW_PRIORITY] as $priority) {
            $queueKey = $this->getQueueKey($queue, $priority);
            $metrics["queue_length:{$priority}"] = $this->metrics->llen($queueKey);
            $metrics["queued:{$priority}"] = $this->getMetricValue("queued:{$queue}:{$priority}");
            $metrics["processed:{$priority}"] = $this->getMetricValue("processed:{$queue}:{$priority}");
        }

        $deadLetterKey = $this->getQueueKey($queue, self::DEAD_LETTER);
        $metrics['dead_letter_count'] = $this->metrics->llen($deadLetterKey);
        
        return $metrics;
    }

    /**
     * Get performance stats
     */
    public function getPerformanceStats(string $queue): array
    {
        $stats = [];
        $total = 0;
        $processed = 0;

        foreach ([self::HIGH_PRIORITY, self::NORMAL_PRIORITY, self::LOW_PRIORITY] as $priority) {
            $queued = $this->getMetricValue("queued:{$queue}:{$priority}");
            $processedCount = $this->getMetricValue("processed:{$queue}:{$priority}");
            
            $total += $queued;
            $processed += $processedCount;
            
            $stats["throughput:{$priority}"] = $processedCount > 0 ? 
                ($queued / $processedCount) * 100 : 0;
        }

        $stats['total_throughput'] = $processed > 0 ? 
            ($total / $processed) * 100 : 0;
        
        return $stats;
    }

    /**
     * Clear metrics
     */
    public function clearMetrics(string $queue): void
    {
        foreach ([self::HIGH_PRIORITY, self::NORMAL_PRIORITY, self::LOW_PRIORITY] as $priority) {
            $this->metrics->del("queued:{$queue}:{$priority}");
            $this->metrics->del("processed:{$queue}:{$priority}");
        }
        $this->metrics->del("dead_letter:{$queue}");
    }

    protected function getQueueKey(string $queue, string $priority): string
    {
        return "{$this->prefix}queue:{$queue}:{$priority}";
    }

    protected function incrementMetric(string $key): void
    {
        $this->metrics->incr($key);
    }

    protected function getMetricValue(string $key): int
    {
        return (int) $this->metrics->get($key) ?? 0;
    }
}
