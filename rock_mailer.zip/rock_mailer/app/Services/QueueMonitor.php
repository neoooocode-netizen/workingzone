<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Exception;

class QueueMonitor
{
    protected $queueManager;
    protected $thresholds = [
        'queue_length' => 1000,
        'dead_letter' => 100,
        'throughput' => 80,
    ];

    public function __construct(QueueManager $queueManager)
    {
        $this->queueManager = $queueManager;
    }

    /**
     * Monitor queue health
     */
    public function checkHealth(string $queue): array
    {
        $metrics = $this->queueManager->getMetrics($queue);
        $stats = $this->queueManager->getPerformanceStats($queue);
        $alerts = [];

        // Check queue lengths
        foreach (['high', 'normal', 'low'] as $priority) {
            if ($metrics["queue_length:{$priority}"] > $this->thresholds['queue_length']) {
                $alerts[] = [
                    'level' => 'warning',
                    'message' => "Queue length for {$priority} priority exceeds threshold",
                    'value' => $metrics["queue_length:{$priority}"],
                    'threshold' => $this->thresholds['queue_length']
                ];
            }
        }

        // Check dead letter queue
        if ($metrics['dead_letter_count'] > $this->thresholds['dead_letter']) {
            $alerts[] = [
                'level' => 'error',
                'message' => 'Dead letter queue size exceeds threshold',
                'value' => $metrics['dead_letter_count'],
                'threshold' => $this->thresholds['dead_letter']
            ];
        }

        // Check throughput
        if ($stats['total_throughput'] < $this->thresholds['throughput']) {
            $alerts[] = [
                'level' => 'warning',
                'message' => 'Queue throughput below threshold',
                'value' => $stats['total_throughput'],
                'threshold' => $this->thresholds['throughput']
            ];
        }

        // Log alerts
        foreach ($alerts as $alert) {
            Log::channel('queue')->log(
                $alert['level'],
                $alert['message'],
                ['value' => $alert['value'], 'threshold' => $alert['threshold']]
            );
        }

        return [
            'metrics' => $metrics,
            'stats' => $stats,
            'alerts' => $alerts,
            'healthy' => empty($alerts)
        ];
    }

    /**
     * Set monitoring thresholds
     */
    public function setThresholds(array $thresholds): void
    {
        $this->thresholds = array_merge($this->thresholds, $thresholds);
    }
}
