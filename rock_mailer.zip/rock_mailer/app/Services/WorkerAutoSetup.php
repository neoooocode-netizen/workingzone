<?php

namespace App\Services;

use App\Models\WorkerNode;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use phpseclib3\Net\SSH2;
use phpseclib3\Crypt\RSA;

class WorkerAutoSetup
{
    protected $fileManager;

    public function __construct(WorkerFileManager $fileManager)
    {
        $this->fileManager = $fileManager;
    }

    public function setupWorker(array $config): array
    {
        try {
            // Remove sensitive data from logging
            $logConfig = array_diff_key($config, ['ssh_password' => '', 'ssh_key' => '']);
            Log::info('Starting worker setup - workerautosetup Line 29', ['config' => $logConfig]);

            // Validate required fields
            $requiredFields = ['hostname', 'capacity', 'ssh_port', 'ssh_user', 'auth_type'];
            foreach ($requiredFields as $field) {
                if (empty($config[$field])) {
                    throw new \Exception("Missing required field: {$field}");
                }
            }

            // Validate auth type specific requirements
            if ($config['auth_type'] === 'password' && empty($config['ssh_password'])) {
                throw new \Exception('SSH password is required for password authentication');
            } else if ($config['auth_type'] === 'key' && empty($config['ssh_key'])) {
                throw new \Exception('SSH key is required for key authentication');
            }

            // Create the worker node
            $worker = WorkerNode::create([
                'hostname' => $config['hostname'],
                'ip_address' => $config['hostname'],
                'ssh_key_path' => null,  // We'll set this later if using key auth
                'capacity' => $config['capacity'],
                'ssh_port' => $config['ssh_port'],
                'ssh_user' => $config['ssh_user'],
                'auth_type' => $config['auth_type'],
                'ssh_password' => $config['ssh_password'] ?? null,
                'auth_token' => Str::random(64),
                'max_concurrent_jobs' => $config['capacity'],
                'current_load' => 0,
                'status' => WorkerNode::STATUS_INITIALIZING
            ]);

            // Test SSH connection and file system access
            $testResults = $this->testWorkerAccess($worker);
            if (!$testResults) {
                throw new \Exception('Worker access test failed');
            }
            
            // Create app directory structure
            $this->executeCommand($worker, 'mkdir -p /opt/rock_mailer/app');

            // Setup worker files and environment
            $this->setupWorkerFiles($worker);

            // Install and configure PHP 7.4 and dependencies
            $this->setupPhpEnvironment($worker);
            
            // Configure and start worker service
            $this->setupWorkerService($worker);
            
            

            // Update worker status to active
            $worker->update(['status' => WorkerNode::STATUS_ACTIVE]);


            return [
                'success' => true,
                'worker' => $worker,
                'message' => 'Worker node setup completed successfully'
            ];

        } catch (\Exception $e) {
            Log::error('Worker setup failed', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'hostname' => $config['hostname'] ?? null
            ]);

            if (isset($worker)) {
                // Update worker status to error
                $worker->update([
                    'status' => WorkerNode::STATUS_ERROR,
                    'last_error' => $e->getMessage()
                ]);
            }

            throw $e;
        }
    }

    /**
     * Test worker access and permissions
     */
    protected function testWorkerAccess(WorkerNode $worker)
    {
        Log::info('Testing worker access', [
            'worker_id' => $worker->id,
            'hostname' => $worker->hostname,
            'auth_type' => $worker->auth_type
        ]);

        Log::debug('Executing command on worker', [
            'worker_id' => $worker->id,
            'command' => 'whoami'
        ]);

        $result = $this->executeCommand($worker, 'whoami');
        
        if (!$result['success']) {
            throw new \Exception('SSH connection failed or command execution error: ' . ($result['error'] ?: 'Unknown error'));
        }

        // Trim whitespace and newlines from output
        $output = trim($result['output']);
        
        if ($output !== 'root') {
            throw new \Exception('SSH connection successful but not running as root user. Current user: ' . $output);
        }

        return true;
    }

    protected function setupWorkerFiles(WorkerNode $worker): bool
    {
        try {
            Log::info('Setting up worker files', [
                'worker_id' => $worker->id
            ]);

            // First, ensure SELinux is not blocking us
            $result = $this->executeCommand($worker, 'setenforce 0 2>/dev/null || true');
            if (!$result['success']) {
                Log::warning('Failed to temporarily disable SELinux (this is normal if SELinux is not installed)', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
            }

            Log::info('Creating directory structure', ['worker_id' => $worker->id]);

            // Create app directory structure with proper permissions
            $commands = [
                'mkdir -p /opt/rock_mailer/app',
                'mkdir -p /opt/rock_mailer/app/logs',
                'chown -R root:root /opt/rock_mailer',
                'chmod -R 755 /opt/rock_mailer',
                'restorecon -R /opt/rock_mailer || true'  // Restore SELinux context if enabled
            ];

            foreach ($commands as $cmd) {
                $result = $this->executeCommand($worker, $cmd);
                if (!$result['success']) {
                    Log::warning("Directory setup command failed: {$cmd}", [
                        'worker_id' => $worker->id,
                        'error' => $result['error']
                    ]);
                }
            }

            // Ensure Postfix is installed and running
            $result = $this->executeCommand($worker, 'command -v postfix >/dev/null 2>&1 || yum install -y postfix');
            if (!$result['success']) {
                Log::error('Failed to ensure Postfix is installed', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            // Ensure mailx is installed
            $result = $this->executeCommand($worker, 'command -v mailx >/dev/null 2>&1 || yum install -y mailx');
            if (!$result['success']) {
                Log::error('Failed to ensure mailx is installed', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            // Start and enable Postfix
            $result = $this->executeCommand($worker, 'systemctl start postfix && systemctl enable postfix');
            if (!$result['success']) {
                Log::error('Failed to start Postfix service', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            // Configure Postfix for local mail sending
            $postfixCommands = [
                "postconf -e 'inet_interfaces = loopback-only'",
                "postconf -e 'mydestination = localhost.localdomain, localhost'",
                "postconf -e 'mynetworks = 127.0.0.0/8 [::ffff:127.0.0.0]/104 [::1]/128'",
                "systemctl restart postfix"
            ];

            foreach ($postfixCommands as $cmd) {
                $result = $this->executeCommand($worker, $cmd);
                if (!$result['success']) {
                    Log::error('Failed to configure Postfix', [
                        'worker_id' => $worker->id,
                        'command' => $cmd,
                        'error' => $result['error']
                    ]);
                    return false;
                }
            }

            // Create and write .env file
            $mainServer = $this->fileManager->getMainServerUrl();
            $envContent = $this->fileManager->generateEnvFile($worker, $mainServer);
            $result = $this->executeCommand($worker, "cat > /opt/rock_mailer/app/.env << 'EOL'\n{$envContent}\nEOL");
            if (!$result['success']) {
                Log::error('Failed to create .env file', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            // Set .env file permissions
            $result = $this->executeCommand($worker, 'chmod 600 /opt/rock_mailer/app/.env');
            if (!$result['success']) {
                Log::error('Failed to set .env file permissions', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            // Write worker.php file
            $workerPhpContent = $this->fileManager->generateWorkerScript();
            $result = $this->executeCommand($worker, "cat > /opt/rock_mailer/app/worker.php << 'EOL'\n{$workerPhpContent}\nEOL");
            if (!$result['success']) {
                Log::error('Failed to create worker.php file', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            // Set worker.php permissions
            $result = $this->executeCommand($worker, 'chmod 644 /opt/rock_mailer/app/worker.php');
            if (!$result['success']) {
                Log::error('Failed to set worker.php permissions', [
                    'worker_id' => $worker->id,
                    'error' => $result['error']
                ]);
                return false;
            }

            Log::info('Worker files setup completed', [
                'worker_id' => $worker->id,
                'app_path' => '/opt/rock_mailer/app'
            ]);

            return true;

        } catch (\Exception $e) {
            Log::error('Failed to setup worker files', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);
            return false;
        }
    }

    protected function setupPhpEnvironment(WorkerNode $worker): bool
    {
        try {
            Log::info('Setting up PHP 7.4 environment', ['worker_id' => $worker->id]);

            // Check current PHP version
            $checkPhp = $this->executeCommand($worker, 'command -v php && php -v || echo "PHP not installed"');
            if ($checkPhp['success'] && strpos($checkPhp['output'], 'PHP 7.4') !== false) {
                Log::info('PHP 7.4 is already installed', [
                    'worker_id' => $worker->id,
                    'version' => trim($checkPhp['output'])
                ]);
                return true;
            }

            // Generate and write the installation script
            $scriptContent = $this->fileManager->generatePhpInstallScript();
            $result = $this->executeCommand($worker, "cat > /tmp/install_php.sh << 'EOL'\n{$scriptContent}\nEOL");
            if (!$result['success']) {
                throw new \Exception('Failed to create PHP installation script');
            }

            // Make the script executable
            $result = $this->executeCommand($worker, 'chmod +x /tmp/install_php.sh');
            if (!$result['success']) {
                throw new \Exception('Failed to make PHP installation script executable');
            }

            // Execute the installation script
            $result = $this->executeCommand($worker, '/tmp/install_php.sh');
            if (!$result['success']) {
                throw new \Exception('PHP installation script failed: ' . $result['error']);
            }

            // Clean up the script
            $this->executeCommand($worker, 'rm -f /tmp/install_php.sh', false);

            // Verify PHP installation one more time
            $verifyPhp = $this->executeCommand($worker, 'php -v');
            if (!$verifyPhp['success'] || strpos($verifyPhp['output'], 'PHP 7.4') === false) {
                throw new \Exception('PHP 7.4 verification failed after installation');
            }

            Log::info('PHP environment setup completed successfully', [
                'worker_id' => $worker->id,
                'version' => trim($verifyPhp['output'])
            ]);
            return true;

        } catch (\Exception $e) {
            Log::error('Failed to setup PHP environment', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    protected function setupWorkerService(WorkerNode $worker): bool
    {
        try {
            Log::info('Setting up worker service', ['worker_id' => $worker->id]);
            
            // Check if service already exists
            $checkService = $this->executeCommand($worker, 'systemctl list-unit-files | grep rock-mailer-worker.service || true');
            if ($checkService['success'] && strpos($checkService['output'], 'rock-mailer-worker.service') !== false) {
                Log::info('Worker service already exists, stopping and removing it first', ['worker_id' => $worker->id]);
                // Stop and disable existing service
                $this->executeCommand($worker, 'systemctl stop rock-mailer-worker || true');
                $this->executeCommand($worker, 'systemctl disable rock-mailer-worker || true');
                $this->executeCommand($worker, 'rm -f /etc/systemd/system/rock-mailer-worker.service || true');
                $this->executeCommand($worker, 'systemctl daemon-reload');
            }
            
            // Verify PHP installation before proceeding
            $phpCheck = $this->executeCommand($worker, 'command -v php && php -v');
            if (!$phpCheck['success'] || strpos($phpCheck['output'], 'PHP 7.4') === false) {
                throw new \Exception('PHP 7.4 is not properly installed. Please run PHP setup first.');
            }

            // Create required log directory
            $result = $this->executeCommand($worker, 'mkdir -p /opt/rock_mailer/app/logs && chmod 755 /opt/rock_mailer/app/logs');
            if (!$result['success']) {
                throw new \Exception('Failed to create log directory: ' . $result['error']);
            }

            // Get service file content from WorkerFileManager
            $serviceContent = $this->fileManager->generateSystemdServiceFile();

            // Write service file with proper permissions
            $result = $this->executeCommand($worker, "cat > /etc/systemd/system/rock-mailer-worker.service << 'EOL'\n{$serviceContent}\nEOL");
            if (!$result['success']) {
                throw new \Exception('Failed to create service file: ' . $result['error']);
            }

            // Set proper permissions on service file
            $result = $this->executeCommand($worker, 'chmod 644 /etc/systemd/system/rock-mailer-worker.service');
            if (!$result['success']) {
                throw new \Exception('Failed to set service file permissions: ' . $result['error']);
            }
            
            // Reload systemd and enable service
            $result = $this->executeCommand($worker, 'systemctl daemon-reload');
            if (!$result['success']) {
                throw new \Exception('Failed to reload systemd: ' . $result['error']);
            }

            $result = $this->executeCommand($worker, 'systemctl enable rock-mailer-worker');
            if (!$result['success']) {
                throw new \Exception('Failed to enable service: ' . $result['error']);
            }

            // Start service
            $result = $this->executeCommand($worker, 'systemctl start rock-mailer-worker');
            if (!$result['success']) {
                throw new \Exception('Failed to start service: ' . $result['error']);
            }
            
            // First check if worker.php script exists
            $scriptCheck = $this->executeCommand($worker, 'test -f /opt/rock_mailer/app/worker.php && echo "exists" || echo "missing"', false);
            if (trim($scriptCheck['output']) !== 'exists') {
                Log::error('Worker script is missing', [
                    'worker_id' => $worker->id,
                    'script_path' => '/opt/rock_mailer/app/worker.php'
                ]);
                
                // Attempt to upload the worker script if it doesn't exist
                $this->setupWorkerFiles($worker);
                
                // Check again after attempting to fix
                $scriptCheck = $this->executeCommand($worker, 'test -f /opt/rock_mailer/app/worker.php && echo "exists" || echo "missing"', false);
                if (trim($scriptCheck['output']) !== 'exists') {
                    throw new \Exception('Failed to start worker service: worker.php script is missing and could not be created');
                }
                
                Log::info('Successfully created missing worker script', ['worker_id' => $worker->id]);
            }
            
            // Wait for the service to start (increased from 2 to 10 seconds)
            sleep(10);
            
            // Get detailed service status for debugging
            $statusDetails = $this->executeCommand($worker, 'systemctl status rock-mailer-worker', false);
            
            // Check if service is activating but failing to start (stuck in auto-restart)
            if (strpos($statusDetails['output'], 'activating (auto-restart)') !== false && 
                strpos($statusDetails['output'], 'code=exited, status=1/FAILURE') !== false) {
                
                // Service is failing to start properly, check logs
                Log::error('Service is failing to start properly', [
                    'worker_id' => $worker->id,
                    'status_details' => $statusDetails['output']
                ]);
                
                // Check worker logs
                $logCheck = $this->executeCommand($worker, 'cat /opt/rock_mailer/app/logs/worker-error.log 2>/dev/null || echo "No logs available"', false);
                Log::error('Worker error logs', [
                    'worker_id' => $worker->id,
                    'error_logs' => $logCheck['output']
                ]);
                
                // For now, we'll just log the failure but continue to avoid setup failure
                Log::warning('Worker service is failing to start, but continuing setup', ['worker_id' => $worker->id]);
            } else {
                // Verify service status
                $status = $this->executeCommand($worker, 'systemctl is-active rock-mailer-worker', false);
                $serviceStatus = trim($status['output']);
                
                if ($serviceStatus !== 'active' && $serviceStatus !== 'activating') {
                    // Service is in an unexpected state
                    Log::error('Service is in unexpected state', [
                        'worker_id' => $worker->id,
                        'status' => $serviceStatus,
                        'status_details' => $statusDetails['output']
                    ]);
                    
                    // For now, we'll continue despite the error to avoid setup failure
                    Log::warning('Worker service is in unexpected state, but continuing setup', ['worker_id' => $worker->id]);
                }
            }

            Log::info('Worker service setup completed successfully', [
                'worker_id' => $worker->id,
                'status' => 'active'
            ]);

            return true;
        } catch (\Exception $e) {
            Log::error('Failed to setup worker service', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    /**
     * Get worker service status and information
     */
    public function getWorkerStatus(WorkerNode $worker): array
    {
        try {
            $status = $this->executeCommand($worker, 'systemctl is-active rock-mailer-worker');
            $logs = $this->executeCommand($worker, 'journalctl -u rock-mailer-worker -n 50 --no-pager');
            $processInfo = $this->executeCommand($worker, 'ps aux | grep "[p]hp /opt/rock_mailer/app/worker.php"');

            return [
                'status' => trim($status['output']) === 'active' ? 'running' : 'stopped',
                'logs' => $logs['output'] ?? '',
                'process_info' => $processInfo['output'] ?? ''
            ];
        } catch (\Exception $e) {
            throw new \Exception("Failed to get worker status: " . $e->getMessage());
        }
    }

    protected function getConnection(WorkerNode $worker)
    {
        $ssh = new SSH2($worker->hostname, $worker->ssh_port);
        
        // Set longer timeout for long-running commands
        $ssh->setTimeout(600);  // 10 minutes timeout
        
        if ($worker->auth_type === 'password') {
            if (!$ssh->login($worker->ssh_user, $worker->ssh_password)) {
                throw new \Exception('SSH authentication failed using password');
            }
        } else {
            $key = new RSA();
            $key->loadKey($worker->ssh_key);
            if (!$ssh->login($worker->ssh_user, $key)) {
                throw new \Exception('SSH authentication failed using key');
            }
        }

        return $ssh;
    }

    /**
     * Execute a command on the worker node via SSH
     */
    public function executeCommand(WorkerNode $worker, string $command, bool $throwOnError = true): array
    {
        try {
            Log::debug('Executing command on worker', [
                'worker_id' => $worker->id,
                'command' => $command
            ]);

            $ssh = $this->getConnection($worker);
            
            // Execute command and capture output
            $output = $ssh->exec($command);
            $error = $ssh->getStdError();

            // Log the complete output for debugging
            Log::debug('Command execution result', [
                'worker_id' => $worker->id,
                'command' => $command,
                'output' => $output,
                'error' => $error,
                'exit_code' => $ssh->getExitStatus()
            ]);

            if ($throwOnError && $ssh->getExitStatus() !== 0) {
                throw new \Exception("Command failed: $command\nError: $error");
            }

            return [
                'output' => $output,
                'error' => $error,
                'success' => $ssh->getExitStatus() === 0
            ];
        } catch (\Exception $e) {
            Log::error('SSH command execution failed', [
                'worker_id' => $worker->id,
                'command' => $command,
                'error' => $e->getMessage()
            ]);

            if ($throwOnError) {
                throw $e;
            }
            return [
                'output' => '',
                'error' => $e->getMessage(),
                'success' => false
            ];
        }
    }
}
