<?php

namespace App\Services;

use App\Models\EmailDeliveryLog;
use App\Models\WorkerPerformanceLog;
use App\Models\Worker;
use Illuminate\Support\Facades\Log;

class WorkerLoggingService
{
    /**
     * Log an email delivery attempt.
     */
    public function logEmailDelivery(
        Worker $worker,
        string $email,
        string $status,
        ?string $messageId = null,
        ?string $errorType = null,
        ?string $errorMessage = null,
        ?string $smtpResponse = null,
        ?float $deliveryTime = null,
        int $attempts = 1,
        array $metadata = []
    ): EmailDeliveryLog {
        try {
            return EmailDeliveryLog::create([
                'worker_id' => $worker->id,
                'campaign_id' => $worker->current_campaign_id,
                'email' => $email,
                'status' => $status,
                'message_id' => $messageId,
                'error_type' => $errorType,
                'error_message' => $errorMessage,
                'smtp_response' => $smtpResponse,
                'delivery_time' => $deliveryTime,
                'attempts' => $attempts,
                'metadata' => $metadata
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to log email delivery', [
                'worker_id' => $worker->id,
                'email' => $email,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    /**
     * Log worker performance metrics.
     */
    public function logPerformance(
        Worker $worker,
        float $memoryUsage,
        float $memoryPeak,
        float $cpuUsage,
        array $loadAverage,
        int $queueSize,
        int $processedCount,
        float $processingSpeed,
        int $postfixQueueSize,
        int $activeCampaigns,
        array $metadata = []
    ): WorkerPerformanceLog {
        try {
            return WorkerPerformanceLog::create([
                'worker_id' => $worker->id,
                'memory_usage' => $memoryUsage,
                'memory_peak' => $memoryPeak,
                'cpu_usage' => $cpuUsage,
                'load_average' => $loadAverage,
                'queue_size' => $queueSize,
                'processed_count' => $processedCount,
                'processing_speed' => $processingSpeed,
                'postfix_queue_size' => $postfixQueueSize,
                'active_campaigns' => $activeCampaigns,
                'metadata' => $metadata
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to log worker performance', [
                'worker_id' => $worker->id,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    /**
     * Get the current Postfix queue size.
     */
    public function getPostfixQueueSize(): int
    {
        try {
            $output = shell_exec('mailq | grep -c "^[A-F0-9]"');
            return (int) $output;
        } catch (\Exception $e) {
            Log::warning('Failed to get Postfix queue size', [
                'error' => $e->getMessage()
            ]);
            return 0;
        }
    }

    /**
     * Get system performance metrics.
     */
    public function getSystemMetrics(): array
    {
        try {
            $memInfo = $this->parseMemInfo();
            $cpuInfo = $this->parseCpuInfo();
            $loadAvg = sys_getloadavg();

            return [
                'memory_usage' => $memInfo['MemTotal'] - $memInfo['MemAvailable'],
                'memory_peak' => $memInfo['MemTotal'] - $memInfo['MemAvailable'],
                'cpu_usage' => $cpuInfo['usage'],
                'load_average' => $loadAvg,
            ];
        } catch (\Exception $e) {
            Log::error('Failed to get system metrics', [
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    /**
     * Parse /proc/meminfo to get memory information.
     */
    private function parseMemInfo(): array
    {
        $memInfo = [];
        $content = file_get_contents('/proc/meminfo');
        
        preg_match_all('/^(\w+):\s+(\d+)/m', $content, $matches, PREG_SET_ORDER);
        
        foreach ($matches as $match) {
            $memInfo[$match[1]] = (int) $match[2] * 1024; // Convert KB to bytes
        }

        return $memInfo;
    }

    /**
     * Parse /proc/stat to get CPU usage.
     */
    private function parseCpuInfo(): array
    {
        $prev = file_get_contents('/proc/stat');
        usleep(100000); // Sleep for 100ms
        $current = file_get_contents('/proc/stat');

        return $this->calculateCpuUsage($prev, $current);
    }

    /**
     * Calculate CPU usage from two snapshots of /proc/stat.
     */
    private function calculateCpuUsage(string $prev, string $current): array
    {
        $prevValues = explode(' ', preg_split('/\s+/', trim($prev))[1]);
        $currentValues = explode(' ', preg_split('/\s+/', trim($current))[1]);

        $prevIdle = $prevValues[3] + $prevValues[4];
        $currentIdle = $currentValues[3] + $currentValues[4];

        $prevTotal = array_sum($prevValues);
        $currentTotal = array_sum($currentValues);

        $totalDiff = $currentTotal - $prevTotal;
        $idleDiff = $currentIdle - $prevIdle;

        return [
            'usage' => ($totalDiff > 0)
                ? (($totalDiff - $idleDiff) / $totalDiff) * 100
                : 0
        ];
    }
}
