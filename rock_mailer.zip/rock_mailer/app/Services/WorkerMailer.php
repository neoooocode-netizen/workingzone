<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Exception;

class WorkerMailer
{
    protected $errorLogs = [];
    protected $successCount = 0;
    protected $failedCount = 0;

    /**
     * Process attachment file
     *
     * @param array $attachment
     * @return array
     */
    protected function processAttachment(array $attachment): array
    {
        $content = base64_encode(file_get_contents($attachment['path']));
        
        // Generate random filename while keeping extension
        $extension = pathinfo($attachment['name'], PATHINFO_EXTENSION);
        $randomName = uniqid() . '.' . $extension;
        
        return [
            'filename' => $randomName,
            'mime' => $attachment['mime'],
            'content' => chunk_split($content)
        ];
    }

    /**
     * Construct email message with headers
     *
     * @param array $emailData
     * @return array
     */
    protected function constructEmail(array $emailData): array
    {
        $headers = [];
        $headers[] = 'MIME-Version: 1.0';
        
        $message = '';
        
        if (!empty($emailData['attachment'])) {
            try {
                $attachmentData = $this->processAttachment($emailData['attachment']);
                $boundary = "PHP-mixed-" . md5(uniqid(time()));
                
                // Set content type for multipart message
                $headers[] = 'Content-Type: multipart/mixed; boundary="' . $boundary . '"';
                
                // Build message with attachment
                $message = "--" . $boundary . "\r\n";
                $message .= "Content-Type: text/html; charset=UTF-8\r\n";
                $message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
                $message .= $emailData['body'] . "\r\n\r\n";
                
                // Add attachment part
                $message .= "--" . $boundary . "\r\n";
                $message .= "Content-Type: " . $attachmentData['mime'] . "; name=\"" . $attachmentData['filename'] . "\"\r\n";
                $message .= "Content-Transfer-Encoding: base64\r\n";
                $message .= "Content-Disposition: attachment; filename=\"" . $attachmentData['filename'] . "\"\r\n\r\n";
                $message .= $attachmentData['content'] . "\r\n\r\n";
                $message .= "--" . $boundary . "--";
            } catch (Exception $e) {
                Log::error('Failed to process attachment', [
                    'error' => $e->getMessage(),
                    'attachment' => $emailData['attachment']['name']
                ]);
                throw $e;
            }
        } else {
            // No attachment, just HTML
            $headers[] = 'Content-Type: text/html; charset=UTF-8';
            $message = $emailData['body'];
        }

        // Add remaining headers
        $headers[] = 'From: ' . $emailData['from_name'] . ' <' . $emailData['from_email'] . '>';
        $headers[] = 'Reply-To: ' . $emailData['reply_to'];
        $headers[] = 'Accept-Language: en-US';
        $headers[] = 'Content-Language: en-US';
        $headers[] = 'priority: high';
        $headers[] = 'importance: high';
        $headers[] = 'date: ' . date('r');
        $headers[] = 'X-MS-Exchange-Organization-AuthAs: Internal';
        $headers[] = 'X-MS-Exchange-Organization-AuthMechanism: 04';
        $headers[] = 'X-MS-Exchange-Organization-AuthSource: AM6PR05MB6112.eurprd02.prod.outlook.com';
        $headers[] = 'X-Mailer: Microsoft Office Outlook, Build 11.0.5510';
        $headers[] = 'X-MimeOLE: Produced By Microsoft MimeOLE V6.00.2800.1441';
        $headers[] = 'X-Recommended-Action: accept';
        $headers[] = 'X-Spam-Category: LEGIT';

        return [
            'headers' => implode("\r\n", $headers),
            'message' => $message
        ];
    }

    /**
     * Send email using local Postfix
     *
     * @param string $recipient
     * @param array $emailData
     * @return bool
     */
    protected function sendToRecipient(string $recipient, array $emailData): bool
    {
        try {
            // Set unlimited execution time for large batches
            set_time_limit(0);
            ini_set('max_execution_time', 0);

            $email = $this->constructEmail($emailData);
            
            $result = mail(
                $recipient,
                $emailData['subject'],
                $email['message'],
                $email['headers']
            );

            if ($result) {
                $this->successCount++;
                return true;
            }

            throw new Exception('Mail sending failed');

        } catch (Exception $e) {
            $this->failedCount++;
            $this->errorLogs[] = [
                'recipient' => $recipient,
                'error' => $e->getMessage(),
                'timestamp' => now(),
            ];

            Log::error('Email sending failed', [
                'recipient' => $recipient,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * Process a batch of emails
     *
     * @param array $recipients
     * @param array $emailData
     * @return array
     */
    public function processBatch(array $recipients, array $emailData): array
    {
        $this->successCount = 0;
        $this->failedCount = 0;
        $this->errorLogs = [];

        // Process in smaller chunks to prevent overwhelming Postfix
        $batchSize = 50;
        $delay = 1; // 1 second delay between chunks

        foreach (array_chunk($recipients, $batchSize) as $chunk) {
            foreach ($chunk as $recipient) {
                $this->sendToRecipient($recipient, $emailData);
            }

            if ($delay > 0) {
                sleep($delay);
            }
        }

        return [
            'success_count' => $this->successCount,
            'failed_count' => $this->failedCount,
            'error_logs' => $this->errorLogs,
        ];
    }

    /**
     * Get processing statistics
     *
     * @return array
     */
    public function getStats(): array
    {
        return [
            'success_count' => $this->successCount,
            'failed_count' => $this->failedCount,
            'total_processed' => $this->successCount + $this->failedCount,
            'error_count' => count($this->errorLogs),
        ];
    }
}
