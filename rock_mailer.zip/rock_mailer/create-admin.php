<?php

// Bootstrap Laravel environment
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\Hash;

// Check if user already exists
$existingUser = User::where('email', 'admin@rockbelling.com')->first();
if ($existingUser) {
    echo "Admin user already exists!\n";
    echo "Email: admin@rockbelling.com\n";
} else {
    // Create admin user
    $user = User::create([
        'name' => 'Rock Belling',
        'email' => 'admin@rockbelling.com',
        'password' => Hash::make('@Rockbelling@'),
    ]);

    echo "Admin user created successfully!\n";
    echo "Email: admin@rockbelling.com\n";
    echo "Password: @Rockbelling@\n";
}
