<?php

namespace Database\Factories;

use App\Models\Campaign;
use Illuminate\Database\Eloquent\Factories\Factory;

class CampaignFactory extends Factory
{
    protected $model = Campaign::class;

    public function definition(): array
    {
        $totalEmails = $this->faker->numberBetween(1000, 10000);
        $sentEmails = $this->faker->numberBetween(0, $totalEmails);
        $failedEmails = $this->faker->numberBetween(0, $totalEmails - $sentEmails);

        return [
            'name' => $this->faker->company() . ' Campaign',
            'status' => $this->faker->randomElement(['pending', 'running', 'paused', 'completed', 'failed']),
            'template' => $this->faker->randomHtml(),
            'settings' => [
                'batch_size' => $this->faker->numberBetween(100, 1000),
                'rate_limit' => $this->faker->numberBetween(1000, 5000),
                'retry_attempts' => $this->faker->numberBetween(1, 3),
                'priority' => $this->faker->numberBetween(1, 5)
            ],
            'total_emails' => $totalEmails,
            'sent_emails' => $sentEmails,
            'failed_emails' => $failedEmails,
            'created_at' => $this->faker->dateTimeBetween('-1 month', '-1 day'),
            'updated_at' => $this->faker->dateTimeBetween('-1 day', 'now'),
            'completed_at' => null
        ];
    }

    public function running(): self
    {
        return $this->state(function (array $attributes) {
            return [
                'status' => 'running',
                'started_at' => now()->subHours(random_int(1, 24))
            ];
        });
    }

    public function completed(): self
    {
        return $this->state(function (array $attributes) {
            return [
                'status' => 'completed',
                'started_at' => now()->subDays(random_int(1, 7)),
                'completed_at' => now()
            ];
        });
    }

    public function failed(): self
    {
        return $this->state(function (array $attributes) {
            return [
                'status' => 'failed',
                'started_at' => now()->subHours(random_int(1, 24)),
                'error' => $this->faker->randomElement([
                    'SMTP connection failed',
                    'Rate limit exceeded',
                    'Worker disconnected',
                    'Invalid template'
                ])
            ];
        });
    }
}
