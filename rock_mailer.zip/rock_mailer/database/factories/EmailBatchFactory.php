<?php

namespace Database\Factories;

use App\Models\EmailBatch;
use App\Models\Campaign;
use App\Models\Worker;
use Illuminate\Database\Eloquent\Factories\Factory;

class EmailBatchFactory extends Factory
{
    protected $model = EmailBatch::class;

    public function definition(): array
    {
        $batchSize = $this->faker->numberBetween(50, 200);
        $processedCount = $this->faker->numberBetween(0, $batchSize);
        $successCount = $this->faker->numberBetween(0, $processedCount);
        $failedCount = $processedCount - $successCount;

        return [
            'campaign_id' => Campaign::factory(),
            'worker_id' => Worker::factory(),
            'status' => $this->faker->randomElement(['pending', 'processing', 'completed', 'failed']),
            'emails' => collect(range(1, $batchSize))->map(fn() => $this->faker->email())->toArray(),
            'batch_size' => $batchSize,
            'processed_count' => $processedCount,
            'success_count' => $successCount,
            'failed_count' => $failedCount,
            'started_at' => $this->faker->dateTimeBetween('-1 hour', 'now'),
            'completed_at' => null,
            'error' => null,
            'metadata' => [
                'retry_count' => $this->faker->numberBetween(0, 3),
                'last_error' => null,
                'processing_time' => $this->faker->randomFloat(2, 0, 60)
            ],
            'created_at' => $this->faker->dateTimeBetween('-1 day', '-1 hour'),
            'updated_at' => $this->faker->dateTimeBetween('-1 hour', 'now')
        ];
    }

    public function pending(): self
    {
        return $this->state(function (array $attributes) {
            return [
                'status' => 'pending',
                'started_at' => null,
                'completed_at' => null,
                'processed_count' => 0,
                'success_count' => 0,
                'failed_count' => 0
            ];
        });
    }

    public function processing(): self
    {
        return $this->state(function (array $attributes) {
            $processedCount = $this->faker->numberBetween(1, $attributes['batch_size'] - 1);
            $successCount = $this->faker->numberBetween(0, $processedCount);
            
            return [
                'status' => 'processing',
                'started_at' => now()->subMinutes(random_int(1, 30)),
                'completed_at' => null,
                'processed_count' => $processedCount,
                'success_count' => $successCount,
                'failed_count' => $processedCount - $successCount
            ];
        });
    }

    public function completed(): self
    {
        return $this->state(function (array $attributes) {
            return [
                'status' => 'completed',
                'started_at' => now()->subHours(random_int(1, 24)),
                'completed_at' => now(),
                'processed_count' => $attributes['batch_size'],
                'success_count' => $attributes['batch_size'],
                'failed_count' => 0
            ];
        });
    }

    public function failed(): self
    {
        return $this->state(function (array $attributes) {
            $processedCount = $this->faker->numberBetween(0, $attributes['batch_size']);
            
            return [
                'status' => 'failed',
                'started_at' => now()->subMinutes(random_int(1, 30)),
                'completed_at' => now(),
                'processed_count' => $processedCount,
                'success_count' => $this->faker->numberBetween(0, $processedCount),
                'failed_count' => $processedCount,
                'error' => $this->faker->randomElement([
                    'SMTP connection failed',
                    'Rate limit exceeded',
                    'Invalid recipient',
                    'Template rendering error'
                ])
            ];
        });
    }
}
