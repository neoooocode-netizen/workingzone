<?php

namespace Database\Factories;

use App\Models\Worker;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class WorkerFactory extends Factory
{
    protected $model = Worker::class;

    public function definition(): array
    {
        return [
            'hostname' => $this->faker->domainName(),
            'ip_address' => $this->faker->ipv4(),
            'status' => $this->faker->randomElement(['active', 'inactive', 'error']),
            'capacity' => $this->faker->numberBetween(500, 5000),
            'current_load' => $this->faker->numberBetween(0, 1000),
            'api_token' => Str::random(60),
            'system_info' => [
                'cpu_cores' => $this->faker->numberBetween(2, 8),
                'memory_total' => $this->faker->numberBetween(4096, 16384),
                'disk_space' => $this->faker->numberBetween(20000, 100000)
            ],
            'last_heartbeat' => $this->faker->dateTimeBetween('-1 hour', 'now'),
            'created_at' => $this->faker->dateTimeBetween('-1 month', '-1 day'),
            'updated_at' => $this->faker->dateTimeBetween('-1 day', 'now')
        ];
    }

    public function active(): self
    {
        return $this->state(function (array $attributes) {
            return [
                'status' => 'active',
                'last_heartbeat' => now()
            ];
        });
    }

    public function inactive(): self
    {
        return $this->state(function (array $attributes) {
            return [
                'status' => 'inactive',
                'last_heartbeat' => now()->subHours(2)
            ];
        });
    }
}
