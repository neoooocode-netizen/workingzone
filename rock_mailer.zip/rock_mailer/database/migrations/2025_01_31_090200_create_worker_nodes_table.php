<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('worker_nodes', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('node_id');
            $table->string('hostname');
            $table->string('ip_address');
            $table->enum('status', ['initializing', 'active', 'inactive', 'error'])->default('inactive');
            $table->integer('capacity')->default(100);
            $table->integer('current_load')->default(0);
            $table->string('auth_token', 64);
            $table->integer('ssh_port')->default(22);
            $table->string('ssh_user')->default('root');
            $table->string('ssh_key_path')->nullable();
            $table->float('cpu_usage')->default(0);
            $table->float('memory_usage')->default(0);
            $table->integer('total_emails_sent')->default(0);
            $table->float('success_rate')->default(100);
            $table->timestamp('last_heartbeat_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('worker_nodes');
    }
};
