<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('system_logs', function (Blueprint $table) {
            $table->id();
            $table->string('type'); // campaign, worker, queue, system
            $table->string('level'); // info, warning, error, debug
            $table->text('message');
            $table->json('context')->nullable();
            $table->nullableMorphs('loggable');
            $table->foreignUuid('worker_node_id')->nullable()->constrained('worker_nodes')->onDelete('set null');
            $table->foreignUuid('campaign_id')->nullable()->constrained('campaigns')->onDelete('set null');
            $table->json('metadata')->nullable();
            $table->timestamps();

            // Indexes for faster filtering
            $table->index('type');
            $table->index('level');
            $table->index('created_at');
            $table->index(['worker_node_id', 'type']);
            $table->index(['campaign_id', 'type']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('system_logs');
    }
};
