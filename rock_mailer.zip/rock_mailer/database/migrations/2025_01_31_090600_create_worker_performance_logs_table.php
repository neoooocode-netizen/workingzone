<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('worker_performance_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('worker_id')->constrained()->onDelete('cascade');
            $table->float('memory_usage'); // in bytes
            $table->float('memory_peak'); // in bytes
            $table->float('cpu_usage'); // percentage
            $table->json('load_average'); // 1, 5, and 15 minute averages
            $table->integer('queue_size');
            $table->integer('processed_count');
            $table->float('processing_speed'); // emails per minute
            $table->integer('postfix_queue_size');
            $table->integer('active_campaigns');
            $table->json('metadata')->nullable();
            $table->timestamps();

            // Indexes for faster querying
            $table->index('created_at');
            $table->index(['worker_id', 'created_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('worker_performance_logs');
    }
};
