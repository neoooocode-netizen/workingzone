<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('campaign_worker', function (Blueprint $table) {
            $table->foreignUuid('campaign_id');
            $table->foreignUuid('worker_node_id');
            $table->integer('emails_sent')->default(0);
            $table->integer('emails_failed')->default(0);
            $table->boolean('active')->default(true);
            $table->timestamps();

            $table->primary(['campaign_id', 'worker_node_id']);

            $table->foreign('campaign_id')
                ->references('id')
                ->on('campaigns')
                ->onDelete('cascade');

            $table->foreign('worker_node_id')
                ->references('id')
                ->on('worker_nodes')
                ->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('campaign_worker');
    }
};
