<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('campaigns', function (Blueprint $table) {
            if (!Schema::hasColumn('campaigns', 'batch_size')) {
                $table->integer('batch_size')->default(100);
            }
            if (!Schema::hasColumn('campaigns', 'priority')) {
                $table->integer('priority')->default(5);
            }
            if (!Schema::hasColumn('campaigns', 'attachments')) {
                $table->json('attachments')->nullable();
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('campaigns', function (Blueprint $table) {
            $table->dropColumn(['attachments', 'priority', 'batch_size']);
        });
    }
};
