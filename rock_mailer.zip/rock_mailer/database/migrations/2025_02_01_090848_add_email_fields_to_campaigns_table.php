<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('campaigns', function (Blueprint $table) {
            // Add missing subject column
            if (!Schema::hasColumn('campaigns', 'subject')) {
                $table->string('subject')->after('name');
            }
            
            // Add email-specific fields
            if (!Schema::hasColumn('campaigns', 'from_email')) {
                $table->string('from_email')->after('subject');
            }
            if (!Schema::hasColumn('campaigns', 'from_name')) {
                $table->string('from_name')->after('from_email');
            }
            if (!Schema::hasColumn('campaigns', 'reply_to')) {
                $table->string('reply_to')->nullable()->after('from_name');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('campaigns', function (Blueprint $table) {
            $table->dropColumn(['subject', 'from_email', 'from_name', 'reply_to']);
        });
    }
};
