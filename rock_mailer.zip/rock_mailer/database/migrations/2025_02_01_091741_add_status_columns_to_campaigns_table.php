<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('campaigns', function (Blueprint $table) {
            if (!Schema::hasColumn('campaigns', 'status')) {
                $table->string('status')->default('pending')->after('body');
            }
            if (!Schema::hasColumn('campaigns', 'total_recipients')) {
                $table->integer('total_recipients')->default(0)->after('status');
            }
            if (!Schema::hasColumn('campaigns', 'sent_count')) {
                $table->integer('sent_count')->default(0)->after('total_recipients');
            }
            if (!Schema::hasColumn('campaigns', 'failed_count')) {
                $table->integer('failed_count')->default(0)->after('sent_count');
            }
            if (!Schema::hasColumn('campaigns', 'batch_size')) {
                $table->integer('batch_size')->default(100)->after('failed_count');
            }
            if (!Schema::hasColumn('campaigns', 'priority')) {
                $table->tinyInteger('priority')->default(5)->after('batch_size');
            }
            if (!Schema::hasColumn('campaigns', 'attachments')) {
                $table->json('attachments')->nullable()->after('priority');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('campaigns', function (Blueprint $table) {
            $table->dropColumn([
                'status',
                'total_recipients',
                'sent_count',
                'failed_count',
                'batch_size',
                'priority',
                'attachments'
            ]);
        });
    }
};
