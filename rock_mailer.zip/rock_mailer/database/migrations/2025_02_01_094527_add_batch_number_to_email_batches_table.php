<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('email_batches', function (Blueprint $table) {
            if (!Schema::hasColumn('email_batches', 'batch_number')) {
                $table->integer('batch_number')->after('campaign_id')->default(0);
            }
            if (!Schema::hasColumn('email_batches', 'total_count')) {
                $table->integer('total_count')->after('recipients')->default(0);
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('email_batches', function (Blueprint $table) {
            $table->dropColumn(['batch_number', 'total_count']);
        });
    }
};
