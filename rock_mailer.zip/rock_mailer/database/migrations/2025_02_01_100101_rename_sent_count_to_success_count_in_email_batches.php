<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('email_batches', function (Blueprint $table) {
            // First check if sent_count exists and success_count doesn't
            if (Schema::hasColumn('email_batches', 'sent_count') && !Schema::hasColumn('email_batches', 'success_count')) {
                $table->renameColumn('sent_count', 'success_count');
            }
            
            // If neither exists, create success_count
            if (!Schema::hasColumn('email_batches', 'sent_count') && !Schema::hasColumn('email_batches', 'success_count')) {
                $table->integer('success_count')->default(0)->after('total_count');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('email_batches', function (Blueprint $table) {
            if (Schema::hasColumn('email_batches', 'success_count')) {
                $table->renameColumn('success_count', 'sent_count');
            }
        });
    }
};
