<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up()
    {
        // First, modify existing enum values to include 'failed'
        DB::statement("ALTER TABLE worker_nodes MODIFY COLUMN status ENUM('initializing', 'active', 'inactive', 'error', 'failed') DEFAULT 'inactive'");
    }

    public function down()
    {
        // Revert back to original enum values
        DB::statement("ALTER TABLE worker_nodes MODIFY COLUMN status ENUM('initializing', 'active', 'inactive', 'error') DEFAULT 'inactive'");
    }
};
