<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('worker_nodes', function (Blueprint $table) {
            $table->string('ssh_password')->nullable()->after('ssh_key_path');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('worker_nodes', function (Blueprint $table) {
            $table->dropColumn('ssh_password');
        });
    }
};
