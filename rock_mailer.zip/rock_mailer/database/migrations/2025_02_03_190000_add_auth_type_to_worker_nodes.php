<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddAuthTypeToWorkerNodes extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('worker_nodes', function (Blueprint $table) {
            $table->string('auth_type')->default('password')->after('ssh_password');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('worker_nodes', function (Blueprint $table) {
            $table->dropColumn('auth_type');
        });
    }
}
