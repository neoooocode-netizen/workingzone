# Rock Mailer Deployment Guide

## Architecture Overview
- Main Server: Ubuntu 22.04.5 LTS
- Worker Nodes: CentOS 7
- Queue System: Redis
- Mail Server: Postfix (on each worker node)

## 1. Main Server Setup (Ubuntu 22.04.5)

### Host System Preparation
```bash
# On Ubuntu host:
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker prerequisites
sudo apt install -y ca-certificates curl gnupg unzip

# Add Docker's GPG key
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# Add Docker repository
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Install Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Install Redis
sudo apt install -y redis-server
sudo systemctl enable redis-server
sudo systemctl start redis-server

# Prepare deployment directory
sudo mkdir -p /var/www/html/rock_mailer
cd /var/www/html/rock_mailer
```

### Application Deployment
```bash
# On Ubuntu host:
#upload the zip file

unzip rock_mailer.zip
# Set proper ownership

sudo chown -R $USER:$USER /var/www/html/rock_mailer

# Configure environment
Change IP to VPS IP in .env file and \rock_mailer\app\Services\WorkerFileManager.php

# might already be existing or Create storage directory structure
mkdir -p storage/app/public
mkdir -p storage/framework/{cache,sessions,views}
mkdir -p storage/logs

# Set correct permissions
sudo chown -R www-data:www-data storage
sudo chown -R www-data:www-data bootstrap/cache
sudo chmod -R 775 storage
sudo chmod -R 775 bootstrap/cache

# Build and start containers
sudo docker compose build --progress=plain --no-cache
sudo docker compose up -d

# Inside app container:
# Run initial setup
sudo docker compose exec app rm -rf vendor composer.lock
sudo docker compose exec app composer install --no-dev --optimize-autoloader
sudo docker compose exec app php artisan migrate --force

# Verify permissions after container setup
sudo docker compose exec app chown -R www-data:www-data /var/www/html/rock_mailer/storage
sudo docker compose exec app chown -R www-data:www-data /var/www/html/rock_mailer/bootstrap/cache
sudo docker compose exec app chmod -R 775 /var/www/html/rock_mailer/storage
sudo docker compose exec app chmod -R 775 /var/www/html/rock_mailer/bootstrap/cache

# Create storage link
sudo docker compose exec app php artisan storage:link

Now visit phpmyadmin at http://your-server:8080
import rock_mailer.sql

# Fix database schema issues
sudo docker compose exec app php fix_personal_access_tokens.php

# Create admin
sudo docker exec -it rock_mailer_app bash

php create-admin.php


NOW visit http://your-server:8000/login


# Email: admin@rockbelling.com
# Password: @Rockbelling@

# sudo docker compose exec app php fix_personal_access_tokens.php

## 2. Worker Node Setup (CentOS 7)

### Prerequisites
- CentOS 7 server with SSH access
- Sudo privileges
- Internet connectivity

### Worker Registration
```
```bash
# On main server's web interface:
# 1. Access the main server's dashboard
# Navigate to Workers > Add Worker

# 2. Enter the worker details:
# - Worker Name (e.g., worker1)
# - SSH Host (e.g., 192.168.1.100)
# - SSH User (with sudo access)
# - SSH Key or Password

# 3. Click "Add Worker"
# The system will automatically:
# - Install Docker and dependencies
# - Configure the worker environment
# - Set up Postfix for mail sending
# - Start the worker service

# 4. Monitor the setup progress in the dashboard
# The worker status will change to "Ready" when setup is complete
```

Note: The system automatically handles all installation and configuration steps. No manual server preparation is required.

## 3. Maintenance Commands

### Main Server
```bash
# On Ubuntu host:
# View application container logs
sudo docker compose logs -f app

# Monitor Redis queue (on host)
redis-cli monitor

# Inside app container:
# View campaign progress
sudo docker compose exec app php artisan campaign:status
```

### Worker Nodes
```bash
# On CentOS host:
# View mail logs
sudo tail -f /var/log/maillog

# Inside worker container:
# View worker logs
sudo docker logs -f worker

# On CentOS host:
# Check Postfix mail queue
mailq
```

### Security
```bash
# On Ubuntu host:
sudo ufw allow 8000/tcp  # API port
sudo ufw allow 6379/tcp  # Redis (only if accessed from external workers)

# On CentOS host:
sudo firewall-cmd --permanent --add-port=25/tcp  # SMTP
sudo firewall-cmd --reload
```

## 4. Troubleshooting

### Main Server
```bash
# On Ubuntu host:
# Check Redis connection
redis-cli ping

# Check queue size
redis-cli llen queues:default

# Web interface:
# Check worker registrations
http://your-server:8000/workers
```

### Worker Nodes
```bash
# From any machine:
# Check worker API status
curl http://main_server:8000/api/workers/status \
  -H "X-Worker-ID: worker1" \
  -H "X-Auth-Token: your_token"

# On CentOS host:
# Check Postfix service
systemctl status postfix

# Test mail sending (inside worker container)
echo "Test" | mail -s "Test" test@example.com
```

## 5. Common Issues and Solutions

### Permissions Issues

#### Main Server
```bash
# On Ubuntu host:
# 1. Fix storage permissions
sudo chown -R www-data:www-data /var/www/html/rock_mailer/storage
sudo chmod -R 775 /var/www/html/rock_mailer/storage

# 2. Fix bootstrap/cache permissions
sudo chown -R www-data:www-data /var/www/html/rock_mailer/bootstrap/cache
sudo chmod -R 775 /var/www/html/rock_mailer/bootstrap/cache

# 3. Fix storage subdirectories
sudo chown -R www-data:www-data /var/www/html/rock_mailer/storage/app/public
sudo chown -R www-data:www-data /var/www/html/rock_mailer/storage/framework
sudo chown -R www-data:www-data /var/www/html/rock_mailer/storage/logs

# 4. Ensure log file exists and is writable
sudo -u www-data touch /var/www/html/rock_mailer/storage/logs/laravel.log
sudo chmod 664 /var/www/html/rock_mailer/storage/logs/laravel.log

# 5. Fix framework directory permissions
sudo chmod -R 775 /var/www/html/rock_mailer/storage/framework/cache
sudo chmod -R 775 /var/www/html/rock_mailer/storage/framework/sessions
sudo chmod -R 775 /var/www/html/rock_mailer/storage/framework/views

# 6. Verify SELinux context (if enabled)
sudo chcon -R -t httpd_sys_rw_content_t /var/www/html/rock_mailer/storage
sudo chcon -R -t httpd_sys_rw_content_t /var/www/html/rock_mailer/bootstrap/cache
```

#### Worker Nodes
```bash
# On CentOS host:
# 1. Fix Postfix permissions
sudo chown -R postfix:postfix /var/spool/postfix
sudo chmod -R 755 /var/spool/postfix

# 2. Fix mail log permissions
sudo chown root:root /var/log/maillog
sudo chmod 644 /var/log/maillog

# Inside worker container:
# 3. Fix worker log directory
sudo docker compose exec worker mkdir -p /app/logs
sudo docker compose exec worker chown -R www-data:www-data /app/logs
sudo docker compose exec worker chmod -R 775 /app/logs
```

### Common Permission-Related Errors

1. Laravel Log Error:
```
UnexpectedValueException: The stream or file "storage/logs/laravel.log" could not be opened in append mode: Failed to open stream: Permission denied
```
Solution: Run the storage permissions fix commands above.

2. Cache Error:
```
RuntimeException: Unable to create directory /var/www/html/rock_mailer/storage/framework/cache
```
Solution: Run the framework directory permissions fix commands.

3. Session Error:
```
RuntimeException: Session store not set
```
Solution: Run the sessions directory permissions fix commands.

4. Postfix Mail Queue Error:
```
warning: cannot access directory /var/spool/postfix: Permission denied
```
Solution: Run the Postfix permissions fix commands on the worker node.

### Prevention Tips

1. Always run Laravel commands as the www-data user:
```bash
# Example
sudo -u www-data php artisan cache:clear
```

2. When creating new directories, set permissions immediately:
```bash
mkdir new_directory
sudo chown www-data:www-data new_directory
sudo chmod 775 new_directory
```

3. Monitor log files for permission errors:
```bash
# On Ubuntu host:
sudo tail -f /var/www/html/rock_mailer/storage/logs/laravel.log

# On CentOS host:
sudo tail -f /var/log/maillog