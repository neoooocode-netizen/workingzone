FROM php:8.2-apache

# Install system dependencies
RUN apt-get update && apt-get install -y \
    git \
    curl \
    libpng-dev \
    libonig-dev \
    libxml2-dev \
    zip \
    unzip \
    gnupg \
    && pecl install redis \
    && docker-php-ext-enable redis \
    && docker-php-ext-install pdo_mysql mbstring exif pcntl bcmath gd \
    && apt-get clean \
    && rm -rf /var/lib/apt/lists/*

# Install Node.js 20.x and npm
RUN curl -fsSL https://deb.nodesource.com/setup_20.x | bash - \
    && apt-get install -y nodejs

# Enable Apache modules
RUN a2enmod rewrite

# Copy and enable Apache configuration
COPY docker/apache.conf /etc/apache2/sites-available/000-default.conf

# Set working directory
WORKDIR /var/www/html/rock_mailer

# Copy existing application directory
COPY . /var/www/html/rock_mailer

# Install composer
COPY --from=composer:latest /usr/bin/composer /usr/bin/composer

# Install NPM dependencies
RUN npm ci

# Fix permissions and build assets
RUN chmod -R 755 node_modules/.bin/ \
    && npm run build

# Set permissions
RUN chown -R www-data:www-data /var/www/html/rock_mailer/storage /var/www/html/rock_mailer/bootstrap/cache
