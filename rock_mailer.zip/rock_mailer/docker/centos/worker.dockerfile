# Use CentOS 7 as base
FROM centos:7

# Install EPEL and Remi repository
RUN yum install -y epel-release && \
    yum install -y http://rpms.remirepo.net/enterprise/remi-release-7.rpm && \
    yum install -y yum-utils && \
    yum-config-manager --enable remi-php72

# Install system dependencies
RUN yum install -y \
    php \
    php-cli \
    php-common \
    php-curl \
    php-mbstring \
    php-mysql \
    php-xml \
    php-zip \
    php-bcmath \
    php-gd \
    php-redis \
    postfix \
    supervisor \
    git \
    unzip

# Set working directory
WORKDIR /var/www/html

# Install composer
RUN curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer

# Copy application files
COPY . /var/www/html

# Copy supervisor configuration
COPY docker/centos/supervisor/worker.conf /etc/supervisord.d/

# Create log directory
RUN mkdir -p /var/log/worker

# Set permissions
RUN chown -R apache:apache /var/www/html/storage /var/www/html/bootstrap/cache /var/log/worker

# Configure Postfix
COPY docker/centos/postfix/main.cf /etc/postfix/main.cf

# Start supervisor
CMD ["/usr/bin/supervisord", "-n", "-c", "/etc/supervisord.conf"]
