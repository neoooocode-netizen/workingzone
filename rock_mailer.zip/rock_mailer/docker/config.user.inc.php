<?php
$cfg['Servers'][1]['auth_type'] = 'config';
$cfg['Servers'][1]['user'] = 'root';
$cfg['Servers'][1]['password'] = 'rock_mailer_root';
$cfg['Servers'][1]['AllowNoPassword'] = false;

// Disable HTTPS requirement for cookies
$cfg['ForceSSL'] = false;
$cfg['PmaNoRelation_DisableWarning'] = true;
$cfg['LoginCookieValidity'] = 14400;
$cfg['CheckConfigurationPermissions'] = false;

// Cookie settings
$cfg['CookieSameSite'] = 'Lax';
$cfg['UseCookie'] = true;
$cfg['CookieSecure'] = false;
$cfg['CookieHttpOnly'] = false;
