# Worker Node Installation and Setup Guide

## Overview
This document outlines the complete workflow for setting up a worker node in the RockMailer distributed email processing system. It includes the key components, potential issues, and solutions that were implemented.

## Prerequisites
- CentOS 7 worker node
- SSH access (password or key-based)
- Docker support
- PHP 8.2 compatibility

## Installation Workflow

### 1. SSH Authentication Setup
```php
use phpseclib3\Net\SSH2;
use phpseclib3\Crypt\PublicKeyLoader;
```

#### Key Components:
- Using phpseclib3 for secure SSH connections
- Supporting both password and key-based authentication
- Proper error handling for connection failures

#### Implementation:
```php
if ($config['auth_type'] === 'key') {
    $key = PublicKeyLoader::load($config['ssh_key']);
    $ssh->login($config['ssh_user'], $key);
} else {
    $ssh->login($config['ssh_user'], $config['ssh_password']);
}
```

### 2. Docker Environment Setup

#### System Requirements:
- Docker engine
- docker-compose
- Proper permissions and group settings

#### Key Steps:
1. Docker Installation Verification
2. SELinux Configuration (if enabled)
3. Docker Daemon Configuration
4. Required Image Pulls:
   - php:8.2-cli
   - redis:latest
   - mysql:8.0

#### Docker Configuration:
```json
{
    "log-driver": "json-file",
    "log-opts": {
        "max-size": "100m",
        "max-file": "3"
    },
    "storage-driver": "overlay2",
    "iptables": true,
    "registry-mirrors": [
        "https://registry-1.docker.io",
        "https://mirror.gcr.io"
    ]
}
```

### 3. Worker Environment Setup

#### Directory Structure:
```
/root/app/
├── src/
│   └── worker.php
├── logs/
├── .env
├── docker-compose.yml
└── Dockerfile
```

#### Critical Files:

1. Environment File (.env):
```
NODE_ID={worker_id}
API_KEY={auth_token}
MAIN_SERVER={server_url}
WORKER_CAPACITY={capacity}
```

2. Dockerfile:
```dockerfile
FROM php:8.2-cli

# Simplified dependencies
RUN apt-get update && apt-get install -y \
    git \
    curl \
    zip \
    unzip \
    && docker-php-ext-install -j$(nproc) pdo_mysql \
    && apt-get clean \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app
CMD ["php", "/app/src/worker.php"]
```

3. docker-compose.yml:
```yaml
version: "3.8"
services:
  worker:
    build:
      context: .
      dockerfile: Dockerfile
    restart: unless-stopped
    volumes:
      - ./.env:/app/.env:ro
      - ./src:/app/src:ro
      - ./logs:/app/logs:rw
    environment:
      NODE_ID: "{worker_id}"
      API_KEY: "{auth_token}"
      MAIN_SERVER: "{server_url}"
      WORKER_CAPACITY: "{capacity}"
```

### 4. Worker Process Implementation

#### Key Features:
- Environment variable validation
- Job polling system
- Status reporting
- Error handling and logging
- Memory usage monitoring

#### Worker Script Structure:
```php
while (true) {
    try {
        // 1. Poll for new jobs
        // 2. Process available jobs
        // 3. Report status back to main server
        // 4. Handle errors and log issues
        sleep(5); // Prevent excessive polling
    } catch (Exception $e) {
        error_log("Error: " . $e->getMessage());
    }
}
```

### 5. Common Issues and Solutions

1. **Docker Permission Issues**
   - Solution: Proper group permissions and directory ownership
   - Command: `chmod -R 777 /root/app/logs`

2. **Environment Variable Access**
   - Solution: Mount .env file as read-only and use environment block in docker-compose.yml
   - Ensure proper file paths in container

3. **Container Startup Issues**
   - Solution: Simplified Dockerfile with minimal dependencies
   - Removed unnecessary Composer dependencies
   - Added proper health checks

4. **Network Communication**
   - Solution: Ensure proper API endpoints and authentication
   - Implement retry logic for failed connections

### 6. Monitoring and Maintenance

1. **Health Checks**
```yaml
healthcheck:
  test: ["CMD", "php", "-r", "if(!file_exists('/app/src/worker.php')) exit(1);"]
  interval: 30s
  timeout: 10s
  retries: 3
  start_period: 10s
```

2. **Log Management**
- Implemented log rotation
- Separate logs for worker process and Docker
- Error tracking and reporting

### 7. Security Considerations

1. **Authentication**
- Secure API key storage
- Protected environment variables
- Limited container permissions

2. **File Permissions**
- Read-only mounts for sensitive files
- Proper volume permissions
- Restricted container access

## Conclusion
The successful worker setup relies on proper Docker configuration, simplified dependencies, and robust error handling. The key was removing unnecessary complexity and ensuring proper file permissions and environment variable handling.
