<?php

// Create a database migration to fix the personal_access_tokens table schema for Laravel Sanctum
$sql = "DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

// Connect to the database using environment variables from the Laravel .env file
$dotenv = file_get_contents(__DIR__ . '/.env');
preg_match('/DB_HOST=([^\n]+)/', $dotenv, $hostMatches);
preg_match('/DB_PORT=([^\n]+)/', $dotenv, $portMatches);
preg_match('/DB_DATABASE=([^\n]+)/', $dotenv, $databaseMatches);
preg_match('/DB_USERNAME=([^\n]+)/', $dotenv, $usernameMatches);
preg_match('/DB_PASSWORD=([^\n]+)/', $dotenv, $passwordMatches);

$host = isset($hostMatches[1]) ? trim($hostMatches[1]) : 'mysql';
$port = isset($portMatches[1]) ? trim($portMatches[1]) : '3306';
$database = isset($databaseMatches[1]) ? trim($databaseMatches[1]) : 'rock_mailer';
$username = isset($usernameMatches[1]) ? trim($usernameMatches[1]) : 'root';
$password = isset($passwordMatches[1]) ? trim($passwordMatches[1]) : '';

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected to database successfully.\n";
    
    // Execute the SQL to fix the personal_access_tokens table
    $pdo->exec($sql);
    
    echo "Successfully recreated personal_access_tokens table with proper schema.\n";
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage() . "\n";
    exit(1);
}
