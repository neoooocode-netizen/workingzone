#!/bin/bash

# Error handling
set -e
exec 2>&1  # Redirect stderr to stdout for better error capture

# Function to log with timestamp
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Function to run command with error handling
run_command() {
    log "Running: $1"
    if ! eval "$1"; then
        log "ERROR: Command failed: $1"
        log "Last 10 lines of /var/log/yum.log:"
        tail -n 10 /var/log/yum.log || true
        return 1
    fi
}

# Check for existing PHP installation
log "Checking for existing PHP installation..."
if command -v php &> /dev/null; then
    CURRENT_PHP_VERSION=$(php -v | grep -E "^PHP [0-9]" | head -n1)
    log "Found existing PHP installation: $CURRENT_PHP_VERSION"
    
    if echo "$CURRENT_PHP_VERSION" | grep -q "PHP 7.4"; then
        log "PHP 7.4 is already installed, no need to proceed"
        exit 0
    else
        log "Removing existing PHP installation..."
        run_command "yum remove -y php php-cli php-common php-curl php-fileinfo php-json php-mbstring php-xml || true"
        run_command "yum remove -y php74-* || true"
        run_command "yum remove -y php-* || true"
        run_command "rm -rf /etc/php* || true"
    fi
fi

# Clean yum cache first
log "Cleaning yum cache..."
run_command "yum clean all"
run_command "rm -rf /var/cache/yum"

# Update system
log "Updating system..."
run_command "yum check-update || true"  # This command returns 100 if updates are available
run_command "yum update -y"

# Remove any existing repository files
log "Removing existing repository files..."
run_command "rm -f /etc/yum.repos.d/remi* || true"
run_command "rm -f /etc/yum.repos.d/epel* || true"

# Install EPEL repository
log "Installing EPEL repository..."
run_command "yum install -y epel-release"

# Install Remi repository
log "Installing Remi repository..."
run_command "yum install -y https://rpms.remirepo.net/enterprise/remi-release-7.rpm"

# Install yum-utils
log "Installing yum-utils..."
run_command "yum install -y yum-utils"

# Enable Remi PHP 7.4 repository
log "Enabling Remi PHP 7.4 repository..."
run_command "yum-config-manager --enable remi-php74"

# Install PHP 7.4 and extensions
log "Installing PHP 7.4 and required extensions..."
run_command "yum install -y php php-cli php-common php-curl php-fileinfo php-json php-mbstring php-xml"

# Verify PHP installation
log "Verifying PHP version..."
PHP_VERSION=$(php -v | grep -E "^PHP 7.4" | head -n1)
if [ -z "$PHP_VERSION" ]; then
    log "ERROR: PHP 7.4 installation verification failed"
    log "Installed PHP version:"
    php -v
    exit 1
fi

log "Successfully installed: $PHP_VERSION"
log "PHP installation completed successfully"