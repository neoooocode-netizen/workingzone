// Auto-refresh mechanism for components that don't use WebSocket
export function initAutoRefresh() {
    return {
        refreshInterval: null,
        isLoading: false,
        lastRefresh: null,

        init() {
            this.startRefreshInterval();
            this.$watch('refreshInterval', () => this.startRefreshInterval());

            // Pause refresh when tab is not visible
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    this.stopRefreshInterval();
                } else {
                    this.startRefreshInterval();
                }
            });
        },

        startRefreshInterval() {
            this.stopRefreshInterval();
            
            if (this.refreshInterval) {
                this.timer = setInterval(() => {
                    this.refresh();
                }, this.refreshInterval);
            }
        },

        stopRefreshInterval() {
            if (this.timer) {
                clearInterval(this.timer);
                this.timer = null;
            }
        },

        async refresh() {
            if (this.isLoading) return;

            this.isLoading = true;
            try {
                await this.$wire.refresh();
                this.lastRefresh = new Date();
            } catch (error) {
                console.error('Refresh failed:', error);
            } finally {
                this.isLoading = false;
            }
        }
    };
}
