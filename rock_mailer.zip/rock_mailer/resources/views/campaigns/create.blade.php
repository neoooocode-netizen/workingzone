<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Create Campaign') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <form action="{{ route('campaigns.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                        @csrf

                        <!-- Campaign Name -->
                        <div>
                            <x-input-label for="name" :value="__('Campaign Name')" />
                            <x-text-input id="name" name="name" type="text" class="mt-1 block w-full" required autofocus />
                            <x-input-error class="mt-2" :messages="$errors->get('name')" />
                        </div>

                        <!-- Sender Information -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <x-input-label for="from_name" :value="__('Sender Name')" />
                                <x-text-input id="from_name" name="from_name" type="text" 
                                    class="mt-1 block w-full" required 
                                    placeholder="Company Name" />
                                <x-input-error class="mt-2" :messages="$errors->get('from_name')" />
                            </div>

                            <div>
                                <x-input-label for="from_email" :value="__('From Email')" />
                                <x-text-input id="from_email" name="from_email" type="email" 
                                    class="mt-1 block w-full" required 
                                    placeholder="noreply@company.com" />
                                <x-input-error class="mt-2" :messages="$errors->get('from_email')" />
                                <p class="mt-1 text-sm text-gray-500">
                                    Email will be sent Via port 25
                                </p>
                            </div>
                        </div>

                        <!-- Reply-To Email -->
                        <div>
                            <x-input-label for="reply_to" :value="__('Reply-To Email (Optional)')" />
                            <x-text-input id="reply_to" name="reply_to" type="email" 
                                class="mt-1 block w-full" 
                                placeholder="support@company.com" />
                            <x-input-error class="mt-2" :messages="$errors->get('reply_to')" />
                        </div>

                        <!-- Subject -->
                        <div>
                            <x-input-label for="subject" :value="__('Email Subject')" />
                            <x-text-input id="subject" name="subject" type="text" class="mt-1 block w-full" required />
                            <x-input-error class="mt-2" :messages="$errors->get('subject')" />
                        </div>

                        <!-- Email Body -->
                        <div>
                            <x-input-label for="body" :value="__('Email Body')" />
                            <textarea id="body" name="body" rows="10" 
                                class="mt-1 block w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm"
                                required></textarea>
                            <x-input-error class="mt-2" :messages="$errors->get('body')" />
                            <p class="mt-2 text-sm text-gray-500">
                                Supports HTML formatting and the following placeholders:
                            </p>
                            <div class="mt-2 p-3 bg-gray-50 rounded text-sm">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                                    <div><code>[-email-]</code>: Full recipient email</div>
                                    <div><code>[-domain-]</code>: Domain name only</div>
                                    <div><code>[-fulldomain-]</code>: Full domain with extension</div>
                                    <div><code>[-emailuser-]</code>: Username part of email</div>
                                    <div><code>[-time-]</code>: Current date and time</div>
                                    <div><code>[-randomstring-]</code>: Random alphanumeric</div>
                                    <div><code>[-randomnumber-]</code>: Random number</div>
                                    <div><code>[-randomletters-]</code>: Random letters</div>
                                    <div><code>[-randommd5-]</code>: Random MD5 hash</div>
                                </div>
                                <p class="mt-2 italic">Example: <code>Hello [-emailuser-], your code is: [-randommd5-]</code></p>
                            </div>
                        </div>

                        <!-- Recipients -->
                        <div>
                            <input type="hidden" name="recipients_type" id="recipients_type_hidden" value="direct">
                            <x-input-label for="recipients_type" :value="__('Recipients Input Method')" />
                            <select id="recipients_type" class="mt-1 block w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm" onchange="toggleRecipientsInput()">
                                <option value="direct">Direct Input</option>
                                <option value="file">File Upload</option>
                            </select>
                        </div>

                        <div id="direct_input_div">
                            <x-input-label for="recipients" :value="__('Recipients List')" />
                            <textarea id="recipients" name="recipients" rows="5" 
                                class="mt-1 block w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm"
                                placeholder="One email per line or CSV format"></textarea>
                            <x-input-error class="mt-2" :messages="$errors->get('recipients')" />
                            <p class="text-sm text-gray-500 mt-1">For large lists (>1000 emails), please use file upload instead.</p>
                        </div>

                        <div id="file_input_div" style="display: none;">
                            <x-input-label for="recipients_file" :value="__('Recipients File')" />
                            <input type="file" id="recipients_file" name="recipients_file" 
                                class="mt-1 block w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm"
                                accept=".txt,.csv">
                            <x-input-error class="mt-2" :messages="$errors->get('recipients_file')" />
                            <p class="text-sm text-gray-500 mt-1">Upload a .txt or .csv file with one email per line</p>
                        </div>

                        <script>
                            function toggleRecipientsInput() {
                                const type = document.getElementById('recipients_type').value;
                                document.getElementById('recipients_type_hidden').value = type;
                                document.getElementById('direct_input_div').style.display = type === 'direct' ? 'block' : 'none';
                                document.getElementById('file_input_div').style.display = type === 'file' ? 'block' : 'none';
                                
                                // Clear the other input when switching
                                if (type === 'direct') {
                                    document.getElementById('recipients_file').value = '';
                                } else {
                                    document.getElementById('recipients').value = '';
                                }
                            }
                        </script>

                        <!-- Attachments -->
                        <div>
                            <x-input-label for="attachments" :value="__('Attachments')" />
                            <input type="file" id="attachments" name="attachments[]" multiple
                                class="mt-1 block w-full text-sm text-gray-500
                                file:mr-4 file:py-2 file:px-4
                                file:rounded-full file:border-0
                                file:text-sm file:font-semibold
                                file:bg-indigo-50 file:text-indigo-700
                                hover:file:bg-indigo-100" />
                            <x-input-error class="mt-2" :messages="$errors->get('attachments.*')" />
                            <p class="mt-2 text-sm text-gray-500">
                                Supported formats: HTML, PDF, DOC, DOCX, XLS, XLSX, JPG, PNG, GIF (Max 10MB each)
                            </p>
                        </div>

                        <!-- Campaign Settings -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <!-- Batch Size -->
                            <div>
                                <x-input-label for="batch_size" :value="__('Batch Size')" />
                                <x-text-input id="batch_size" name="batch_size" type="number" 
                                    class="mt-1 block w-full" 
                                    value="100" min="1" max="2000" />
                                <x-input-error class="mt-2" :messages="$errors->get('batch_size')" />
                                <p class="mt-2 text-sm text-gray-500">
                                    Number of emails to send in each batch (1-2000)
                                </p>
                            </div>

                            <!-- Priority -->
                            <div>
                                <x-input-label for="priority" :value="__('Priority')" />
                                <select id="priority" name="priority" 
                                    class="mt-1 block w-full border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm">
                                    <option value="1">Highest</option>
                                    <option value="3">High</option>
                                    <option value="5" selected>Normal</option>
                                    <option value="7">Low</option>
                                    <option value="9">Lowest</option>
                                </select>
                                <x-input-error class="mt-2" :messages="$errors->get('priority')" />
                            </div>
                        </div>

                        <div class="flex items-center justify-end mt-4">
                            <x-secondary-button onclick="window.history.back()" type="button" class="mr-3">
                                {{ __('Cancel') }}
                            </x-secondary-button>
                            <x-primary-button>
                                {{ __('Create Campaign') }}
                            </x-primary-button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
