<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Campaign Management') }}
            </h2>
            <button @click="$dispatch('open-modal', 'create-campaign')" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Create Campaign
            </button>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Active Campaigns -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4">Active Campaigns</h3>
                    <div class="space-y-6">
                        @foreach($activeCampaigns as $campaign)
                        <div class="border rounded-lg p-4">
                            <div class="flex justify-between items-start mb-4">
                                <div>
                                    <h4 class="text-lg font-medium">{{ $campaign->name }}</h4>
                                    <p class="text-sm text-gray-600">Created {{ $campaign->created_at->diffForHumans() }}</p>
                                    <p class="text-sm text-gray-600">Status: <span class="font-semibold">{{ ucfirst($campaign->status) }}</span></p>
                                    @if($campaign->attachments)
                                        <p class="text-sm text-gray-600 mt-1">
                                            Attachments: {{ count($campaign->attachments) }} file(s)
                                        </p>
                                    @endif
                                </div>
                                <div class="flex space-x-2">
                                    @if($campaign->status === 'pending')
                                        <button @click="$dispatch('open-modal', 'start-campaign-{{ $campaign->id }}')"
                                                class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                                            Start
                                        </button>
                                    @elseif($campaign->status === 'active')
                                        <button @click="$dispatch('open-modal', 'pause-campaign-{{ $campaign->id }}')" 
                                                class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-semibold">
                                            Pause
                                        </button>
                                    @elseif($campaign->status === 'paused')
                                        <button @click="$dispatch('open-modal', 'resume-campaign-{{ $campaign->id }}')"
                                                class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                                            Resume
                                        </button>
                                    @endif
                                </div>
                            </div>

                            <!-- Progress -->
                            <div class="mb-4">
                                <div class="flex justify-between text-sm text-gray-600 mb-1">
                                    <span>Progress</span>
                                    <span>{{ $campaign->sent_count }} / {{ $campaign->total_recipients }}</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2.5">
                                    <div class="bg-blue-600 h-2.5 rounded-full" style="width: {{ $campaign->success_rate }}%"></div>
                                </div>
                            </div>

                            <!-- Stats -->
                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div>
                                    <p class="text-sm text-gray-600">Success Rate</p>
                                    <p class="text-xl font-bold {{ $campaign->success_rate >= 90 ? 'text-green-600' : 'text-yellow-600' }}">
                                        {{ number_format($campaign->success_rate, 1) }}%
                                    </p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Emails/min</p>
                                    <p class="text-xl font-bold text-blue-600">{{ $campaign->emails_per_minute }}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Active Workers</p>
                                    <p class="text-xl font-bold text-indigo-600">{{ $campaign->activeWorkers->count() }}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Failed</p>
                                    <p class="text-xl font-bold {{ $campaign->failed_count === 0 ? 'text-green-600' : 'text-red-600' }}">
                                        {{ $campaign->failed_count }}
                                    </p>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <!-- Completed Campaigns -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4">Completed Campaigns</h3>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Campaign</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sent</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Failed</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Success Rate</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Completed</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach($completedCampaigns as $campaign)
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900">{{ $campaign->name }}</div>
                                        <div class="text-sm text-gray-500">{{ $campaign->description }}</div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                            @if($campaign->status === 'completed') bg-green-100 text-green-800
                                            @else bg-red-100 text-red-800 @endif">
                                            {{ ucfirst($campaign->status) }}
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ number_format($campaign->sent_count) }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ number_format($campaign->failed_count) }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ number_format($campaign->success_rate, 1) }}%
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ $campaign->completed_at->diffForHumans() }}
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-4">
                        {{ $completedCampaigns->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Campaign Modal -->
    <x-modal name="create-campaign" :show="false">
        <form method="POST" action="{{ route('campaigns.store') }}" class="p-6" enctype="multipart/form-data">
            @csrf
            <h2 class="text-lg font-medium text-gray-900 mb-4">
                {{ __('Create New Campaign') }}
            </h2>

            <div class="mb-4">
                <x-input-label for="name" :value="__('Campaign Name')" />
                <x-text-input id="name" name="name" type="text" class="mt-1 block w-full" required />
                <x-input-error :messages="$errors->get('name')" class="mt-2" />
            </div>

            <div class="mb-4">
                <x-input-label for="description" :value="__('Description')" />
                <x-textarea id="description" name="description" class="mt-1 block w-full" rows="3" />
                <x-input-error :messages="$errors->get('description')" class="mt-2" />
            </div>

            <div class="mb-4">
                <x-input-label for="email_list" :value="__('Email List (CSV)')" />
                <x-file-input id="email_list" name="email_list" class="mt-1 block w-full" required accept=".csv" />
                <x-input-error :messages="$errors->get('email_list')" class="mt-2" />
                <p class="mt-1 text-sm text-gray-500">Upload a CSV file with email recipients</p>
            </div>

            <div class="mb-4">
                <x-input-label for="template" :value="__('Email Template')" />
                <x-textarea id="template" name="template" class="mt-1 block w-full" rows="10" required />
                <x-input-error :messages="$errors->get('template')" class="mt-2" />
                <p class="mt-1 text-sm text-gray-500">Use {name}, {email}, etc. as placeholders</p>
            </div>

            <div class="mb-4">
                <x-input-label for="attachments" :value="__('Attachments')" />
                <x-file-input id="attachments" name="attachments[]" class="mt-1 block w-full" multiple />
                <x-input-error :messages="$errors->get('attachments')" class="mt-2" />
            </div>

            <div class="mt-6 flex justify-end">
                <x-secondary-button x-on:click="$dispatch('close')">
                    {{ __('Cancel') }}
                </x-secondary-button>

                <x-primary-button class="ml-3">
                    {{ __('Create Campaign') }}
                </x-primary-button>
            </div>
        </form>
    </x-modal>

    @foreach($activeCampaigns as $campaign)
        @if($campaign->status === 'pending')
            <x-modal name="start-campaign-{{ $campaign->id }}" :show="false">
                <form method="POST" action="{{ route('campaigns.start', $campaign) }}" class="p-6">
                    @csrf
                    <h2 class="text-lg font-medium text-gray-900 mb-4">
                        {{ __('Start Campaign') }}
                    </h2>

                    <p class="text-gray-600 mb-4">
                        Are you sure you want to start this campaign? Workers will start processing batches immediately.
                    </p>

                    <div class="mt-6 flex justify-end">
                        <x-secondary-button x-on:click="$dispatch('close')">
                            {{ __('Cancel') }}
                        </x-secondary-button>

                        <x-primary-button class="ml-3">
                            {{ __('Start Campaign') }}
                        </x-primary-button>
                    </div>
                </form>
            </x-modal>
        @endif

        @if($campaign->status === 'active')
            <x-modal name="pause-campaign-{{ $campaign->id }}" :show="false">
                <form method="POST" action="{{ route('campaigns.pause', $campaign) }}" class="p-6">
                    @csrf
                    <h2 class="text-lg font-medium text-gray-900 mb-4">
                        {{ __('Pause Campaign') }}
                    </h2>

                    <p class="text-gray-600 mb-4">
                        Are you sure you want to pause this campaign? All active workers will complete their current batches before pausing.
                    </p>

                    <div class="mt-6 flex justify-end">
                        <x-secondary-button x-on:click="$dispatch('close')">
                            {{ __('Cancel') }}
                        </x-secondary-button>

                        <x-primary-button class="ml-3">
                            {{ __('Pause Campaign') }}
                        </x-primary-button>
                    </div>
                </form>
            </x-modal>
        @endif

        @if($campaign->status === 'paused')
            <x-modal name="resume-campaign-{{ $campaign->id }}" :show="false">
                <form method="POST" action="{{ route('campaigns.resume', $campaign) }}" class="p-6">
                    @csrf
                    <h2 class="text-lg font-medium text-gray-900 mb-4">
                        {{ __('Resume Campaign') }}
                    </h2>

                    <p class="text-gray-600 mb-4">
                        Resume this campaign? Workers will start processing new batches immediately.
                    </p>

                    <div class="mt-6 flex justify-end">
                        <x-secondary-button x-on:click="$dispatch('close')">
                            {{ __('Cancel') }}
                        </x-secondary-button>

                        <x-primary-button class="ml-3">
                            {{ __('Resume Campaign') }}
                        </x-primary-button>
                    </div>
                </form>
            </x-modal>
        @endif
    @endforeach

    @push('scripts')
    <script>
        // Refresh campaign data every 30 seconds
        setInterval(() => {
            window.location.reload();
        }, 30000);
    </script>
    @endpush
</x-app-layout>
