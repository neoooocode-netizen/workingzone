<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Campaign Details') }}: {{ $campaign->name }}
            </h2>
            <div class="flex space-x-2">
                @if($campaign->status !== 'completed')
                    @if($campaign->status === 'active')
                        <form action="{{ route('campaigns.pause', $campaign) }}" method="POST" class="inline">
                            @csrf
                            <x-secondary-button type="submit">
                                {{ __('Pause Campaign') }}
                            </x-secondary-button>
                        </form>
                    @else
                        <form action="{{ route('campaigns.resume', $campaign) }}" method="POST" class="inline">
                            @csrf
                            <x-secondary-button type="submit">
                                {{ __('Resume Campaign') }}
                            </x-secondary-button>
                        </form>
                    @endif
                @endif
                <form action="{{ route('campaigns.destroy', $campaign) }}" method="POST" class="inline" 
                    onsubmit="return confirm('Are you sure you want to delete this campaign?');">
                    @csrf
                    @method('DELETE')
                    <x-danger-button type="submit">
                        {{ __('Delete Campaign') }}
                    </x-danger-button>
                </form>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <!-- Campaign Status -->
                    <div class="mb-8">
                        <h3 class="text-lg font-semibold mb-4">Status</h3>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="text-sm text-gray-600">Status</div>
                                <div class="text-lg font-semibold capitalize">{{ $campaign->status }}</div>
                            </div>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="text-sm text-gray-600">Progress</div>
                                <div class="text-lg font-semibold">
                                    {{ $campaign->sent_count }} / {{ $campaign->total_recipients }}
                                    ({{ $campaign->total_recipients > 0 
                                        ? round(($campaign->sent_count / $campaign->total_recipients) * 100, 1) 
                                        : 0 }}%)
                                </div>
                            </div>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <div class="text-sm text-gray-600">Failed</div>
                                <div class="text-lg font-semibold">{{ $campaign->failed_count }}</div>
                            </div>
                        </div>
                    </div>

                    <!-- Campaign Details -->
                    <div class="mb-8">
                        <h3 class="text-lg font-semibold mb-4">Details</h3>
                        <div class="space-y-4">
                            <div>
                                <div class="text-sm text-gray-600">Subject</div>
                                <div class="text-lg">{{ $campaign->subject }}</div>
                            </div>
                            <div>
                                <div class="text-sm text-gray-600">Body</div>
                                <div class="prose max-w-none mt-2">
                                    {!! $campaign->body !!}
                                </div>
                            </div>
                            @if($campaign->attachments)
                                <div>
                                    <div class="text-sm text-gray-600 mb-2">Attachments</div>
                                    <div class="space-y-2">
                                        @foreach($campaign->attachments as $attachment)
                                            <div class="flex items-center space-x-2">
                                                <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                        d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13">
                                                    </path>
                                                </svg>
                                                <a href="{{ route('storage.local', $attachment['path']) }}" 
                                                   class="text-blue-600 hover:text-blue-800"
                                                   target="_blank">
                                                    {{ $attachment['name'] }}
                                                </a>
                                                <span class="text-sm text-gray-500">
                                                    ({{ round($attachment['size'] / 1024, 1) }} KB)
                                                </span>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>

                    <!-- Batch Information -->
                    <div>
                        <h3 class="text-lg font-semibold mb-4">Batch Information</h3>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Status
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Recipients
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Success
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Failed
                                        </th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                            Worker
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    @foreach($campaign->batches as $batch)
                                        <tr>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="capitalize">{{ $batch->status }}</span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                {{ $batch->total_count }}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                {{ $batch->success_count }}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                {{ $batch->failed_count }}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                {{ $batch->worker_node_id ?? 'Not assigned' }}
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
