<div class="flex items-center">
    <img src="/images/rock_logo.png" {{ $attributes }} alt="Rock Logo">
    <span class="text-2xl font-bold text-gray-800">ROCK MAILER</span>
</div>
