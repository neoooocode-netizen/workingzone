<div>
    @if($showModal)
        <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>

        <div class="fixed inset-0 z-10 overflow-y-auto">
            <div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                <div class="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-4xl sm:p-6">
                    <!-- Header -->
                    <div class="mb-4 border-b pb-4">
                        <div class="flex justify-between items-center">
                            <h3 class="text-lg font-semibold text-gray-900">
                                Error Details
                            </h3>
                            <button wire:click="$set('showModal', false)" class="text-gray-400 hover:text-gray-500">
                                <span class="sr-only">Close</span>
                                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>

                        <!-- Debug Mode Toggle -->
                        <div class="mt-4 flex items-center space-x-4">
                            <button 
                                wire:click="toggleDebugMode"
                                class="px-3 py-1 text-sm rounded-full {{ $debugMode ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-700' }}"
                            >
                                Debug Mode
                            </button>
                            @if($debugMode)
                                <button 
                                    wire:click="toggleVerboseLogging"
                                    class="px-3 py-1 text-sm rounded-full {{ $verboseLogging ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700' }}"
                                >
                                    Verbose Logging
                                </button>
                                <button 
                                    wire:click="toggleRawData"
                                    class="px-3 py-1 text-sm rounded-full {{ $showRawData ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700' }}"
                                >
                                    Raw Data
                                </button>
                                <button 
                                    wire:click="togglePerformanceMetrics"
                                    class="px-3 py-1 text-sm rounded-full {{ $showPerformanceMetrics ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-700' }}"
                                >
                                    Performance Metrics
                                </button>
                            @endif
                        </div>
                    </div>

                    <!-- Content -->
                    <div class="space-y-4">
                        @if($errorLog)
                            <!-- Basic Error Info -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <p class="text-sm font-medium text-gray-500">Error Type</p>
                                        <p class="mt-1 text-sm text-gray-900">{{ $errorLog->error_type }}</p>
                                    </div>
                                    <div>
                                        <p class="text-sm font-medium text-gray-500">Timestamp</p>
                                        <p class="mt-1 text-sm text-gray-900">{{ $errorLog->created_at->format('Y-m-d H:i:s') }}</p>
                                    </div>
                                    @if($errorLog->worker_id)
                                        <div>
                                            <p class="text-sm font-medium text-gray-500">Worker</p>
                                            <p class="mt-1 text-sm text-gray-900">Worker #{{ $errorLog->worker_id }}</p>
                                        </div>
                                    @endif
                                    @if($errorLog->campaign_id)
                                        <div>
                                            <p class="text-sm font-medium text-gray-500">Campaign</p>
                                            <p class="mt-1 text-sm text-gray-900">{{ $errorLog->campaign->name }}</p>
                                        </div>
                                    @endif
                                </div>
                            </div>

                            <!-- Error Message and Stack Trace -->
                            <div class="bg-gray-50 rounded-lg p-4">
                                <h4 class="text-sm font-medium text-gray-900 mb-2">Error Message</h4>
                                <p class="text-sm text-gray-700">{{ $errorLog->error_message }}</p>

                                @if($debugMode && $verboseLogging && $errorLog->metadata['stack_trace'] ?? null)
                                    <div class="mt-4">
                                        <h4 class="text-sm font-medium text-gray-900 mb-2">Stack Trace</h4>
                                        <pre class="text-xs text-gray-600 bg-gray-100 p-3 rounded overflow-x-auto">{{ $errorLog->metadata['stack_trace'] }}</pre>
                                    </div>
                                @endif
                            </div>

                            <!-- System Status -->
                            @if($systemStatus)
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <h4 class="text-sm font-medium text-gray-900 mb-2">System Status</h4>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <p class="text-sm font-medium text-gray-500">Worker Status</p>
                                            <p class="mt-1 text-sm {{ $systemStatus['success'] ? 'text-green-600' : 'text-red-600' }}">
                                                {{ $systemStatus['success'] ? 'Connected' : 'Disconnected' }}
                                            </p>
                                        </div>
                                        @if($systemStatus['data']['latency'] ?? null)
                                            <div>
                                                <p class="text-sm font-medium text-gray-500">Latency</p>
                                                <p class="mt-1 text-sm text-gray-900">{{ $systemStatus['data']['latency'] }}ms</p>
                                            </div>
                                        @endif
                                    </div>

                                    @if($debugMode && $showPerformanceMetrics && $performanceMetrics)
                                        <div class="mt-4 grid grid-cols-2 gap-4">
                                            <div>
                                                <p class="text-sm font-medium text-gray-500">Memory Usage</p>
                                                <p class="mt-1 text-sm text-gray-900">{{ number_format($performanceMetrics['memory_usage'] / 1024 / 1024, 2) }} MB</p>
                                            </div>
                                            <div>
                                                <p class="text-sm font-medium text-gray-500">CPU Usage</p>
                                                <p class="mt-1 text-sm text-gray-900">{{ number_format($performanceMetrics['cpu_usage'], 1) }}%</p>
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            @endif

                            <!-- Raw Data -->
                            @if($debugMode && $showRawData)
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <h4 class="text-sm font-medium text-gray-900 mb-2">Raw Data</h4>
                                    <pre class="text-xs text-gray-600 bg-gray-100 p-3 rounded overflow-x-auto">{{ json_encode($errorLog->toArray(), JSON_PRETTY_PRINT) }}</pre>
                                </div>
                            @endif

                            <!-- Quick Actions -->
                            <div class="mt-6 flex justify-end space-x-3">
                                @if($errorLog instanceof \App\Models\EmailDeliveryLog)
                                    <button wire:click="retryEmail" class="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700">
                                        Retry Email
                                    </button>
                                @endif
                                
                                @if($errorLog->worker_id)
                                    <button wire:click="refreshWorkerStatus" class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                                        Refresh Worker Status
                                    </button>
                                    
                                    <button wire:click="checkPostfix" class="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">
                                        Check Postfix
                                    </button>
                                @endif

                                <button wire:click="clearErrorLog" class="inline-flex items-center px-4 py-2 text-sm font-medium text-red-700 bg-red-100 rounded-md hover:bg-red-200">
                                    Clear Error
                                </button>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
