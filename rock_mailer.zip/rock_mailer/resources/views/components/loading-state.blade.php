@props([
    'type' => 'spinner', // spinner, skeleton, or pulse
    'size' => 'md', // sm, md, or lg
    'color' => 'primary' // primary, secondary, or gray
])

@php
    $sizeClasses = [
        'sm' => 'w-4 h-4',
        'md' => 'w-8 h-8',
        'lg' => 'w-12 h-12'
    ][$size];

    $colorClasses = [
        'primary' => 'text-blue-600',
        'secondary' => 'text-purple-600',
        'gray' => 'text-gray-600'
    ][$color];
@endphp

@if($type === 'spinner')
    <div {{ $attributes->merge(['class' => 'flex items-center justify-center']) }}>
        <svg class="animate-spin {{ $sizeClasses }} {{ $colorClasses }}" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    </div>
@elseif($type === 'skeleton')
    <div {{ $attributes->merge(['class' => 'animate-pulse bg-gray-200 rounded']) }}>
        <div class="h-full w-full"></div>
    </div>
@else
    <div {{ $attributes->merge(['class' => 'animate-pulse flex space-x-4']) }}>
        <div class="rounded-full bg-gray-200 {{ $sizeClasses }}"></div>
        <div class="flex-1 space-y-4 py-1">
            <div class="h-2 bg-gray-200 rounded"></div>
            <div class="space-y-3">
                <div class="grid grid-cols-3 gap-4">
                    <div class="h-2 bg-gray-200 rounded col-span-2"></div>
                    <div class="h-2 bg-gray-200 rounded col-span-1"></div>
                </div>
                <div class="h-2 bg-gray-200 rounded"></div>
            </div>
        </div>
    </div>
@endif
