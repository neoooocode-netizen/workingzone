<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 bg-[#060d08] text-green-400 font-mono border-b border-emerald-500/30 px-4 py-3 rounded-md">
            <div>
                <span class="text-xs uppercase tracking-widest text-emerald-500/80">MaDoOoOoOoOo Blaster</span>
                <h2 class="font-bold text-xl text-green-400 leading-tight">
                    {{ __('Dashboard') }}
                </h2>
            </div>
            <span class="text-xs text-emerald-400/80">[SYSTEM: ONLINE]</span>
        </div>
    </x-slot>

    <div class="py-12 bg-gradient-to-br from-black via-[#060d08] to-[#020503] text-green-400 font-mono min-h-screen selection:bg-green-500 selection:text-black">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <!-- System Overview -->
            <div class="bg-[#09110c]/95 border border-emerald-500/30 overflow-hidden shadow-[0_0_25px_rgba(16,185,129,0.08)] sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4 text-green-400 border-b border-emerald-500/20 pb-2">
                        MaDoOoOoOoOo Blaster — System Overview
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="bg-[#050a07] border border-emerald-500/20 p-4 rounded-md">
                            <h4 class="font-medium text-emerald-300">Campaigns</h4>
                            <p class="text-2xl font-bold text-green-400 mt-1">{{ $stats['campaigns']['total'] ?? 0 }}</p>
                            <p class="text-sm text-emerald-400/80 mt-1">Active: {{ $stats['campaigns']['active'] ?? 0 }}</p>
                        </div>
                        <div class="bg-[#050a07] border border-emerald-500/20 p-4 rounded-md">
                            <h4 class="font-medium text-emerald-300">Workers</h4>
                            <p class="text-2xl font-bold text-green-400 mt-1">{{ $stats['workers']['total'] ?? 0 }}</p>
                            <p class="text-sm text-emerald-400/80 mt-1">Online: {{ $stats['workers']['active'] ?? 0 }}</p>
                        </div>
                        <div class="bg-[#050a07] border border-emerald-500/20 p-4 rounded-md">
                            <h4 class="font-medium text-emerald-300">Emails</h4>
                            <p class="text-2xl font-bold text-green-400 mt-1">{{ $stats['emails']['sent'] ?? 0 }}</p>
                            <p class="text-sm text-emerald-400/80 mt-1">Pending: {{ $stats['emails']['pending'] ?? 0 }}</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-[#09110c]/95 border border-emerald-500/30 overflow-hidden shadow-[0_0_25px_rgba(16,185,129,0.08)] sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4 text-green-400 border-b border-emerald-500/20 pb-2">
                        Quick Actions
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <a href="{{ route('campaigns.create') }}"
                           class="inline-flex items-center justify-center px-4 py-2.5 bg-emerald-500 hover:bg-green-400 border border-transparent rounded-md font-bold text-black transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-green-400">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                            </svg>
                            Create New Campaign
                        </a>
                        <a href="{{ route('workers.index') }}"
                           class="inline-flex items-center justify-center px-4 py-2.5 bg-[#0b1710] hover:bg-emerald-950 border border-emerald-500/50 rounded-md font-semibold text-green-400 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-emerald-500">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                            </svg>
                            Manage Workers
                        </a>
                    </div>
                </div>
            </div>

            <!-- Active Campaigns -->
            <div class="bg-[#09110c]/95 border border-emerald-500/30 overflow-hidden shadow-[0_0_25px_rgba(16,185,129,0.08)] sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4 text-green-400 border-b border-emerald-500/20 pb-2">
                        Active Campaigns
                    </h3>
                    @if(isset($recentCampaigns) && count($recentCampaigns) > 0)
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-emerald-500/20">
                                <thead>
                                    <tr>
                                        <th class="px-6 py-3 bg-[#050a07] text-left text-xs font-semibold text-emerald-400 uppercase tracking-wider">Name</th>
                                        <th class="px-6 py-3 bg-[#050a07] text-left text-xs font-semibold text-emerald-400 uppercase tracking-wider">Status</th>
                                        <th class="px-6 py-3 bg-[#050a07] text-left text-xs font-semibold text-emerald-400 uppercase tracking-wider">Progress</th>
                                        <th class="px-6 py-3 bg-[#050a07] text-left text-xs font-semibold text-emerald-400 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-[#09110c] divide-y divide-emerald-500/15">
                                    @foreach($recentCampaigns as $campaign)
                                        <tr class="hover:bg-emerald-950/30 transition-colors">
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-300">
                                                {{ $campaign->name }}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-emerald-300/90">
                                                {{ ucfirst($campaign->status) }}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-emerald-300/90">
                                                {{ $campaign->progress }}%
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                <a href="{{ route('campaigns.show', $campaign->id) }}" class="text-green-400 hover:text-emerald-200 underline">View</a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <p class="text-emerald-400/70">No active campaigns found.</p>
                    @endif
                </div>
            </div>

            <!-- Worker Nodes -->
            <div class="bg-[#09110c]/95 border border-emerald-500/30 overflow-hidden shadow-[0_0_25px_rgba(16,185,129,0.08)] sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4 text-green-400 border-b border-emerald-500/20 pb-2">
                        Worker Nodes
                    </h3>
                    @if(isset($workers) && count($workers) > 0)
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-emerald-500/20">
                                <thead>
                                    <tr>
                                        <th class="px-6 py-3 bg-[#050a07] text-left text-xs font-semibold text-emerald-400 uppercase tracking-wider">Node ID</th>
                                        <th class="px-6 py-3 bg-[#050a07] text-left text-xs font-semibold text-emerald-400 uppercase tracking-wider">Status</th>
                                        <th class="px-6 py-3 bg-[#050a07] text-left text-xs font-semibold text-emerald-400 uppercase tracking-wider">Load</th>
                                        <th class="px-6 py-3 bg-[#050a07] text-left text-xs font-semibold text-emerald-400 uppercase tracking-wider">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-[#09110c] divide-y divide-emerald-500/15">
                                    @foreach($workers as $worker)
                                        <tr class="hover:bg-emerald-950/30 transition-colors">
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-green-300">
                                                {{ $worker->node_id }}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-emerald-300/90">
                                                {{ ucfirst($worker->status) }}
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-emerald-300/90">
                                                {{ $worker->current_load }}%
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                <a href="{{ route('workers.show', $worker->id) }}" class="text-green-400 hover:text-emerald-200 underline">View</a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <p class="text-emerald-400/70">No worker nodes registered.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout>