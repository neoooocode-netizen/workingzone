<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                ROCK VPS MAILER
            </h2>
            <a href="https://t.me/rockbelling" target="_blank" class="text-sm font-bold text-gray-600">@rockbelling</a>
            <div class="space-x-2">
                <a href="{{ route('home') }}" class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-all duration-200 shadow-md">
                    Home
                </a>
                <form method="POST" action="{{ route('logout') }}" class="inline">
                    @csrf
                    <button type="submit" class="bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-4 rounded-lg transition-all duration-200 shadow-md">
                        Logout
                    </button>
                </form>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    @if(session('success'))
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                            {{ session('success') }}
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                            {{ session('error') }}
                        </div>
                    @endif

                    <form id="email-form" action="{{ route('mailer.send') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="from">
                                From Email
                            </label>
                            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('from') border-red-500 @enderror" 
                                   id="from" name="from" type="email" required>
                            @error('from')
                                <p class="text-red-500 text-xs italic">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="reply_to">
                                Reply-To Email
                            </label>
                            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('reply_to') border-red-500 @enderror" 
                                   id="reply_to" name="reply_to" type="email" required>
                            @error('reply_to')
                                <p class="text-red-500 text-xs italic">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="sender_name">
                                Sender Name
                            </label>
                            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('sender_name') border-red-500 @enderror" 
                                   id="sender_name" name="sender_name" type="text" required>
                            @error('sender_name')
                                <p class="text-red-500 text-xs italic">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="subject">
                                Subject
                            </label>
                            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('subject') border-red-500 @enderror" 
                                   id="subject" name="subject" type="text">
                            @error('subject')
                                <p class="text-red-500 text-xs italic">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="message">
                                Message (Both Plain text and HTML supported)
                            </label>
                            <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('message') border-red-500 @enderror" 
                                      id="message" name="message" rows="6" required></textarea>
                            @error('message')
                                <p class="text-red-500 text-xs italic">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mb-4">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="to" id="emailLabel">
                                To Email(s) - One email per line - Total emails(0)
                            </label>
                            <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('to') border-red-500 @enderror" 
                                      id="to" name="to" rows="10" required
                                      oninput="updateEmailCount(this)"></textarea>
                            @error('to')
                                <p class="text-red-500 text-xs italic">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mb-6">
                            <label class="block text-gray-700 text-sm font-bold mb-2" for="attachment">
                                Attachment (Optional)
                            </label>
                            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline @error('attachment') border-red-500 @enderror" 
                                   id="attachment" name="attachment" type="file">
                            @error('attachment')
                                <p class="text-red-500 text-xs italic">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="mt-6 flex justify-center">
                            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                                Send Email
                            </button>
                        </div>
                    </form>

                    <!-- Progress Modal -->
                    <div id="progress-modal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden">
                        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                            <div class="mt-3 text-center">
                                <h3 class="text-lg leading-6 font-medium text-gray-900">Sending Emails</h3>
                                <div class="mt-2">
                                    <p id="modal-recipients" class="text-sm text-gray-600 font-medium"></p>
                                </div>
                                <div class="mt-4 px-7 py-3">
                                    <div class="bg-gray-200 rounded-full h-6 overflow-hidden">
                                        <div id="modal-progress-bar" class="bg-blue-600 h-6 rounded-full transition-all duration-500 ease-out" style="width: 0%"></div>
                                    </div>
                                    <div class="mt-3">
                                        <p id="modal-progress-text" class="text-sm text-gray-500">Preparing to send...</p>
                                    </div>
                                    <div class="mt-2">
                                        <p id="modal-status" class="text-xs text-gray-400"></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <script>
                        function updateEmailCount(textarea) {
                            const emails = textarea.value.split('\n').filter(email => email.trim()).length;
                            document.getElementById('emailLabel').textContent = `To Email(s) - One email per line - Total emails(${emails})`;
                        }
                        
                        // Also update on paste
                        document.getElementById('to').addEventListener('paste', function(e) {
                            setTimeout(() => updateEmailCount(this), 0);
                        });

                        let currentTrackingId = null;
                        let progressInterval = null;
                        let animationInterval = null;
                        const modal = document.getElementById('progress-modal');
                        const modalProgressBar = document.getElementById('modal-progress-bar');
                        const modalProgressText = document.getElementById('modal-progress-text');

                        function showModal() {
                            modal.classList.remove('hidden');
                        }

                        function hideModal() {
                            modal.classList.add('hidden');
                            currentTrackingId = null;
                            if (progressInterval) {
                                clearInterval(progressInterval);
                                progressInterval = null;
                            }
                            if (animationInterval) {
                                clearInterval(animationInterval);
                                animationInterval = null;
                            }
                            // Refresh page after modal is hidden
                            setTimeout(() => {
                                window.location.reload();
                            }, 100);
                        }

                        function updateProgressDisplay(processed, total, percentage) {
                            modalProgressBar.style.width = percentage + '%';
                            modalProgressText.textContent = `Processed: ${processed} of ${total} emails`;
                        }

                        function animateProgress(total) {
                            let processed = 0;
                            
                            // Clear any existing animation
                            if (animationInterval) {
                                clearInterval(animationInterval);
                            }
                            
                            // Calculate update interval based on total emails
                            // 10% of total emails in milliseconds, with min 500ms and max 2000ms
                            const updateInterval = Math.min(Math.max(total * 100, 500), 20000);
                            
                            // Start animation
                            animationInterval = setInterval(() => {
                                // Calculate increment based on total (larger lists need bigger increments)
                                const increment = Math.max(Math.ceil(total * 0.01), 1); // At least 1 email
                                
                                processed = Math.min(processed + increment, Math.floor(total * 0.95));
                                const percentage = Math.floor((processed / total) * 100);
                                
                                updateProgressDisplay(processed, total, percentage);
                                
                                // Stop at 95%
                                if (percentage >= 95) {
                                    clearInterval(animationInterval);
                                    animationInterval = null;
                                }
                            }, updateInterval);
                        }

                        function checkProgress() {
                            if (!currentTrackingId) return;
                            
                            const progressUrl = '{{ route("mailer.progress", ["trackingId" => "__ID__"]) }}'.replace('__ID__', currentTrackingId);
                            fetch(progressUrl)
                                .then(response => response.json())
                                .then(data => {
                                    if (data.percentage === 100) {
                                        // Stop animation
                                        if (animationInterval) {
                                            clearInterval(animationInterval);
                                            animationInterval = null;
                                        }
                                        // Show 100%
                                        updateProgressDisplay(data.total, data.total, 100);
                                        // Hide modal after delay
                                        setTimeout(hideModal, 2000);
                                    } else {
                                        updateProgressDisplay(data.processed, data.total, data.percentage);
                                    }
                                })
                                .catch(error => {
                                    console.error('Error:', error);
                                    modalProgressText.textContent = 'Error checking progress';
                                });
                        }

                        document.getElementById('email-form').addEventListener('submit', function(e) {
                            e.preventDefault();
                            
                            const form = this;
                            const formData = new FormData(form);
                            const recipients = formData.get('to').split('\n').filter(email => email.trim());
                            const totalEmails = recipients.length;
                            
                            showModal();
                            updateProgressDisplay(0, totalEmails, 0);
                            
                            // Start progress animation
                            animateProgress(totalEmails);
                            
                            fetch('{{ route("mailer.send") }}', {
                                method: 'POST',
                                body: formData,
                                headers: {
                                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                                }
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.success) {
                                    currentTrackingId = data.tracking_id;
                                    // Check completion status every second
                                    progressInterval = setInterval(checkProgress, 1000);
                                } else {
                                    modalProgressText.textContent = 'Error: ' + data.message;
                                    if (animationInterval) {
                                        clearInterval(animationInterval);
                                        animationInterval = null;
                                    }
                                }
                            })
                            .catch(error => {
                                console.error('Error:', error);
                                modalProgressText.textContent = 'Error starting email send';
                                if (animationInterval) {
                                    clearInterval(animationInterval);
                                    animationInterval = null;
                                }
                            });
                        });
                    </script>

                    <style>
                        #modal-progress-bar {
                            transition: width 0.5s ease-out;
                        }
                        #progress-modal {
                            transition: opacity 0.3s ease-in-out;
                        }
                    </style>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
