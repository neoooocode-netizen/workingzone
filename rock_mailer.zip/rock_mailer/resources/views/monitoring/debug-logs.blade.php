<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Debug Logs') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <!-- Filters -->
                    <div class="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
                        <!-- Type Filter -->
                        <div>
                            <x-label for="type" :value="__('Log Type')" />
                            <x-select id="type" wire:model="filters.type" class="w-full">
                                <option value="">All Types</option>
                                <option value="campaign">Campaign</option>
                                <option value="worker">Worker</option>
                                <option value="queue">Queue</option>
                                <option value="system">System</option>
                            </x-select>
                        </div>

                        <!-- Level Filter -->
                        <div>
                            <x-label for="level" :value="__('Log Level')" />
                            <x-select id="level" wire:model="filters.level" class="w-full">
                                <option value="">All Levels</option>
                                <option value="info">Info</option>
                                <option value="warning">Warning</option>
                                <option value="error">Error</option>
                                <option value="debug">Debug</option>
                            </x-select>
                        </div>

                        <!-- Worker Filter -->
                        <div>
                            <x-label for="worker" :value="__('Worker')" />
                            <x-select id="worker" wire:model="filters.worker_id" class="w-full">
                                <option value="">All Workers</option>
                                @foreach($workers as $worker)
                                    <option value="{{ $worker->id }}">Worker #{{ $worker->id }}</option>
                                @endforeach
                            </x-select>
                        </div>

                        <!-- Campaign Filter -->
                        <div>
                            <x-label for="campaign" :value="__('Campaign')" />
                            <x-select id="campaign" wire:model="filters.campaign_id" class="w-full">
                                <option value="">All Campaigns</option>
                                @foreach($campaigns as $campaign)
                                    <option value="{{ $campaign->id }}">{{ $campaign->name }}</option>
                                @endforeach
                            </x-select>
                        </div>
                    </div>

                    <!-- Date Range Filter -->
                    <div class="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <x-label for="date_from" :value="__('From Date')" />
                            <x-input type="datetime-local" id="date_from" wire:model="filters.date_from" class="w-full" />
                        </div>
                        <div>
                            <x-label for="date_to" :value="__('To Date')" />
                            <x-input type="datetime-local" id="date_to" wire:model="filters.date_to" class="w-full" />
                        </div>
                    </div>

                    <!-- Export Button -->
                    <div class="mb-6 flex justify-end">
                        <x-button wire:click="exportLogs" class="flex items-center">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                            {{ __('Export Logs') }}
                        </x-button>
                    </div>

                    <!-- Logs Table -->
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Timestamp
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Type
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Level
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Message
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Related To
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Details
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach($logs as $log)
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {{ $log->created_at->format('Y-m-d H:i:s') }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span @class([
                                                'px-2 inline-flex text-xs leading-5 font-semibold rounded-full',
                                                'bg-blue-100 text-blue-800' => $log->type === 'campaign',
                                                'bg-green-100 text-green-800' => $log->type === 'worker',
                                                'bg-yellow-100 text-yellow-800' => $log->type === 'queue',
                                                'bg-purple-100 text-purple-800' => $log->type === 'system',
                                            ])>
                                                {{ ucfirst($log->type) }}
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span @class([
                                                'px-2 inline-flex text-xs leading-5 font-semibold rounded-full',
                                                'bg-gray-100 text-gray-800' => $log->level === 'info',
                                                'bg-yellow-100 text-yellow-800' => $log->level === 'warning',
                                                'bg-red-100 text-red-800' => $log->level === 'error',
                                                'bg-blue-100 text-blue-800' => $log->level === 'debug',
                                            ])>
                                                {{ ucfirst($log->level) }}
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-sm text-gray-900">
                                            {{ $log->message }}
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            @if($log->worker)
                                                Worker #{{ $log->worker->id }}<br>
                                            @endif
                                            @if($log->campaign)
                                                {{ $log->campaign->name }}
                                            @endif
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            <button 
                                                wire:click="showDetails({{ $log->id }})"
                                                class="text-indigo-600 hover:text-indigo-900"
                                            >
                                                View Details
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="mt-4">
                        {{ $logs->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Log Details Modal -->
    <x-modal name="log-details" :show="false">
        <div class="p-6">
            <h2 class="text-lg font-medium text-gray-900 mb-4">
                {{ __('Log Details') }}
            </h2>

            @if($selectedLog)
                <div class="space-y-4">
                    <div>
                        <h3 class="text-sm font-medium text-gray-500">Context</h3>
                        <pre class="mt-1 bg-gray-50 p-3 rounded-md text-sm overflow-x-auto">{{ json_encode($selectedLog->context, JSON_PRETTY_PRINT) }}</pre>
                    </div>

                    <div>
                        <h3 class="text-sm font-medium text-gray-500">Metadata</h3>
                        <pre class="mt-1 bg-gray-50 p-3 rounded-md text-sm overflow-x-auto">{{ json_encode($selectedLog->metadata, JSON_PRETTY_PRINT) }}</pre>
                    </div>
                </div>

                <div class="mt-6 flex justify-end">
                    <x-button x-on:click="$dispatch('close')">
                        {{ __('Close') }}
                    </x-button>
                </div>
            @endif
        </div>
    </x-modal>
</x-app-layout>
