<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Error Monitoring') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Error Summary -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4">Error Summary</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <x-monitoring.error-stat-card
                            title="Total Errors"
                            :value="$totalErrors"
                            trend="{{ $errorTrend }}%"
                            trend-direction="{{ $errorTrend <= 0 ? 'up' : 'down' }}"
                            icon="exclamation"
                        />
                        <x-monitoring.error-stat-card
                            title="Failed Emails"
                            :value="$failedEmails"
                            trend="{{ $emailErrorTrend }}%"
                            trend-direction="{{ $emailErrorTrend <= 0 ? 'up' : 'down' }}"
                            icon="mail"
                        />
                        <x-monitoring.error-stat-card
                            title="Worker Issues"
                            :value="$workerIssues"
                            trend="{{ $workerErrorTrend }}%"
                            trend-direction="{{ $workerErrorTrend <= 0 ? 'up' : 'down' }}"
                            icon="server"
                        />
                    </div>
                </div>
            </div>

            <!-- Error Logs -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-semibold">Error Logs</h3>
                        <div class="flex items-center space-x-2">
                            <x-dropdown>
                                <x-slot name="trigger">
                                    <button class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                        {{ $selectedSeverity ?? 'All Severities' }}
                                        <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                        </svg>
                                    </button>
                                </x-slot>
                                <x-slot name="content">
                                    <x-dropdown-link href="{{ route('monitoring.errors', ['severity' => 'all']) }}">
                                        All Severities
                                    </x-dropdown-link>
                                    <x-dropdown-link href="{{ route('monitoring.errors', ['severity' => 'high']) }}">
                                        High
                                    </x-dropdown-link>
                                    <x-dropdown-link href="{{ route('monitoring.errors', ['severity' => 'medium']) }}">
                                        Medium
                                    </x-dropdown-link>
                                    <x-dropdown-link href="{{ route('monitoring.errors', ['severity' => 'low']) }}">
                                        Low
                                    </x-dropdown-link>
                                </x-slot>
                            </x-dropdown>

                            <x-dropdown>
                                <x-slot name="trigger">
                                    <button class="inline-flex items-center px-3 py-2 border border-gray-300 text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                        {{ $selectedType ?? 'All Types' }}
                                        <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                            <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                        </svg>
                                    </button>
                                </x-slot>
                                <x-slot name="content">
                                    <x-dropdown-link href="{{ route('monitoring.errors', ['type' => 'all']) }}">
                                        All Types
                                    </x-dropdown-link>
                                    <x-dropdown-link href="{{ route('monitoring.errors', ['type' => 'email']) }}">
                                        Email Errors
                                    </x-dropdown-link>
                                    <x-dropdown-link href="{{ route('monitoring.errors', ['type' => 'worker']) }}">
                                        Worker Errors
                                    </x-dropdown-link>
                                    <x-dropdown-link href="{{ route('monitoring.errors', ['type' => 'system']) }}">
                                        System Errors
                                    </x-dropdown-link>
                                </x-slot>
                            </x-dropdown>
                        </div>
                    </div>

                    <div class="space-y-4">
                        @foreach($errors as $error)
                            <x-monitoring.error-log-item
                                :type="$error->type"
                                :message="$error->message"
                                :stack-trace="$error->stack_trace"
                                :timestamp="$error->created_at"
                                :severity="$error->severity"
                                :resolved="$error->resolved"
                            />
                        @endforeach
                    </div>

                    <div class="mt-4">
                        {{ $errors->links() }}
                    </div>
                </div>
            </div>

            <!-- Failed Email List -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-semibold">Failed Emails</h3>
                        <x-button @click="$dispatch('open-modal', 'retry-all-emails')">
                            Retry All
                        </x-button>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Campaign
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Recipient
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Error
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Failed At
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Actions
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach($failedEmailsList as $email)
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm font-medium text-gray-900">
                                                {{ $email->campaign->name }}
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-900">{{ $email->recipient }}</div>
                                        </td>
                                        <td class="px-6 py-4">
                                            <div class="text-sm text-gray-900">{{ $email->error_message }}</div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <div class="text-sm text-gray-900">
                                                {{ $email->failed_at->diffForHumans() }}
                                            </div>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <button @click="$dispatch('open-modal', 'retry-email-{{ $email->id }}')"
                                                    class="text-indigo-600 hover:text-indigo-900">
                                                Retry
                                            </button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4">
                        {{ $failedEmailsList->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Retry All Emails Modal -->
    <x-modal name="retry-all-emails" :show="false">
        <form method="POST" action="{{ route('monitoring.retry-all-emails') }}" class="p-6">
            @csrf
            <h2 class="text-lg font-medium text-gray-900">
                {{ __('Retry All Failed Emails') }}
            </h2>

            <p class="mt-1 text-sm text-gray-600">
                Are you sure you want to retry sending all failed emails? This will attempt to resend {{ $failedEmailsList->total() }} emails.
            </p>

            <div class="mt-6 flex justify-end">
                <x-secondary-button x-on:click="$dispatch('close')">
                    {{ __('Cancel') }}
                </x-secondary-button>

                <x-button class="ml-3">
                    {{ __('Retry All') }}
                </x-button>
            </div>
        </form>
    </x-modal>

    @foreach($failedEmailsList as $email)
        <!-- Individual Retry Email Modal -->
        <x-modal name="retry-email-{{ $email->id }}" :show="false">
            <form method="POST" action="{{ route('monitoring.retry-email', $email) }}" class="p-6">
                @csrf
                <h2 class="text-lg font-medium text-gray-900">
                    {{ __('Retry Failed Email') }}
                </h2>

                <p class="mt-1 text-sm text-gray-600">
                    Are you sure you want to retry sending this email to {{ $email->recipient }}?
                </p>

                <div class="mt-6 flex justify-end">
                    <x-secondary-button x-on:click="$dispatch('close')">
                        {{ __('Cancel') }}
                    </x-secondary-button>

                    <x-button class="ml-3">
                        {{ __('Retry') }}
                    </x-button>
                </div>
            </form>
        </x-modal>
    @endforeach
</x-app-layout>
