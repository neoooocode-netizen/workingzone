<div class="space-y-6">
    <!-- Filters -->
    <div class="bg-white rounded-lg shadow p-4">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <!-- Time Range -->
            <div>
                <label class="block text-sm font-medium text-gray-700">Time Range</label>
                <select wire:model.live="timeRange" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    @foreach($timeRanges as $key => $range)
                        <option value="{{ $key }}">{{ $range['name'] }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Worker Filter -->
            <div>
                <label class="block text-sm font-medium text-gray-700">Worker</label>
                <select wire:model.live="workerId" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="">All Workers</option>
                    @foreach($workers as $worker)
                        <option value="{{ $worker->id }}">Worker #{{ $worker->id }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Export Button -->
            <div class="flex items-end">
                <button wire:click="exportErrorStats" class="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700">
                    Export Statistics
                </button>
            </div>
        </div>
    </div>

    @if($errorStats)
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <!-- Error Categories -->
            <div class="bg-white rounded-lg shadow">
                <div class="px-4 py-5 sm:p-6">
                    <h3 class="text-lg font-medium leading-6 text-gray-900">Error Categories</h3>
                    <div class="mt-5 space-y-4">
                        @foreach($errorStats['categories'] as $category => $count)
                            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer"
                                 wire:click="selectCategory('{{ $category }}')">
                                <div class="flex items-center space-x-3">
                                    <span class="px-2.5 py-0.5 rounded-full text-xs font-medium {{ $this->getCategoryBadgeClass($category) }}">
                                        {{ ucfirst($category) }}
                                    </span>
                                    <span class="text-sm text-gray-500">
                                        {{ \App\Services\ErrorAggregationService::getCategoryDescription($category) }}
                                    </span>
                                </div>
                                <span class="text-sm font-medium text-gray-900">{{ $count }}</span>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <!-- Error Rates by Worker -->
            <div class="bg-white rounded-lg shadow">
                <div class="px-4 py-5 sm:p-6">
                    <h3 class="text-lg font-medium leading-6 text-gray-900">Error Rates by Worker</h3>
                    <div class="mt-5 space-y-4">
                        @foreach($errorStats['rates'] as $rate)
                            <div class="p-3 bg-gray-50 rounded-lg">
                                <div class="flex items-center justify-between">
                                    <span class="text-sm font-medium text-gray-900">Worker #{{ $rate->id }}</span>
                                    <span class="text-sm text-gray-500">{{ $rate->error_rate }}% Error Rate</span>
                                </div>
                                <div class="mt-2">
                                    <div class="relative pt-1">
                                        <div class="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                                            <div style="width: {{ $rate->error_rate }}%"
                                                 class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-red-500">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-1 text-xs text-gray-500">
                                        {{ $rate->total_errors }} errors out of {{ $rate->total_emails }} emails
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <!-- Common Error Patterns -->
            <div class="bg-white rounded-lg shadow">
                <div class="px-4 py-5 sm:p-6">
                    <h3 class="text-lg font-medium leading-6 text-gray-900">Common Error Patterns</h3>
                    <div class="mt-5 space-y-4">
                        @foreach($errorStats['patterns'] as $pattern)
                            <div class="p-3 bg-gray-50 rounded-lg">
                                <div class="flex items-center justify-between">
                                    <span class="text-sm font-medium text-gray-900">{{ $pattern->error_type }}</span>
                                    <span class="text-sm text-gray-500">{{ $pattern->occurrence_count }} occurrences</span>
                                </div>
                                <p class="mt-1 text-sm text-gray-500">{{ $pattern->error_message }}</p>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <!-- Error Trends -->
            <div class="bg-white rounded-lg shadow">
                <div class="px-4 py-5 sm:p-6">
                    <h3 class="text-lg font-medium leading-6 text-gray-900">Error Trends</h3>
                    <div class="mt-5">
                        <div class="relative" style="height: 300px;">
                            <!-- Placeholder for Chart.js -->
                            <canvas id="errorTrendsChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @else
        <div class="bg-white rounded-lg shadow p-4 text-center text-gray-500">
            No error statistics available
        </div>
    @endif
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    let errorTrendsChart = null;

    document.addEventListener('livewire:initialized', () => {
        @this.on('refresh-error-stats', () => {
            const trends = @this.errorStats?.trends || [];
            updateErrorTrendsChart(trends);
        });
    });

    function updateErrorTrendsChart(trends) {
        const ctx = document.getElementById('errorTrendsChart');
        
        if (errorTrendsChart) {
            errorTrendsChart.destroy();
        }

        // Process data for the chart
        const hours = [...new Set(trends.map(t => t.hour))];
        const errorTypes = [...new Set(trends.map(t => t.error_type))];
        
        const datasets = errorTypes.map(type => {
            return {
                label: type,
                data: hours.map(hour => {
                    const trend = trends.find(t => t.hour === hour && t.error_type === type);
                    return trend ? trend.error_count : 0;
                }),
                fill: false,
                tension: 0.4
            };
        });

        errorTrendsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: hours,
                datasets: datasets
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Error Count'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Time'
                        }
                    }
                }
            }
        });
    }
</script>
@endpush
