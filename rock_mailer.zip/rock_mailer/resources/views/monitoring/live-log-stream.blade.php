<div class="space-y-4">
    <!-- Filters -->
    <div class="bg-white rounded-lg shadow p-4 space-y-4">
        <h3 class="text-lg font-semibold mb-4">Live Log Stream</h3>
        
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <!-- Worker Filter -->
            <div>
                <label class="block text-sm font-medium text-gray-700">Worker</label>
                <select wire:model.live="filters.worker_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="">All Workers</option>
                    @foreach($workers as $worker)
                        <option value="{{ $worker->id }}">Worker #{{ $worker->id }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Campaign Filter -->
            <div>
                <label class="block text-sm font-medium text-gray-700">Campaign</label>
                <select wire:model.live="filters.campaign_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="">All Campaigns</option>
                    @foreach($campaigns as $campaign)
                        <option value="{{ $campaign->id }}">{{ $campaign->name }}</option>
                    @endforeach
                </select>
            </div>

            <!-- Log Type Filter -->
            <div>
                <label class="block text-sm font-medium text-gray-700">Type</label>
                <select wire:model.live="filters.type" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="all">All Types</option>
                    <option value="campaign">Campaign</option>
                    <option value="worker">Worker</option>
                    <option value="queue">Queue</option>
                    <option value="system">System</option>
                </select>
            </div>

            <!-- Error Only Toggle -->
            <div class="flex items-center space-x-2 mt-6">
                <button 
                    wire:click="toggleErrorOnly"
                    class="px-4 py-2 text-sm font-medium rounded-md {{ $filters['error_only'] ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-700' }} hover:bg-opacity-90"
                >
                    {{ $filters['error_only'] ? 'Show All Levels' : 'Show Errors Only' }}
                </button>

                <button 
                    wire:click="clearLogs"
                    class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300"
                >
                    Clear Logs
                </button>
            </div>
        </div>
    </div>

    <!-- Log Stream -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="divide-y divide-gray-200">
            @forelse($logs as $log)
                <div class="p-4 hover:bg-gray-50 transition-colors duration-150">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-2">
                            <span class="px-2.5 py-0.5 rounded-full text-xs font-medium {{ $this->getLogBadgeClass($log['level']) }}">
                                {{ strtoupper($log['level']) }}
                            </span>
                            <span class="text-sm text-gray-500">
                                {{ \Carbon\Carbon::parse($log['timestamp'])->format('Y-m-d H:i:s') }}
                            </span>
                            @if($log['worker_id'])
                                <span class="text-sm text-gray-500">Worker #{{ $log['worker_id'] }}</span>
                            @endif
                            @if($log['campaign_id'])
                                <span class="text-sm text-gray-500">Campaign #{{ $log['campaign_id'] }}</span>
                            @endif
                        </div>
                        <span class="text-sm text-gray-500">{{ $log['type'] }}</span>
                    </div>
                    
                    <p class="mt-2 text-sm text-gray-900">{{ $log['message'] }}</p>
                    
                    @if(!empty($log['context']))
                        <div class="mt-2">
                            <pre class="text-xs text-gray-600 bg-gray-50 p-2 rounded">{{ json_encode($log['context'], JSON_PRETTY_PRINT) }}</pre>
                        </div>
                    @endif
                </div>
            @empty
                <div class="p-4 text-center text-gray-500">
                    No logs to display
                </div>
            @endforelse
        </div>
    </div>
</div>
