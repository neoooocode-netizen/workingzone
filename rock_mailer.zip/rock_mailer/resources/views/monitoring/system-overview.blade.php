<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('System Overview') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- System Capacity Overview -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4">System Capacity</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <x-monitoring.metric-card
                            title="Total Workers"
                            :value="$totalWorkers"
                            icon="server"
                            trend="{{ $workerTrend }}%"
                            trend-direction="{{ $workerTrend >= 0 ? 'up' : 'down' }}"
                        />
                        <x-monitoring.metric-card
                            title="Active Campaigns"
                            :value="$activeCampaigns"
                            icon="mail"
                            trend="{{ $campaignTrend }}%"
                            trend-direction="{{ $campaignTrend >= 0 ? 'up' : 'down' }}"
                        />
                        <x-monitoring.metric-card
                            title="Queue Load"
                            :value="$queueLoad . '%'"
                            icon="chart-bar"
                            trend="{{ $queueTrend }}%"
                            trend-direction="{{ $queueTrend >= 0 ? 'up' : 'down' }}"
                        />
                        <x-monitoring.metric-card
                            title="System Health"
                            :value="$systemHealth . '%'"
                            icon="heart"
                            trend="{{ $healthTrend }}%"
                            trend-direction="{{ $healthTrend >= 0 ? 'up' : 'down' }}"
                        />
                    </div>
                </div>
            </div>

            <!-- Worker Status and Campaigns -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <!-- Active Campaigns per Worker -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold mb-4">Active Campaigns per Worker</h3>
                        <div class="h-80">
                            <canvas id="campaignsPerWorkerChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Resource Usage -->
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold mb-4">Resource Usage</h3>
                        <div class="h-80">
                            <canvas id="resourceUsageChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Queue Status -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4">Queue Status</h3>
                    <div class="space-y-4">
                        @foreach($queues as $queue)
                            <x-monitoring.queue-status-card
                                :name="$queue['name']"
                                :jobs="$queue['jobs']"
                                :processed="$queue['processed']"
                                :failed="$queue['failed']"
                                :processing-rate="$queue['processing_rate']"
                            />
                        @endforeach
                    </div>
                </div>
            </div>

            <!-- Recent System Events -->
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4">Recent System Events</h3>
                    <div class="space-y-4">
                        @foreach($systemEvents as $event)
                            <x-monitoring.event-card
                                :type="$event->type"
                                :message="$event->message"
                                :timestamp="$event->created_at"
                                :severity="$event->severity"
                            />
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Initialize WebSocket connection for real-time updates
        window.Echo.private('system-monitoring')
            .listen('SystemMetricsUpdated', (e) => {
                updateMetrics(e.metrics);
                updateCharts(e.charts);
                updateQueues(e.queues);
            });

        // Setup charts
        const campaignsCtx = document.getElementById('campaignsPerWorkerChart').getContext('2d');
        const resourceCtx = document.getElementById('resourceUsageChart').getContext('2d');

        const campaignsChart = new Chart(campaignsCtx, {
            type: 'bar',
            data: @json($campaignsChartData),
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        const resourceChart = new Chart(resourceCtx, {
            type: 'line',
            data: @json($resourceChartData),
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        function updateMetrics(metrics) {
            // Update metric cards with new data
            document.querySelectorAll('[data-metric]').forEach(card => {
                const metric = card.dataset.metric;
                if (metrics[metric]) {
                    card.querySelector('.value').textContent = metrics[metric].value;
                    card.querySelector('.trend').textContent = metrics[metric].trend + '%';
                }
            });
        }

        function updateCharts(chartData) {
            // Update charts with new data
            if (chartData.campaigns) {
                campaignsChart.data = chartData.campaigns;
                campaignsChart.update();
            }
            if (chartData.resources) {
                resourceChart.data = chartData.resources;
                resourceChart.update();
            }
        }

        function updateQueues(queues) {
            // Update queue status cards
            queues.forEach(queue => {
                const card = document.querySelector(`[data-queue="${queue.name}"]`);
                if (card) {
                    card.querySelector('.jobs').textContent = queue.jobs;
                    card.querySelector('.processed').textContent = queue.processed;
                    card.querySelector('.failed').textContent = queue.failed;
                    card.querySelector('.rate').textContent = queue.processing_rate;
                }
            });
        }
    </script>
    @endpush
</x-app-layout>
