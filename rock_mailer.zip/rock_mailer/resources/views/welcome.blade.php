<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MaDoOoOoOoOo - Welcome</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-black via-[#060d08] to-[#020503] text-green-400 font-mono min-h-screen selection:bg-green-500 selection:text-black">
    <div class="container mx-auto px-4 py-16">
        <div class="max-w-2xl mx-auto text-center">
            <h1 class="text-4xl sm:text-5xl font-bold mb-4 tracking-wider text-green-400 drop-shadow-[0_0_12px_rgba(34,197,94,0.35)]">
                MaDoOoOoOoOo
            </h1>
            <a href="https://t.me/MaD0o0o0o0o" class="inline-block mb-8 text-emerald-500 hover:text-green-300 transition-colors">
                <h2 class="text-xl sm:text-2xl font-semibold tracking-wide">By @MaD0o0o0o0o</h2>
            </a>


            <div class="space-y-6">
                <div class="mt-8 flex flex-wrap items-center justify-center gap-4">
                    @if(Session::get('authenticated'))
                        <a href="{{ route('mailer.dashboard') }}"
                           class="bg-emerald-500 hover:bg-green-400 text-black font-bold py-3 px-8 rounded-lg inline-block transform hover:scale-105 transition-all duration-200 shadow-[0_0_15px_rgba(34,197,94,0.3)]">
                            Access Mailer Dashboard
                        </a>
                        <a href="{{ route('logout') }}"
                           class="bg-red-950/80 hover:bg-red-900 border border-red-500/50 text-red-300 font-bold py-3 px-8 rounded-lg inline-block transform hover:scale-105 transition-all duration-200">
                            Logout
                        </a>
                    @else
                        <a href="{{ route('login') }}"
                           class="bg-emerald-500 hover:bg-green-400 text-black font-bold py-3 px-8 rounded-lg inline-block transform hover:scale-105 transition-all duration-200 shadow-[0_0_15px_rgba(34,197,94,0.3)]">
                            Login to Access Mailer
                        </a>
                    @endif
                </div>

                <div class="mt-12 pt-6 border-t border-emerald-500/20">
                    <a href="https://t.me/MaD0o0o0o0o"
                       target="_blank"
                       class="inline-flex items-center gap-2 bg-[#0b1710] hover:bg-emerald-950 border border-emerald-500/40 text-green-400 font-semibold py-2 px-4 rounded-lg transition-all duration-200">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .24z"/>
                        </svg>
                        Contact Developer
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>