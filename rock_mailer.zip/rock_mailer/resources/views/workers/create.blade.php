<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Register New Worker Node') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <form action="{{ route('workers.store') }}" method="POST">
                        @csrf
                        <div class="space-y-6">
                            <div>
                                <label for="hostname" class="block text-sm font-medium text-gray-700">Hostname</label>
                                <input type="text" name="hostname" id="hostname" 
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500" 
                                    required>
                                <p class="mt-2 text-sm text-gray-500">The hostname of the worker node (e.g., worker1.example.com)</p>
                            </div>

                            <div>
                                <label for="ip_address" class="block text-sm font-medium text-gray-700">IP Address</label>
                                <input type="text" name="ip_address" id="ip_address" 
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500" 
                                    required>
                                <p class="mt-2 text-sm text-gray-500">The IP address where the worker node will run</p>
                            </div>

                            <div>
                                <label for="capacity" class="block text-sm font-medium text-gray-700">Processing Capacity</label>
                                <input type="number" name="capacity" id="capacity" min="1" 
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500" 
                                    required>
                                <p class="mt-2 text-sm text-gray-500">Maximum number of concurrent email batches this worker can process</p>
                            </div>

                            <div>
                                <label for="email_rate_limit" class="block text-sm font-medium text-gray-700">Email Rate Limit</label>
                                <input type="number" name="email_rate_limit" id="email_rate_limit" min="1" 
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500" 
                                    required>
                                <p class="mt-2 text-sm text-gray-500">Maximum emails per minute this worker can send</p>
                            </div>

                            <div class="flex justify-end">
                                <button type="submit" 
                                    class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    Register Worker Node
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>