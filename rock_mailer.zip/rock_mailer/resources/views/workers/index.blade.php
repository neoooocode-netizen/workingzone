<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Worker Management') }}
            </h2>
            <button 
                x-data
                @click="$dispatch('open-modal', 'add-worker')" 
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Add New Worker
            </button>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            @if (session('warning'))
            <div class="mb-6 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4" role="alert">
                <p class="font-medium">{{ session('warning') }}</p>
                
                @if (session('batch_errors'))
                <div class="mt-3">
                    <p class="font-medium">Errors:</p>
                    <ul class="list-disc pl-5 mt-2">
                        @foreach (session('batch_errors') as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif
            </div>
            @endif
            
            @if (session('success'))
            <div class="mb-6 bg-green-100 border-l-4 border-green-500 text-green-700 p-4" role="alert">
                <p>{{ session('success') }}</p>
            </div>
            @endif
            
            <!-- Workers Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
                @forelse($workers as $worker)
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h3 class="text-lg font-semibold">{{ $worker->node_id }}</h3>
                            <p class="text-sm text-gray-600">{{ $worker->hostname }}</p>
                        </div>
                        <span class="px-2 py-1 text-xs font-semibold rounded-full 
                            @if($worker->isHealthyNode()) bg-green-100 text-green-800
                            @else bg-red-100 text-red-800 @endif">
                            {{ $worker->isHealthyNode() ? 'Active' : 'Inactive' }}
                        </span>
                    </div>

                    <!-- Performance Metrics -->
                    <div class="space-y-4">
                        <!-- CPU Load -->
                        <div>
                            <div class="flex justify-between text-sm text-gray-600 mb-1">
                                <span>CPU Load</span>
                                <span>{{ $worker->cpu_usage }}%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-blue-600 h-2 rounded-full" style="width: {{ $worker->cpu_usage }}%"></div>
                            </div>
                        </div>

                        <!-- Memory Usage -->
                        <div>
                            <div class="flex justify-between text-sm text-gray-600 mb-1">
                                <span>Memory Usage</span>
                                <span>{{ $worker->memory_usage / 1048576 }} MB</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <!-- Calculate percentage of 500 MB memory usage -->
                                <div class="bg-blue-600 h-2 rounded-full" style="width: {{ ($worker->memory_usage / 536870912) * 100 }}%"></div>
                            </div>
                        </div>

                        <!-- Current Load -->
                        <div>
                            <div class="flex justify-between text-sm text-gray-600 mb-1">
                                <span>Email Load</span>
                                <span>{{ $worker->current_load }}/{{ $worker->capacity }}</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                @php
                                    $loadPercentage = ($worker->current_load / $worker->capacity) * 100;
                                @endphp
                                <div class="bg-yellow-600 h-2 rounded-full" style="width: {{ $loadPercentage }}%"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Stats -->
                    <div class="grid grid-cols-2 gap-4 mt-4">
                        <div>
                            <p class="text-sm text-gray-600">Emails Sent</p>
                            <p class="text-xl font-bold">{{ number_format($worker->total_emails_sent) }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Success Rate</p>
                            <p class="text-xl font-bold">{{ number_format($worker->success_rate, 1) }}%</p>
                        </div>
                    </div>

                    <div class="mt-4 text-sm">
                        <span class="text-gray-600">Last Heartbeat:</span>
                        <span class="@if(!$worker->isHealthyNode()) text-red-600 @endif">
                            {{ $worker->last_heartbeat_at ? $worker->last_heartbeat_at->diffForHumans() : 'Never' }}
                        </span>
                    </div>

                    @if($worker->system_info)
                    <div class="mt-2 text-sm">
                        <p class="text-gray-600 font-medium mb-1">System Info:</p>
                        <div class="grid grid-cols-2 gap-2 pl-2">
                            <div>
                                <span class="text-gray-500">OS:</span>
                                <span class="text-gray-700">{{ $worker->system_info['os'] ?? 'Unknown' }}</span>
                            </div>
                            <div>
                                <span class="text-gray-500">CPU:</span>
                                <span class="text-gray-700">{{ $worker->system_info['cpu_cores'] ?? 'Unknown' }} cores</span>
                            </div>
                            <div>
                                <span class="text-gray-500">Memory:</span>
                                <span class="text-gray-700">{{ $worker->system_info['total_memory'] ?? 'Unknown' }}</span>
                            </div>
                            <div>
                                <span class="text-gray-500">Disk:</span>
                                <span class="text-gray-700">{{ $worker->system_info['disk_space'] ?? 'Unknown' }}</span>
                            </div>
                        </div>
                    </div>
                    @endif

                    <!-- Actions -->
                    <div class="mt-6">
                        <button 
                            x-data
                            @click="$dispatch('open-modal', 'remove-worker-{{ $worker->id }}')"
                            class="w-full bg-red-100 hover:bg-red-200 text-red-800 font-semibold py-2 px-4 rounded">
                            Remove Worker
                        </button>
                    </div>
                </div>
            </div>
                @empty
                <div class="col-span-3">
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div class="p-6">
                            <p class="text-gray-500 text-center">No workers found. Click "Add New Worker" to add one.</p>
                        </div>
                    </div>
                </div>
                @endforelse
            </div>
        </div>
    </div>

    <!-- Add Worker Modal -->
    <x-modal 
        name="add-worker" 
        :show="false"
        x-on:open-modal.window="$dispatch('open-modal', 'add-worker')">
        <form method="POST" action="{{ route('workers.store') }}" class="p-6" enctype="multipart/form-data" x-data="{addType: 'single'}">
            @csrf
            <h2 class="text-lg font-medium text-gray-900 mb-4">
                {{ __('Add New Worker') }}
            </h2>

            <!-- Add Type Selection -->
            <div class="mb-6 border-b border-gray-200">
                <div class="flex space-x-4">
                    <button type="button" @click="addType = 'single'" 
                        :class="{'border-b-2 border-blue-500 text-blue-600 font-medium': addType === 'single', 'text-gray-500': addType !== 'single'}"
                        class="py-2 px-1 focus:outline-none">
                        Single Worker
                    </button>
                    <button type="button" @click="addType = 'batch'" 
                        :class="{'border-b-2 border-blue-500 text-blue-600 font-medium': addType === 'batch', 'text-gray-500': addType !== 'batch'}"
                        class="py-2 px-1 focus:outline-none">
                        Batch Upload
                    </button>
                </div>
            </div>

            <input type="hidden" name="add_type" x-bind:value="addType">

            <!-- Single Worker Form -->
            <div x-show="addType === 'single'">
                <!-- VPS Details -->
                <div class="mb-4">
                    <x-input-label for="hostname" :value="__('Hostname/IP')" />
                    <x-text-input id="hostname" name="hostname" type="text" class="mt-1 block w-full" x-bind:required="addType === 'single'" />
                    <x-input-error :messages="$errors->get('hostname')" class="mt-2" />
                </div>

                <div class="mb-4">
                    <x-input-label for="ssh_port" :value="__('SSH Port')" />
                    <x-text-input id="ssh_port" name="ssh_port" type="number" class="mt-1 block w-full" value="22" x-bind:required="addType === 'single'" />
                    <x-input-error :messages="$errors->get('ssh_port')" class="mt-2" />
                </div>

                <div class="mb-4">
                    <x-input-label for="ssh_user" :value="__('SSH Username')" />
                    <x-text-input id="ssh_user" name="ssh_user" type="text" class="mt-1 block w-full" value="root" x-bind:required="addType === 'single'" />
                    <x-input-error :messages="$errors->get('ssh_user')" class="mt-2" />
                </div>

                <div x-data="{ authType: 'password' }" class="space-y-4">
                    <div class="mb-4">
                        <x-input-label for="auth_type" :value="__('Authentication Method')" />
                        <select id="auth_type" name="auth_type" class="mt-1 block w-full rounded-md border-gray-300" x-model="authType">
                            <option value="password">Password</option>
                            <option value="key">Private Key</option>
                        </select>
                    </div>

                    <div class="mb-4" x-show="authType === 'password'">
                        <x-input-label for="ssh_password" :value="__('SSH Password')" />
                        <x-text-input id="ssh_password" name="ssh_password" type="password" class="mt-1 block w-full" x-bind:required="addType === 'single' && authType === 'password'" />
                        <x-input-error :messages="$errors->get('ssh_password')" class="mt-2" />
                    </div>

                    <div class="mb-4" x-show="authType === 'key'">
                        <x-input-label for="ssh_key" :value="__('SSH Private Key')" />
                        <x-textarea id="ssh_key" name="ssh_key" class="mt-1 block w-full h-32" x-bind:required="addType === 'single' && authType === 'key'" />
                        <p class="mt-1 text-sm text-gray-500">Paste your private key here if using key-based authentication</p>
                        <x-input-error :messages="$errors->get('ssh_key')" class="mt-2" />
                    </div>
                </div>
            </div>
            
            <!-- Batch Upload Form -->
            <div x-show="addType === 'batch'" class="space-y-4">
                <div class="mb-4">
                    <x-input-label for="workers_file" :value="__('Workers File')" />
                    <input type="file" id="workers_file" name="workers_file" accept=".txt" 
                        class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                        x-bind:required="addType === 'batch'" />
                    <x-input-error :messages="$errors->get('workers_file')" class="mt-2" />
                    <p class="mt-2 text-sm text-gray-500">
                        Upload a .txt file with one worker per line in the format:<br>
                        <code>ip_address:username:password</code>
                    </p>
                    <div class="mt-2 p-3 bg-gray-50 rounded-md">
                        <p class="text-sm text-gray-700 font-medium">Example:</p>
                        <pre class="text-xs text-gray-600 mt-1">191.101.218.59:root:GiROG9zui584
191.101.218.64:root:Kr0f9R1iwNX1</pre>
                    </div>
                </div>

                <div class="mb-4">
                    <x-input-label for="batch_ssh_port" :value="__('SSH Port (for all workers)')" />
                    <x-text-input id="batch_ssh_port" name="batch_ssh_port" type="number" class="mt-1 block w-full" value="22" x-bind:required="addType === 'batch'" />
                    <x-input-error :messages="$errors->get('batch_ssh_port')" class="mt-2" />
                </div>
            </div>

            <div class="mb-4">
                <x-input-label for="capacity" :value="__('Email Capacity (per hour)')" />
                <x-text-input id="capacity" name="capacity" type="number" class="mt-1 block w-full" value="100" required />
                <p class="mt-1 text-sm text-gray-500" x-show="addType === 'batch'">This capacity will be applied to all workers in the batch.</p>
                <x-input-error :messages="$errors->get('capacity')" class="mt-2" />
            </div>

            <div class="mt-6 flex justify-end">
                <x-secondary-button x-on:click="$dispatch('close')">
                    {{ __('Cancel') }}
                </x-secondary-button>

                <x-primary-button class="ml-3">
                    {{ __('Add Worker') }}
                </x-primary-button>
            </div>
        </form>
    </x-modal>

    @foreach($workers as $worker)
    <!-- Edit Worker Modal -->
    <x-modal name="edit-worker-{{ $worker->id }}" :show="false">
        <form method="POST" action="{{ route('workers.update', $worker) }}" class="p-6">
            @csrf
            @method('PUT')
            <h2 class="text-lg font-medium text-gray-900 mb-4">
                {{ __('Edit Worker') }} - {{ $worker->node_id }}
            </h2>

            <div class="mb-4">
                <x-input-label for="capacity" :value="__('Email Capacity (per hour)')" />
                <x-text-input id="capacity" name="capacity" type="number" 
                             class="mt-1 block w-full" 
                             value="{{ $worker->capacity }}" required />
                <x-input-error :messages="$errors->get('capacity')" class="mt-2" />
            </div>

            <div class="mt-6 flex justify-end">
                <x-secondary-button x-on:click="$dispatch('close')">
                    {{ __('Cancel') }}
                </x-secondary-button>

                <x-primary-button class="ml-3">
                    {{ __('Update Worker') }}
                </x-primary-button>
            </div>
        </form>
    </x-modal>

    <!-- Remove Worker Modal -->
    <x-modal 
        name="remove-worker-{{ $worker->id }}" 
        :show="false"
        x-on:open-modal.window="$event.detail === 'remove-worker-{{ $worker->id }}' && show()">
        <form method="POST" action="{{ route('workers.destroy', $worker) }}" class="p-6">
            @csrf
            @method('DELETE')
            <h2 class="text-lg font-medium text-gray-900 mb-4">
                {{ __('Remove Worker') }}
            </h2>

            <p class="text-gray-600 mb-4">
                Are you sure you want to remove this worker? This action cannot be undone.
            </p>

            <div class="mt-6 flex justify-end">
                <x-secondary-button x-on:click="$dispatch('close')">
                    {{ __('Cancel') }}
                </x-secondary-button>

                <x-danger-button class="ml-3">
                    {{ __('Remove Worker') }}
                </x-danger-button>
            </div>
        </form>
    </x-modal>
    @endforeach

    @push('scripts')
    <script>
        // Refresh worker data every 30 seconds
        setInterval(() => {
            window.location.reload();
        }, 30000);
    </script>
    @endpush
</x-app-layout>
