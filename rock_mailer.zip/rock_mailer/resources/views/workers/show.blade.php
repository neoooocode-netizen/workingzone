<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                {{ __('Worker Details') }}
            </h2>
            <a href="{{ route('workers.index') }}" class="text-blue-500 hover:text-blue-700">Go to Workers List</a>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            @if(session('success'))
            <div class="bg-green-50 border-l-4 border-green-400 p-4 mb-6">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-green-700">
                            {{ session('success') }}
                        </p>
                    </div>
                </div>
            </div>
            @endif

            <div class="bg-white shadow-lg rounded-lg p-6 mb-6">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <h2 class="text-xl font-semibold mb-4">Worker Information</h2>
                        <dl class="grid grid-cols-2 gap-4">
                            <dt class="font-medium">Node ID:</dt>
                            <dd>{{ $worker->node_id }}</dd>
                            
                            <dt class="font-medium">Hostname:</dt>
                            <dd>{{ $worker->hostname }}</dd>
                            
                            <dt class="font-medium">Capacity:</dt>
                            <dd>{{ $worker->capacity }} / hr</dd>
                            
                            <dt class="font-medium">Status:</dt>
                            <dd>
                                @if($status['status'] === 'active')
                                    <span class="px-2 py-1 bg-green-100 text-green-800 rounded">Active</span>
                                @else
                                    <span class="px-2 py-1 bg-red-100 text-red-800 rounded">{{ ucfirst($status['status']) }}</span>
                                @endif
                            </dd>
                            
                            <dt class="font-medium">Last Heartbeat:</dt>
                            <dd>{{ $status['last_heartbeat'] ?? 'Never' }}</dd>
                            
                            <dt class="font-medium">Created:</dt>
                            <dd>{{ $worker->created_at->format('Y-m-d H:i:s') }}</dd>
                        </dl>
                    </div>

                    <div>
                        <h2 class="text-xl font-semibold mb-4">Worker Status</h2>
                        <dl class="grid grid-cols-2 gap-4">
                            <dt class="font-medium">Worker Status:</dt>
                            <dd>
                                @if($status['container_status'] === 'running')
                                    <span class="px-2 py-1 bg-green-100 text-green-800 rounded">Running</span>
                                @else
                                    <span class="px-2 py-1 bg-red-100 text-red-800 rounded">{{ ucfirst($status['container_status']) }}</span>
                                @endif
                            </dd>
                            
                            <dt class="font-medium">CPU Usage:</dt>
                            <dd>{{ $status['metrics']['cpu'] ?? 'N/A' }}</dd>
                            
                            <dt class="font-medium">Memory Usage:</dt>
                            <dd>{{ $status['metrics']['memory'] ?? 'N/A' }}</dd>
                            
                            <dt class="font-medium">Network I/O:</dt>
                            <dd>{{ $status['metrics']['network'] ?? 'N/A' }}</dd>

                            @if($status['last_error'])
                                <dt class="font-medium text-red-600">Last Error:</dt>
                                <dd class="text-red-600">{{ $status['last_error'] }}</dd>
                            @endif
                        </dl>
                    </div>
                </div>
            </div>

            @if($status['error'] ?? false)
            <div class="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-red-700">
                            {{ $status['error'] }}
                        </p>
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>
</x-app-layout>
