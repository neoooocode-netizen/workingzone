<?php

use App\Http\Controllers\WorkerController;
use App\Http\Controllers\CampaignController;
use App\Http\Controllers\BatchController;
use App\Http\Controllers\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Authentication Routes
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');

// Worker Management API Routes
Route::prefix('workers')->group(function () {
    Route::get('/', [WorkerController::class, 'index']);
    Route::post('/', [WorkerController::class, 'store']);
    Route::get('/status', [WorkerController::class, 'status'])->middleware('auth.worker');
    Route::post('/heartbeat', [WorkerController::class, 'heartbeat']);
    Route::get('/{id}', [WorkerController::class, 'show']);
    Route::put('/{id}', [WorkerController::class, 'update']);
    Route::delete('/{id}', [WorkerController::class, 'destroy']);
});

// Worker API Routes
Route::prefix('worker')->middleware(['auth.worker'])->group(function () {
    Route::get('jobs/next', [WorkerController::class, 'getNextJob']);
    Route::post('jobs/{job}/complete', [WorkerController::class, 'completeJob']);
});

// Batch Management Routes
Route::prefix('batches')->group(function () {
    Route::get('/next', [BatchController::class, 'getNext']);
    Route::post('/{id}/update', [BatchController::class, 'updateStatus']);
    Route::post('/{id}/complete', [BatchController::class, 'complete']);
});

// Campaign Management API Routes
Route::prefix('campaigns')->middleware('auth:sanctum')->group(function () {
    Route::get('/{id}/status', [CampaignController::class, 'status']);
    Route::post('/{id}/pause', [CampaignController::class, 'pause']);
    Route::post('/{id}/resume', [CampaignController::class, 'resume']);
    Route::get('/{campaign}/attachments/{path}', [CampaignController::class, 'downloadAttachment'])
        ->where('path', '.*');
});
