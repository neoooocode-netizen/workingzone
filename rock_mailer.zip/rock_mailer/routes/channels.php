<?php

use Illuminate\Support\Facades\Broadcast;
use App\Models\Campaign;

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Here you may register all of the event broadcasting channels that your
| application supports. The given channel authorization callbacks are
| used to check if an authenticated user can listen to the channel.
|
*/

// Campaign progress channel
Broadcast::channel('campaign.{campaignId}', function ($user, $campaignId) {
    return $user->can('view', Campaign::findOrFail($campaignId));
});

// Worker status channel
Broadcast::channel('workers', function ($user) {
    return $user->can('view-workers');
});

// Queue status channel
Broadcast::channel('queues', function ($user) {
    return $user->can('view-queues');
});

// System metrics channel
Broadcast::channel('system-metrics', function ($user) {
    return $user->can('view-metrics');
});
