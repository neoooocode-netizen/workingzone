#!/bin/bash

# Exit on any error
set -e

# Default values
REGISTRY="local"
IMAGE_NAME="rock_mailer-worker"
IMAGE_TAG="latest"
CONTAINER_NAME="rock_mailer_worker"
ENV_FILE="/opt/rock_mailer/.env"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --token)
            AUTH_TOKEN="$2"
            shift 2
            ;;
        --api-url)
            API_URL="$2"
            shift 2
            ;;
        --worker-id)
            WORKER_ID="$2"
            shift 2
            ;;
        --capacity)
            CAPACITY="$2"
            shift 2
            ;;
        *)
            echo "Unknown parameter: $1"
            exit 1
            ;;
    esac
done

# Validate required parameters
if [[ -z "$AUTH_TOKEN" || -z "$API_URL" || -z "$WORKER_ID" ]]; then
    echo "Error: Missing required parameters"
    echo "Usage: $0 --token <auth_token> --api-url <api_url> --worker-id <worker_id> [--capacity <capacity>]"
    exit 1
fi

# Check if Docker is installed and running
if ! command -v docker &> /dev/null; then
    echo "Docker not found. Installing Docker..."
    # Install Docker using CentOS-specific commands
    yum install -y yum-utils
    yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
    yum install -y docker-ce docker-ce-cli containerd.io
    systemctl start docker
    systemctl enable docker
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "Docker Compose not found. Installing Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

# Create necessary directories
mkdir -p /opt/rock_mailer
mkdir -p /opt/rock_mailer/logs

# Create environment file
cat > $ENV_FILE << EOL
WORKER_ID=$WORKER_ID
AUTH_TOKEN=$AUTH_TOKEN
API_URL=$API_URL
WORKER_CAPACITY=${CAPACITY:-100}
EOL

# Create docker-compose.yml
cat > /opt/rock_mailer/docker-compose.yml << EOL
version: '3.8'

services:
  worker:
    image: ${REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG}
    container_name: ${CONTAINER_NAME}
    restart: unless-stopped
    env_file: .env
    volumes:
      - ./logs:/var/log/rock_mailer
    networks:
      - rock_mailer_net

networks:
  rock_mailer_net:
    driver: bridge
EOL

# Pull the latest image
echo "Pulling latest worker image..."
docker pull ${REGISTRY}/${IMAGE_NAME}:${IMAGE_TAG}

# Stop and remove existing container if it exists
if docker ps -a | grep -q ${CONTAINER_NAME}; then
    echo "Stopping and removing existing container..."
    docker stop ${CONTAINER_NAME} || true
    docker rm ${CONTAINER_NAME} || true
fi

# Start the container
echo "Starting worker container..."
cd /opt/rock_mailer
docker-compose up -d

# Check if container is running
if docker ps | grep -q ${CONTAINER_NAME}; then
    echo "Worker container successfully started!"
    echo "Container logs:"
    docker logs ${CONTAINER_NAME}
else
    echo "Error: Container failed to start"
    echo "Container logs:"
    docker logs ${CONTAINER_NAME}
    exit 1
fi
