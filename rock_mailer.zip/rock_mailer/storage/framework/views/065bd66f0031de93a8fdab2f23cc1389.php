<div class="flex items-center">
    <img src="/images/rock_logo.png" <?php echo e($attributes); ?> alt="Rock Logo">
    <span class="text-2xl font-bold text-gray-800">ROCK MAILER</span>
</div>
<?php /**PATH /var/www/html/rock_mailer/resources/views/components/application-logo.blade.php ENDPATH**/ ?>