<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Worker Details')); ?>

            </h2>
            <a href="<?php echo e(route('workers.index')); ?>" class="text-blue-500 hover:text-blue-700">Go to Workers List</a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if(session('success')): ?>
            <div class="bg-green-50 border-l-4 border-green-400 p-4 mb-6">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-green-700">
                            <?php echo e(session('success')); ?>

                        </p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="bg-white shadow-lg rounded-lg p-6 mb-6">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <h2 class="text-xl font-semibold mb-4">Worker Information</h2>
                        <dl class="grid grid-cols-2 gap-4">
                            <dt class="font-medium">Node ID:</dt>
                            <dd><?php echo e($worker->node_id); ?></dd>
                            
                            <dt class="font-medium">Hostname:</dt>
                            <dd><?php echo e($worker->hostname); ?></dd>
                            
                            <dt class="font-medium">Capacity:</dt>
                            <dd><?php echo e($worker->capacity); ?> / hr</dd>
                            
                            <dt class="font-medium">Status:</dt>
                            <dd>
                                <?php if($status['status'] === 'active'): ?>
                                    <span class="px-2 py-1 bg-green-100 text-green-800 rounded">Active</span>
                                <?php else: ?>
                                    <span class="px-2 py-1 bg-red-100 text-red-800 rounded"><?php echo e(ucfirst($status['status'])); ?></span>
                                <?php endif; ?>
                            </dd>
                            
                            <dt class="font-medium">Last Heartbeat:</dt>
                            <dd><?php echo e($status['last_heartbeat'] ?? 'Never'); ?></dd>
                            
                            <dt class="font-medium">Created:</dt>
                            <dd><?php echo e($worker->created_at->format('Y-m-d H:i:s')); ?></dd>
                        </dl>
                    </div>

                    <div>
                        <h2 class="text-xl font-semibold mb-4">Worker Status</h2>
                        <dl class="grid grid-cols-2 gap-4">
                            <dt class="font-medium">Worker Status:</dt>
                            <dd>
                                <?php if($status['container_status'] === 'running'): ?>
                                    <span class="px-2 py-1 bg-green-100 text-green-800 rounded">Running</span>
                                <?php else: ?>
                                    <span class="px-2 py-1 bg-red-100 text-red-800 rounded"><?php echo e(ucfirst($status['container_status'])); ?></span>
                                <?php endif; ?>
                            </dd>
                            
                            <dt class="font-medium">CPU Usage:</dt>
                            <dd><?php echo e($status['metrics']['cpu'] ?? 'N/A'); ?></dd>
                            
                            <dt class="font-medium">Memory Usage:</dt>
                            <dd><?php echo e($status['metrics']['memory'] ?? 'N/A'); ?></dd>
                            
                            <dt class="font-medium">Network I/O:</dt>
                            <dd><?php echo e($status['metrics']['network'] ?? 'N/A'); ?></dd>

                            <?php if($status['last_error']): ?>
                                <dt class="font-medium text-red-600">Last Error:</dt>
                                <dd class="text-red-600"><?php echo e($status['last_error']); ?></dd>
                            <?php endif; ?>
                        </dl>
                    </div>
                </div>
            </div>

            <?php if($status['error'] ?? false): ?>
            <div class="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-red-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-red-700">
                            <?php echo e($status['error']); ?>

                        </p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/rock_mailer/resources/views/workers/show.blade.php ENDPATH**/ ?>