<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rock Mailer - Welcome</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-50 to-blue-100 min-h-screen">
    <div class="container mx-auto px-4 py-16">
        <div class="max-w-2xl mx-auto text-center">
            <h1 class="text-5xl font-bold mb-8 text-blue-900">ROCK VPS MAILER</h1>
            <a href="https://t.me/rockybelling"><h1 class="text-2xl font-bold mb-8 text-blue-900">by @rockybelling</h1></a>
            <p class="text-xl text-gray-600 mb-12">A powerful email management system for your business needs.</p>
            
            <div class="space-y-6">
                <div class="bg-white rounded-lg shadow-lg p-8">
                    <h2 class="text-2xl font-semibold mb-4 text-gray-800">Features</h2>
                    <ul class="text-left text-gray-600 space-y-2">
                        <li class="flex items-center">
                            <svg class="w-5 h-5 mr-2 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                            Multiple Email Recipients
                        </li>
                        <li class="flex items-center">
                            <svg class="w-5 h-5 mr-2 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                            HTML Email Support
                        </li>
                        <li class="flex items-center">
                            <svg class="w-5 h-5 mr-2 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                            File Attachments
                        </li>
                        <li class="flex items-center">
                            <svg class="w-5 h-5 mr-2 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                            MultiCampaign Management
                        </li>
                        <li class="flex items-center">
                            <svg class="w-5 h-5 mr-2 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                            </svg>
                            Multi Worker Management
                        </li>
                    </ul>
                </div>

                <div class="mt-8">
                    <?php if(Session::get('authenticated')): ?>
                        <a href="<?php echo e(route('mailer.dashboard')); ?>" 
                           class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg inline-block transform hover:scale-105 transition-all duration-200 shadow-lg">
                            Access Mailer Dashboard
                        </a>
                        <a href="<?php echo e(route('logout')); ?>" 
                           class="bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-8 rounded-lg inline-block transform hover:scale-105 transition-all duration-200 shadow-lg ml-4">
                            Logout
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" 
                           class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-lg inline-block transform hover:scale-105 transition-all duration-200 shadow-lg">
                            Login to Access Mailer
                        </a>
                    <?php endif; ?>
                </div>

                <div class="mt-12 pt-6 border-t border-gray-200">
                    <a href="https://t.me/rockybelling" 
                       target="_blank"
                       class="inline-flex items-center gap-2 bg-[#0088cc] hover:bg-[#0077b5] text-white font-semibold py-2 px-4 rounded-lg transition-all duration-200 shadow-md">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .24z"/>
                        </svg>
                        Contact Developer
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH /var/www/html/rock_mailer/resources/views/welcome.blade.php ENDPATH**/ ?>