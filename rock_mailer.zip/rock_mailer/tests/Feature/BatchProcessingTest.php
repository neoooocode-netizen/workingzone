<?php

namespace Tests\Feature;

use App\Models\Campaign;
use App\Models\Worker;
use App\Models\EmailBatch;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BatchProcessingTest extends TestCase
{
    use RefreshDatabase;

    private Worker $worker;
    private Campaign $campaign;

    protected function setUp(): void
    {
        parent::setUp();

        $this->worker = Worker::factory()->create(['status' => 'active']);
        $this->campaign = Campaign::factory()->create(['status' => 'running']);
    }

    public function test_worker_can_get_next_batch()
    {
        EmailBatch::factory()->create([
            'campaign_id' => $this->campaign->id,
            'status' => 'pending',
            'emails' => ['test1@example.com', 'test2@example.com']
        ]);

        $response = $this->withHeaders([
            'Authorization' => 'Bearer ' . $this->worker->api_token
        ])->getJson('/api/batches/next');

        $response->assertStatus(200)
                ->assertJsonStructure([
                    'batch_id',
                    'campaign_id',
                    'emails',
                    'template',
                    'settings'
                ]);
    }

    public function test_worker_can_update_batch_progress()
    {
        $batch = EmailBatch::factory()->create([
            'campaign_id' => $this->campaign->id,
            'worker_id' => $this->worker->id,
            'status' => 'processing'
        ]);

        $response = $this->withHeaders([
            'Authorization' => 'Bearer ' . $this->worker->api_token
        ])->postJson("/api/batches/{$batch->id}/update", [
            'processed_count' => 50,
            'success_count' => 45,
            'failed_count' => 5,
            'status' => 'processing'
        ]);

        $response->assertStatus(200);

        $this->assertDatabaseHas('email_batches', [
            'id' => $batch->id,
            'processed_count' => 50,
            'success_count' => 45,
            'failed_count' => 5
        ]);
    }

    public function test_worker_can_complete_batch()
    {
        $batch = EmailBatch::factory()->create([
            'campaign_id' => $this->campaign->id,
            'worker_id' => $this->worker->id,
            'status' => 'processing'
        ]);

        $response = $this->withHeaders([
            'Authorization' => 'Bearer ' . $this->worker->api_token
        ])->postJson("/api/batches/{$batch->id}/complete", [
            'success_count' => 95,
            'failed_count' => 5,
            'failed_emails' => [
                ['email' => 'fail1@example.com', 'error' => 'SMTP error'],
                ['email' => 'fail2@example.com', 'error' => 'Invalid address']
            ]
        ]);

        $response->assertStatus(200);

        $this->assertDatabaseHas('email_batches', [
            'id' => $batch->id,
            'status' => 'completed',
            'success_count' => 95,
            'failed_count' => 5
        ]);
    }

    public function test_batch_error_handling()
    {
        $batch = EmailBatch::factory()->create([
            'campaign_id' => $this->campaign->id,
            'worker_id' => $this->worker->id,
            'status' => 'processing'
        ]);

        $response = $this->withHeaders([
            'Authorization' => 'Bearer ' . $this->worker->api_token
        ])->postJson("/api/batches/{$batch->id}/update", [
            'status' => 'failed',
            'error' => 'SMTP server connection failed'
        ]);

        $response->assertStatus(200);

        $this->assertDatabaseHas('email_batches', [
            'id' => $batch->id,
            'status' => 'failed'
        ]);

        $this->assertDatabaseHas('system_logs', [
            'type' => 'batch',
            'level' => 'error',
            'batch_id' => $batch->id
        ]);
    }

    public function test_batch_rate_limiting()
    {
        // Create multiple batches in quick succession
        $responses = collect(range(1, 5))->map(function () {
            return $this->withHeaders([
                'Authorization' => 'Bearer ' . $this->worker->api_token
            ])->getJson('/api/batches/next');
        });

        // At least one response should indicate rate limiting
        $this->assertTrue(
            $responses->contains(function ($response) {
                return $response->status() === 429;
            })
        );
    }
}
