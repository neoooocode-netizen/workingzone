<?php

namespace Tests\Feature;

use App\Models\Campaign;
use App\Models\Worker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CampaignManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_can_create_campaign()
    {
        $response = $this->postJson('/api/campaigns/create', [
            'name' => 'Test Campaign',
            'email_list' => [
                'test1@example.com',
                'test2@example.com'
            ],
            'template' => 'Welcome to our service!',
            'settings' => [
                'batch_size' => 100,
                'rate_limit' => 1000
            ]
        ]);

        $response->assertStatus(201)
                ->assertJsonStructure([
                    'campaign_id',
                    'status'
                ]);

        $this->assertDatabaseHas('campaigns', [
            'name' => 'Test Campaign',
            'status' => 'pending'
        ]);
    }

    public function test_can_get_campaign_status()
    {
        $campaign = Campaign::factory()->create([
            'status' => 'running',
            'total_emails' => 1000,
            'sent_emails' => 500
        ]);

        $response = $this->getJson("/api/campaigns/{$campaign->id}/status");

        $response->assertStatus(200)
                ->assertJsonStructure([
                    'status',
                    'progress',
                    'total_emails',
                    'sent_emails',
                    'failed_emails'
                ]);
    }

    public function test_can_pause_campaign()
    {
        $campaign = Campaign::factory()->create(['status' => 'running']);

        $response = $this->postJson("/api/campaigns/{$campaign->id}/pause");

        $response->assertStatus(200)
                ->assertJson(['status' => 'paused']);

        $this->assertDatabaseHas('campaigns', [
            'id' => $campaign->id,
            'status' => 'paused'
        ]);
    }

    public function test_can_resume_campaign()
    {
        $campaign = Campaign::factory()->create(['status' => 'paused']);

        $response = $this->postJson("/api/campaigns/{$campaign->id}/resume");

        $response->assertStatus(200)
                ->assertJson(['status' => 'running']);

        $this->assertDatabaseHas('campaigns', [
            'id' => $campaign->id,
            'status' => 'running'
        ]);
    }

    public function test_campaign_assignment_to_workers()
    {
        $campaign = Campaign::factory()->create(['status' => 'pending']);
        $worker = Worker::factory()->create(['status' => 'active']);

        $response = $this->postJson("/api/campaigns/{$campaign->id}/assign", [
            'worker_id' => $worker->id
        ]);

        $response->assertStatus(200);

        $this->assertDatabaseHas('campaign_worker', [
            'campaign_id' => $campaign->id,
            'worker_id' => $worker->id
        ]);
    }

    public function test_campaign_validation()
    {
        $response = $this->postJson('/api/campaigns/create', [
            'name' => '',
            'email_list' => 'not-an-array',
            'template' => ''
        ]);

        $response->assertStatus(422)
                ->assertJsonValidationErrors(['name', 'email_list', 'template']);
    }
}
