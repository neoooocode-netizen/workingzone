<?php

namespace Tests\Feature;

use App\Models\Worker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class WorkerRegistrationTest extends TestCase
{
    use RefreshDatabase;

    public function test_worker_can_register()
    {
        $response = $this->postJson('/api/workers/register', [
            'hostname' => 'worker-1.example.com',
            'ip_address' => '192.168.1.100',
            'capacity' => 1000,
            'system_info' => [
                'cpu_cores' => 4,
                'memory_total' => 8192,
                'disk_space' => 50000
            ]
        ]);

        $response->assertStatus(201)
                ->assertJsonStructure([
                    'worker_id',
                    'api_token'
                ]);

        $this->assertDatabaseHas('workers', [
            'hostname' => 'worker-1.example.com',
            'ip_address' => '192.168.1.100',
            'capacity' => 1000
        ]);
    }

    public function test_worker_can_send_heartbeat()
    {
        $worker = Worker::factory()->create();

        $response = $this->withHeaders([
            'Authorization' => 'Bearer ' . $worker->api_token
        ])->postJson('/api/workers/heartbeat', [
            'status' => 'active',
            'current_load' => 500,
            'memory_usage' => 4096,
            'cpu_usage' => 45.5
        ]);

        $response->assertStatus(200)
                ->assertJson(['message' => 'Heartbeat received']);

        $this->assertDatabaseHas('workers', [
            'id' => $worker->id,
            'status' => 'active',
            'current_load' => 500
        ]);
    }

    public function test_worker_cannot_register_with_invalid_data()
    {
        $response = $this->postJson('/api/workers/register', [
            'hostname' => '',
            'ip_address' => 'invalid-ip',
            'capacity' => -1
        ]);

        $response->assertStatus(422)
                ->assertJsonValidationErrors(['hostname', 'ip_address', 'capacity']);
    }

    public function test_worker_can_get_status()
    {
        $worker = Worker::factory()->create([
            'status' => 'active',
            'current_load' => 500
        ]);

        $response = $this->withHeaders([
            'Authorization' => 'Bearer ' . $worker->api_token
        ])->getJson('/api/workers/status');

        $response->assertStatus(200)
                ->assertJsonStructure([
                    'status',
                    'current_load',
                    'assigned_campaigns'
                ]);
    }

    public function test_unauthorized_worker_cannot_access_api()
    {
        $response = $this->getJson('/api/workers/status');

        $response->assertStatus(401);
    }
}
