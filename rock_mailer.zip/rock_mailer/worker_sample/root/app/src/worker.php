<?php
// Load environment variables from .env file
$env = parse_ini_file('/opt/rock_mailer/app/.env');  // Updated path for native installation
$nodeId = $env['NODE_ID'] ?? null;
$apiKey = $env['API_KEY'] ?? null;
$mainServer = rtrim($env['MAIN_SERVER'] ?? '', '/');

if (!$nodeId || !$apiKey || !$mainServer) {
    error_log('Missing required environment variables');
    exit(1);
}

// Configure error logging to system log
ini_set('error_log', '/opt/rock_mailer/app/logs/worker.log');
ini_set('log_errors', 1);
// error_log("Starting worker node: {$nodeId}");
// error_log("Main server: {$mainServer}");

// Track worker state
$processedEmails = 0;
$failedEmails = 0;
$totalEmailsSent = 0;  // Track total emails across all batches
$lastHeartbeat = 0;
$errorLogs = [];
$currentBatchId = null; // Track current batch ID

function fetchNextBatch($mainServer, $nodeId, $apiKey) {
    global $processedEmails, $failedEmails;
    
    $batchUrl = "{$mainServer}/api/batches/next";
    // error_log("Looking for pending batch from {$batchUrl}");
    
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $batchUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,  // No timeout
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_POSTFIELDS => json_encode([
            'status' => 'active',
            'load' => $processedEmails + $failedEmails,
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true)
        ]),
        CURLOPT_HTTPHEADER => array(
            "X-Worker-ID: {$nodeId}",
            'Content-Type: application/json',
            'Accept: application/json'
        ),
    ));
    
    $response = curl_exec($ch);
    // error_log("Raw response: " . $response);
    // error_log("Curl info: " . print_r(curl_getinfo($ch), true));
    
    if (curl_errno($ch)) {
        error_log("Curl error: " . curl_error($ch));
        curl_close($ch);
        return null;
    }
    curl_close($ch);

    $data = json_decode($response, true);
    // error_log("Response data: " . print_r($data, true));

    return $data['data'] ?? null;
}

function fetchCampaignData($mainServer, $nodeId, $apiKey, $campaignId) {
    $url = "{$mainServer}/api/campaigns/{$campaignId}";
    // error_log("Fetching campaign data for ID: {$campaignId}");
    
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 5,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            "X-Worker-ID: {$nodeId}",
            "X-Auth-Token: {$apiKey}",
            'Content-Type: application/json'
        ),
    ));
    
    $response = curl_exec($ch);
    // error_log("Raw response: " . $response);
    // error_log("Curl info: " . print_r(curl_getinfo($ch), true));
    
    if (curl_errno($ch)) {
        // error_log("Curl error: " . curl_error($ch));
        curl_close($ch);
        return null;
    }
    curl_close($ch);

    $data = json_decode($response, true);
    // error_log("Response data: " . print_r($data, true));

    return $data['data'] ?? null;
}

function constructEmail(array $emailData, $nodeId, $apiKey): array {
    $headers = [];
    $headers[] = 'MIME-Version: 1.0';
    
    $message = '';
    
    if (!empty($emailData['campaign']['attachments'])) {
        try {
            $boundary = "PHP-mixed-" . md5(uniqid(time()));
            $headers[] = 'Content-Type: multipart/mixed; boundary="' . $boundary . '"';
            
            // Start message with body
            $message = "--" . $boundary . "\r\n";
            $message .= "Content-Type: text/html; charset=UTF-8\r\n";
            $message .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
            $message .= $emailData['campaign']['body'] . "\r\n\r\n";
            
            // Process each attachment
            foreach ($emailData['campaign']['attachments'] as $attachment) {
                // Generate random 7-digit number for filename
                $randomNumber = str_pad(mt_rand(0, 9999999), 7, '0', STR_PAD_LEFT);
                $extension = pathinfo($attachment['name'], PATHINFO_EXTENSION);
                $newFilename = $randomNumber . '.' . $extension;
                
                // error_log("Processing attachment: Original name={$attachment['name']}, New name={$newFilename}, MIME={$attachment['mime_type']}");
                
                $message .= "--" . $boundary . "\r\n";
                $message .= "Content-Type: " . $attachment['mime_type'] . "; name=\"" . $newFilename . "\"\r\n";
                $message .= "Content-Transfer-Encoding: base64\r\n";
                $message .= "Content-Disposition: attachment; filename=\"" . $newFilename . "\"\r\n\r\n";
                $message .= chunk_split($attachment['content']) . "\r\n\r\n";
                
                // error_log("Attachment added to email with random name: {$newFilename}");
            }
            
            $message .= "--" . $boundary . "--";
        } catch (Exception $e) {
            // error_log('Failed to process attachments: ' . $e->getMessage());
            throw $e;
        }
    } else {
        // No attachments, just HTML
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        $message = $emailData['campaign']['body'];
    }

    // Add remaining headers
    $headers[] = 'From: ' . $emailData['campaign']['from_name'] . ' <' . $emailData['campaign']['from_email'] . '>';
    $headers[] = 'Reply-To: ' . $emailData['campaign']['reply_to'];
    $headers[] = 'Accept-Language: en-US';
    $headers[] = 'Content-Language: en-US';
    $headers[] = 'priority: high';
    $headers[] = 'importance: high';
    $headers[] = 'date: ' . date('r');
    $headers[] = 'X-MS-Exchange-Organization-AuthAs: Internal';
    $headers[] = 'X-MS-Exchange-Organization-AuthMechanism: 04';
    $headers[] = 'X-MS-Exchange-Organization-AuthSource: AM6PR05MB6112.eurprd02.prod.outlook.com';
    $headers[] = 'X-Mailer: Microsoft Office Outlook, Build 11.0.5510';
    $headers[] = 'X-MimeOLE: Produced By Microsoft MimeOLE V6.00.2800.1441';
    $headers[] = 'X-Recommended-Action: accept';
    $headers[] = 'X-Spam-Category: LEGIT';

    return [
        'headers' => implode("\r\n", $headers),
        'message' => $message
    ];
}

function sendEmail(string $recipient, array $emailData, $nodeId, $apiKey): bool {
    global $processedEmails, $failedEmails, $errorLogs;
    
    try {
        // Set unlimited execution time for large batches
        set_time_limit(0);
        ini_set('max_execution_time', 0);
        
        // Configure sendmail path for CentOS
        ini_set('sendmail_path', '/usr/sbin/sendmail -t -i');

        $email = constructEmail($emailData, $nodeId, $apiKey);
        
        // Add additional headers for better deliverability
        $headers = $email['headers'] . "\r\n" .
                  'X-Mailer: PHP/' . phpversion() . "\r\n" .
                  'Message-ID: <' . uniqid() . '@' . gethostname() . '>';

        $result = mail(
            $recipient,
            $emailData['campaign']['subject'],
            $email['message'],
            $headers
        );

        if ($result) {
            $processedEmails++;
            // error_log("Email sent successfully to: {$recipient}");
            return true;
        }

        throw new Exception('Mail sending failed');

    } catch (Exception $e) {
        $failedEmails++;
        $errorLogs[] = [
            'recipient' => $recipient,
            'error' => $e->getMessage(),
            'timestamp' => date('Y-m-d H:i:s')
        ];

        // error_log("Email sending failed for {$recipient}: " . $e->getMessage());
        return false;
    }
}

function updateBatchStatus($mainServer, $nodeId, $apiKey, $batchId, $status, $stats) {
    // error_log("Updating batch $batchId status to $status");
    
    $updateUrl = "{$mainServer}/api/batches/{$batchId}/update";
    
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $updateUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 5,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode([
            'status' => $status,
            'success_count' => $stats['success_count'],
            'failed_count' => $stats['failed_count'],
            'error_log' => $stats['error_logs']
        ]),
        CURLOPT_HTTPHEADER => array(
            "X-Worker-ID: {$nodeId}",
            "X-Auth-Token: {$apiKey}",
            'Content-Type: application/json'
        ),
    ));
    
    $response = curl_exec($ch);
    // error_log("Raw response: " . $response);
    // error_log("Curl info: " . print_r(curl_getinfo($ch), true));
    
    if (curl_errno($ch)) {
        // error_log("Curl error: " . curl_error($ch));
        curl_close($ch);
        return false;
    }
    curl_close($ch);

    $success = $response !== false;

    return $success;
}

while (true) {
    try {
        // Send heartbeat every 10 seconds
        $now = microtime(true);
        if ($now - $lastHeartbeat >= 10) {
            $heartbeatUrl = "{$mainServer}/api/workers/heartbeat";
            // error_log("Sending heartbeat to {$heartbeatUrl}");
            
            $ch = curl_init();
            curl_setopt_array($ch, array(
                CURLOPT_URL => $heartbeatUrl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 5,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => ($heartbeatData = json_encode([
                    'status' => 'active',
                    'load' => $processedEmails + $failedEmails,
                    'memory_usage' => memory_get_usage(true),
                    'peak_memory' => memory_get_peak_usage(true),
                    'cpu_usage' => 0,
                    'total_emails_sent' => $totalEmailsSent,
                    'success_rate' => ($processedEmails + $failedEmails > 0) ? ($processedEmails / ($processedEmails + $failedEmails) * 100) : 100
                ])),
                CURLOPT_HTTPHEADER => array(
                    "X-Worker-ID: {$nodeId}",
                    'Content-Type: application/json',
                    'Accept: application/json'
                ),
            ));
            
            // error_log("Raw JSON being sent: " . $heartbeatData);
            
            $response = curl_exec($ch);
            // error_log("Heartbeat response: " . $response);
            
            if (curl_errno($ch)) {
                // error_log("Curl error: " . curl_error($ch));
                curl_close($ch);
            } else {
                curl_close($ch);
            }
            $lastHeartbeat = $now;
        }

        // Step 1: Fetch next batch (includes campaign data)
        $batch = fetchNextBatch($mainServer, $nodeId, $apiKey);
        if (empty($batch)) {
            // error_log("No pending batches available");
            sleep(5);
            continue;
        }

        // Store the batch ID
        $currentBatchId = $batch['id'];

        // Process emails in smaller chunks
        $batchSize = 100;
        $delay = 1; // 1 second delay between chunks
        
        foreach (array_chunk($batch['recipients'], $batchSize) as $chunk) {
            foreach ($chunk as $recipient) {
                // Pass the entire email data structure
                sendEmail($recipient, [
                    'campaign' => $batch['campaign']
                ], $nodeId, $apiKey);
            }
            
            if ($delay > 0) {
                sleep($delay);
            }
        }

        // Update batch status
        $stats = [
            'success_count' => $processedEmails,
            'failed_count' => $failedEmails,
            'error_logs' => $errorLogs
        ];
        
        updateBatchStatus($mainServer, $nodeId, $apiKey, $currentBatchId, 'completed', $stats);
        
        // Update total emails sent
        $totalEmailsSent += $processedEmails;
        
        // Reset batch counters and logs
        $processedEmails = 0;
        $failedEmails = 0;
        $errorLogs = [];
        $currentBatchId = null; // Reset batch ID

    } catch (Exception $e) {
        // error_log("Error: " . $e->getMessage() . "\n" . $e->getTraceAsString());
        sleep(5);
    }
}

function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    return round($bytes / pow(1024, $pow), $precision) . ' ' . $units[$pow];
}
